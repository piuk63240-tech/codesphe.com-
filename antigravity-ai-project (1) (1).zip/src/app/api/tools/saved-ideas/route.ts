import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const toolType = searchParams.get('toolType');
    const limit = Math.min(parseInt(searchParams.get('limit') || '50', 10), 100);
    const offset = parseInt(searchParams.get('offset') || '0', 10);

    const where: Record<string, unknown> = {};
    if (category) where.category = category;
    if (toolType) where.toolType = toolType;

    const [ideas, total] = await Promise.all([
      db.savedIdea.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      db.savedIdea.count({ where }),
    ]);

    return NextResponse.json({
      ideas,
      total,
      limit,
      offset,
    });
  } catch (error) {
    console.error('Saved ideas fetch error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch saved ideas' },
      { status: 500 }
    );
  }
}
