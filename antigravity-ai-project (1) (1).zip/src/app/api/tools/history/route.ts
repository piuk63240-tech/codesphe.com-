import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const toolType = searchParams.get('toolType');
    const limit = Math.min(parseInt(searchParams.get('limit') || '20', 10), 100);
    const offset = parseInt(searchParams.get('offset') || '0', 10);

    const where = toolType ? { toolType } : {};

    const [results, total] = await Promise.all([
      db.toolResult.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
        select: {
          id: true,
          toolType: true,
          input: true,
          output: true,
          rating: true,
          createdAt: true,
        },
      }),
      db.toolResult.count({ where }),
    ]);

    return NextResponse.json({
      results,
      total,
      limit,
      offset,
    });
  } catch (error) {
    console.error('History fetch error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch tool result history' },
      { status: 500 }
    );
  }
}
