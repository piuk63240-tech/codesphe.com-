import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

interface RateBody {
  id?: string;
  toolType?: string;
  rating: number;
}

export async function POST(request: NextRequest) {
  try {
    const body: RateBody = await request.json();
    const { id, rating } = body;

    if (rating === undefined || rating === null) {
      return NextResponse.json(
        { error: 'Missing required field: rating' },
        { status: 400 }
      );
    }

    if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
      return NextResponse.json(
        { error: 'Rating must be an integer between 1 and 5' },
        { status: 400 }
      );
    }

    if (!id) {
      // If no specific result ID, just acknowledge the rating
      return NextResponse.json({
        rating,
        message: 'Rating recorded',
      });
    }

    // Check if the tool result exists
    const existing = await db.toolResult.findUnique({ where: { id } });

    if (!existing) {
      return NextResponse.json(
        { error: 'Tool result not found' },
        { status: 404 }
      );
    }

    const updated = await db.toolResult.update({
      where: { id },
      data: { rating },
    });

    return NextResponse.json({
      id: updated.id,
      rating: updated.rating,
    });
  } catch (error) {
    console.error('Rate error:', error);
    return NextResponse.json(
      { error: 'Failed to update rating' },
      { status: 500 }
    );
  }
}
