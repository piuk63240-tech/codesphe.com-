import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { db } from '@/lib/db';

const SYSTEM_PROMPTS: Record<string, string> = {
  'idea-generator':
    'You are an expert AI SaaS business consultant. Generate innovative, viable AI SaaS business ideas based on the user\'s input. For each idea, provide: 1) Name, 2) One-line description, 3) Target market, 4) Key features (3-5), 5) Revenue model, 6) Competitive advantage, 7) Technical complexity (Low/Medium/High), 8) Estimated time to MVP. Format your response in clear markdown.',

  'prompt-generator':
    'You are an expert prompt engineer. Generate optimized, effective prompts for AI models based on the user\'s requirements. For each prompt, provide: 1) The prompt text, 2) Use case, 3) Expected output format, 4) Tips for customization, 5) Model compatibility. Format your response in clear markdown.',

  'idea-validator':
    'You are a seasoned startup advisor and venture capitalist. Thoroughly validate the given business idea by analyzing: 1) Market size and potential (TAM/SAM/SOM), 2) Problem-solution fit, 3) Competitive landscape, 4) Technical feasibility, 5) Business model viability, 6) Risks and challenges, 7) Go-to-market strategy, 8) Overall viability score (1-10), 9) Key recommendations. Be honest and critical. Format your response in clear markdown.',

  'market-analyzer':
    'You are a market research analyst specializing in the AI and SaaS industries. Analyze the market for the given product/service by providing: 1) Market size estimation, 2) Growth trends, 3) Key market segments, 4) Customer personas, 5) Pricing benchmarks, 6) Market entry barriers, 7) Opportunities, 8) Threats, 9) Market timing assessment. Format your response in clear markdown.',

  'competitor-research':
    'You are a competitive intelligence analyst. Research and analyze competitors in the given market space by providing: 1) Top competitors overview, 2) Feature comparison matrix, 3) Pricing comparison, 4) Market positioning, 5) Strengths and weaknesses, 6) Gaps in the market, 7) Differentiation opportunities, 8) Strategic recommendations. Format your response in clear markdown.',

  'tech-stack-recommender':
    'You are a senior software architect. Recommend the optimal technology stack for building the described SaaS product by providing: 1) Frontend stack with justification, 2) Backend stack with justification, 3) Database recommendations, 4) Infrastructure & deployment, 5) Third-party integrations, 6) DevOps tools, 7) Security considerations, 8) Scalability plan, 9) Estimated development timeline, 10) Cost estimation. Format your response in clear markdown.',

  'business-model-generator':
    'You are a business strategy consultant specializing in SaaS companies. Generate a comprehensive business model for the described product by providing: 1) Value proposition, 2) Customer segments, 3) Revenue streams, 4) Pricing tiers (Freemium/Pro/Enterprise), 5) Cost structure, 6) Key partnerships, 7) Key activities, 8) Key resources, 9) Customer acquisition channels, 10) Unit economics. Format your response in clear markdown.',

  'code-scaffolder':
    'You are an expert full-stack developer. Generate production-ready code scaffolding for the described SaaS application by providing: 1) Project structure, 2) Key configuration files, 3) Database schema, 4) API route templates, 5) Frontend component structure, 6) Authentication setup, 7) Core business logic, 8) Deployment configuration. Use modern best practices (Next.js, TypeScript, Tailwind CSS). Format code blocks with proper language tags.',

  'landing-page-optimizer':
    'You are a conversion rate optimization expert and copywriter. Generate compelling landing page content for the described SaaS product by providing: 1) Hero headline and subheadline, 2) Value propositions (3), 3) Feature descriptions, 4) Social proof section, 5) CTA buttons text, 6) FAQ section, 7) Testimonial templates, 8) Pricing section copy. Format your response in clear markdown.',

  'pitch-deck-generator':
    'You are a startup pitch deck consultant who has helped raise millions in funding. Generate a compelling pitch deck outline for the described SaaS product by providing: 1) Title slide content, 2) Problem statement, 3) Solution overview, 4) Market opportunity, 5) Business model, 6) Traction/milestones, 7) Go-to-market strategy, 8) Competitive advantages, 9) Team, 10) Financial projections, 11) The Ask (funding request). Format your response in clear markdown.',
};

const VALID_TOOL_TYPES = Object.keys(SYSTEM_PROMPTS);

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { toolType, input, regenerationContext } = body;

    if (!toolType || !input) {
      return NextResponse.json(
        { error: 'Missing required fields: toolType and input are required' },
        { status: 400 }
      );
    }

    if (!VALID_TOOL_TYPES.includes(toolType)) {
      return NextResponse.json(
        { error: `Invalid tool type. Must be one of: ${VALID_TOOL_TYPES.join(', ')}` },
        { status: 400 }
      );
    }

    const systemPrompt = SYSTEM_PROMPTS[toolType];

    // Build user message from input
    // Strip internal regeneration keys from input before sending to AI
    const cleanInput = { ...input };
    delete cleanInput._regenerationStyle;
    const inputStr = typeof cleanInput === 'string' ? cleanInput : JSON.stringify(cleanInput, null, 2);

    let regenerationInstruction = '';
    if (regenerationContext === 'same') {
      regenerationInstruction = '\n\nIMPORTANT: The user is regenerating with the same input. Please provide a fresh, equally comprehensive response with different phrasing and potentially different perspectives while covering the same topics.';
    } else if (regenerationContext === 'different-style') {
      regenerationInstruction = '\n\nIMPORTANT: The user wants a different style/approach. Please generate the results using a significantly different approach, tone, or methodology than you typically would. Be creative and offer a fresh perspective.';
    } else if (regenerationContext === 'alternative') {
      regenerationInstruction = '\n\nIMPORTANT: The user wants an alternative take. Please generate a completely different set of results, ideas, or recommendations than you normally would. Think outside the box and provide unique, unexpected insights.';
    }

    const userMessage = `Here are my inputs for this tool:\n\n${inputStr}\n\nPlease generate comprehensive results based on these inputs.${regenerationInstruction}`;

    // Call LLM via z-ai-web-dev-sdk
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: userMessage },
      ],
      thinking: { type: 'disabled' },
    });

    const result = completion.choices?.[0]?.message?.content || '';

    if (!result) {
      return NextResponse.json(
        { error: 'AI model returned an empty response' },
        { status: 502 }
      );
    }

    // Save to database
    let savedId: string | undefined;
    try {
      const saved = await db.toolResult.create({
        data: {
          toolType,
          input: typeof input === 'string' ? input : JSON.stringify(input),
          output: result,
        },
      });
      savedId = saved.id;
    } catch {
      // Database save is optional - don't fail the request
    }

    return NextResponse.json({
      id: savedId,
      result,
      toolType,
    });
  } catch (error) {
    console.error('Generate error:', error);
    return NextResponse.json(
      { error: 'Failed to generate result. Please try again later.' },
      { status: 500 }
    );
  }
}
