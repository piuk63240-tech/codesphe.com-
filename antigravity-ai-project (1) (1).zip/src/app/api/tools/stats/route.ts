import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    // Total generations count
    const totalGenerations = await db.toolResult.count()

    // If no data, return empty stats
    if (totalGenerations === 0) {
      return NextResponse.json({
        totalGenerations: 0,
        totalSavedIdeas: 0,
        generationsPerTool: [],
        generationsPerDay: [],
        averageRatingPerTool: [],
        mostPopularTools: [],
        overallAvgRating: 0,
      })
    }

    // Total saved ideas
    const totalSavedIdeas = await db.savedIdea.count()

    // Generations per tool type
    const generationsPerToolRaw = await db.toolResult.groupBy({
      by: ['toolType'],
      _count: { toolType: true },
      orderBy: { _count: { toolType: 'desc' } },
    })

    const generationsPerTool = generationsPerToolRaw.map((item) => ({
      toolType: item.toolType,
      count: item._count.toolType,
    }))

    // Generations per day for last 7 days
    const sevenDaysAgo = new Date()
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)
    sevenDaysAgo.setHours(0, 0, 0, 0)

    const recentResults = await db.toolResult.findMany({
      where: { createdAt: { gte: sevenDaysAgo } },
      select: { createdAt: true },
    })

    // Group by date
    const dateMap = new Map<string, number>()
    for (let i = 6; i >= 0; i--) {
      const date = new Date()
      date.setDate(date.getDate() - i)
      const dateStr = date.toISOString().split('T')[0]
      dateMap.set(dateStr, 0)
    }

    for (const result of recentResults) {
      const dateStr = result.createdAt.toISOString().split('T')[0]
      if (dateMap.has(dateStr)) {
        dateMap.set(dateStr, (dateMap.get(dateStr) || 0) + 1)
      }
    }

    const generationsPerDay = Array.from(dateMap.entries()).map(
      ([date, count]) => {
        const d = new Date(date + 'T00:00:00')
        const dayLabel = d.toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
        })
        return { date: dayLabel, count }
      }
    )

    // Average rating per tool type
    const ratedResults = await db.toolResult.findMany({
      where: { rating: { not: null } },
      select: { toolType: true, rating: true },
    })

    const ratingMap = new Map<string, { total: number; count: number }>()
    for (const result of ratedResults) {
      const current = ratingMap.get(result.toolType) || {
        total: 0,
        count: 0,
      }
      current.total += result.rating!
      current.count += 1
      ratingMap.set(result.toolType, current)
    }

    const averageRatingPerTool = Array.from(ratingMap.entries()).map(
      ([toolType, data]) => ({
        toolType,
        averageRating: Math.round((data.total / data.count) * 10) / 10,
      })
    )

    // Most popular tools (top 5 by generation count)
    const mostPopularTools = generationsPerTool.slice(0, 5)

    // Overall average rating
    const overallAvgRating =
      ratedResults.length > 0
        ? Math.round(
            (ratedResults.reduce((sum, r) => sum + r.rating!, 0) /
              ratedResults.length) *
              10
          ) / 10
        : 0

    return NextResponse.json({
      totalGenerations,
      totalSavedIdeas,
      generationsPerTool,
      generationsPerDay,
      averageRatingPerTool,
      mostPopularTools,
      overallAvgRating,
    })
  } catch (error) {
    console.error('Error fetching stats:', error)
    return NextResponse.json(
      { error: 'Failed to fetch stats' },
      { status: 500 }
    )
  }
}
