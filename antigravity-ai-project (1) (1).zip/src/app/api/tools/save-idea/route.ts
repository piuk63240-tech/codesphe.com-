import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

interface SaveIdeaBody {
  toolType: string;
  input: Record<string, string>;
  result: string;
  title?: string;
  category?: string;
  notes?: string;
}

export async function POST(request: NextRequest) {
  try {
    const body: SaveIdeaBody = await request.json();
    const { toolType, input, result, title, category, notes } = body;

    if (!toolType || !result) {
      return NextResponse.json(
        { error: 'Missing required fields: toolType and result are required' },
        { status: 400 }
      );
    }

    // Create a title from the tool type and input if not provided
    const ideaTitle =
      title ||
      `${toolType.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())} - ${new Date().toLocaleDateString()}`;

    const ideaDescription = typeof input === 'string' ? input : JSON.stringify(input);

    const savedIdea = await db.savedIdea.create({
      data: {
        title: ideaTitle,
        description: ideaDescription,
        category: category || toolType,
        toolType,
        notes: notes || result.substring(0, 500),
      },
    });

    return NextResponse.json(
      {
        id: savedIdea.id,
        title: savedIdea.title,
        description: savedIdea.description,
        category: savedIdea.category,
        toolType: savedIdea.toolType,
        notes: savedIdea.notes,
        createdAt: savedIdea.createdAt,
        updatedAt: savedIdea.updatedAt,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Save idea error:', error);
    return NextResponse.json(
      { error: 'Failed to save idea' },
      { status: 500 }
    );
  }
}
