import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const SYSTEM_PROMPT = `You are a helpful AI assistant for the Antigravity AI platform. You help users choose the right AI tool for their needs, explain features, and provide guidance on using the platform. Be concise and friendly. The platform has 10 tools: Idea Generator, Prompt Generator, Idea Validator, Market Analyzer, Competitor Research, Tech Stack Recommender, Business Model Generator, Code Scaffolder, Landing Page Optimizer, Pitch Deck Generator.

Here's a brief overview of each tool:
- Idea Generator: Generate innovative AI SaaS business ideas with market analysis
- Prompt Generator: Create optimized prompts for any AI model or use case
- Idea Validator: Validate your business idea with comprehensive AI analysis
- Market Analyzer: Analyze market size, trends, and opportunities
- Competitor Research: Research competitors and find market gaps
- Tech Stack Recommender: Get AI-recommended tech stacks for your project
- Business Model Generator: Generate complete business models and pricing strategies
- Code Scaffolder: Generate production-ready code scaffolding and project structure
- Landing Page Optimizer: Generate high-converting landing page copy
- Pitch Deck Generator: Create compelling pitch deck content for investors`;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { message } = body;

    if (!message || typeof message !== 'string') {
      return NextResponse.json(
        { error: 'Message is required' },
        { status: 400 }
      );
    }

    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: SYSTEM_PROMPT },
        { role: 'user', content: message },
      ],
      thinking: { type: 'disabled' },
    });

    const response = completion.choices?.[0]?.message?.content || '';

    if (!response) {
      return NextResponse.json(
        { error: 'AI model returned an empty response' },
        { status: 502 }
      );
    }

    return NextResponse.json({ response });
  } catch (error) {
    console.error('Chat error:', error);
    return NextResponse.json(
      { error: 'Failed to generate response. Please try again later.' },
      { status: 500 }
    );
  }
}
