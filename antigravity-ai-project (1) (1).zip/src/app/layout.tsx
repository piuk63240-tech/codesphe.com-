import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Antigravity AI - AI-Powered SaaS Tools Platform",
  description:
    "Validate ideas, generate prompts, analyze markets, and build your AI-powered SaaS business with 10 specialized tools.",
  keywords: [
    "AI",
    "SaaS",
    "idea validation",
    "prompt generator",
    "market analysis",
    "business tools",
    "startup tools",
    "AI tools",
  ],
  openGraph: {
    title: "Antigravity AI - AI-Powered SaaS Tools Platform",
    description:
      "Validate ideas, generate prompts, analyze markets, and build your AI-powered SaaS business with 10 specialized tools.",
    type: "website",
    locale: "en_US",
    siteName: "Antigravity AI",
  },
  twitter: {
    card: "summary_large_image",
    title: "Antigravity AI - AI-Powered SaaS Tools Platform",
    description:
      "Validate ideas, generate prompts, analyze markets, and build your AI-powered SaaS business with 10 specialized tools.",
  },
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster position="bottom-right" richColors closeButton />
        </ThemeProvider>
      </body>
    </html>
  );
}
