'use client'

import * as React from 'react'
import { Navbar } from '@/components/navbar'
import { HeroSection } from '@/components/hero-section'
import { ToolsGrid, tools, type ToolConfig } from '@/components/tools-grid'
import { ToolModal } from '@/components/tool-modal'
import { HistoryPanel } from '@/components/history-panel'
import { FeaturesSection } from '@/components/features-section'
import { HowItWorks } from '@/components/how-it-works'
import { PopularToolsSection } from '@/components/popular-tools-section'
import { AnalyticsSection } from '@/components/analytics-section'
import { CtaSection } from '@/components/cta-section'
import { TestimonialsSection } from '@/components/testimonials-section'
import { Footer } from '@/components/footer'
import { CommandPalette } from '@/components/command-palette'
import { ScrollToTop } from '@/components/scroll-to-top'
import { AiChatWidget } from '@/components/ai-chat-widget'
import { PricingSection } from '@/components/pricing-section'
import { FaqSection } from '@/components/faq-section'
import { KeyboardShortcutsDialog } from '@/components/keyboard-shortcuts-dialog'
import { SectionDivider } from '@/components/section-divider'
import { RecentActivity } from '@/components/recent-activity'
import { OnboardingModal, shouldShowOnboarding } from '@/components/onboarding-modal'
import { ScrollReveal } from '@/components/scroll-reveal'
import { ScrollProgress } from '@/components/scroll-progress'

interface HistoryItem {
  id: string
  toolType: string
  input: string
  output: string
  rating: number | null
  createdAt: string
}

export default function Home() {
  const [selectedTool, setSelectedTool] = React.useState<ToolConfig | null>(
    null
  )
  const [modalOpen, setModalOpen] = React.useState(false)
  const [historyOpen, setHistoryOpen] = React.useState(false)
  const [commandPaletteOpen, setCommandPaletteOpen] = React.useState(false)
  const [shortcutsOpen, setShortcutsOpen] = React.useState(false)
  const [onboardingOpen, setOnboardingOpen] = React.useState(false)
  const [onboardingChecked, setOnboardingChecked] = React.useState(false)

  // Check localStorage for onboarding on mount
  React.useEffect(() => {
    if (shouldShowOnboarding()) {
      // Small delay so the page loads first
      const timer = setTimeout(() => setOnboardingOpen(true), 1500)
      return () => clearTimeout(timer)
    }
    setOnboardingChecked(true)
  }, [])

  // Mark onboarding as checked when it closes
  const handleOnboardingOpenChange = (open: boolean) => {
    setOnboardingOpen(open)
    if (!open) {
      setOnboardingChecked(true)
    }
  }

  // Handle "Try a tool" from onboarding
  const handleOnboardingTryTool = () => {
    const ideaGenerator = tools.find((t) => t.id === 'idea-generator')
    if (ideaGenerator) {
      setSelectedTool(ideaGenerator)
      setModalOpen(true)
    }
  }

  // Global keyboard listener for ⌘/ or Ctrl+/
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === '/') {
        e.preventDefault()
        setShortcutsOpen(true)
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  const handleToolClick = (tool: ToolConfig) => {
    setSelectedTool(tool)
    setModalOpen(true)
  }

  const handleCloseModal = () => {
    setModalOpen(false)
    // Delay clearing tool so modal animation can complete
    setTimeout(() => setSelectedTool(null), 200)
  }

  const handleCommandToolSelect = (toolId: string) => {
    const tool = tools.find((t) => t.id === toolId)
    if (tool) {
      setSelectedTool(tool)
      setModalOpen(true)
    }
  }

  // Handle viewing a result from recent activity
  const handleViewResult = (item: HistoryItem) => {
    const tool = tools.find((t) => t.id === item.toolType)
    if (tool) {
      setSelectedTool(tool)
      setModalOpen(true)
    }
  }

  return (
    <div className="min-h-screen flex flex-col gradient-mesh-bg noise-overlay">
      <a href="#main-content" className="skip-to-content">
        Skip to content
      </a>
      <ScrollProgress />
      <div className="relative z-10 flex flex-col min-h-screen">
      <Navbar
        onHistoryClick={() => setHistoryOpen(true)}
        onCommandPaletteOpen={() => setCommandPaletteOpen(true)}
      />
      <main id="main-content" className="flex-1">
        <HeroSection />
        <SectionDivider variant="wave" />
        <ScrollReveal variant="fade-up" duration={0.5}>
          <RecentActivity onViewResult={handleViewResult} onViewAll={() => setHistoryOpen(true)} />
        </ScrollReveal>
        <SectionDivider variant="gradient" />
        <ScrollReveal variant="scale-up" duration={0.6}>
          <ToolsGrid onToolClick={handleToolClick} />
        </ScrollReveal>
        <SectionDivider variant="dots" />
        <ScrollReveal variant="fade-up" duration={0.6}>
          <PopularToolsSection onToolClick={handleToolClick} />
        </ScrollReveal>
        <SectionDivider variant="wave" />
        <ScrollReveal variant="fade-up" duration={0.6}>
          <AnalyticsSection />
        </ScrollReveal>
        <SectionDivider variant="gradient" />
        <ScrollReveal variant="fade-up" duration={0.5}>
          <FeaturesSection />
        </ScrollReveal>
        <SectionDivider variant="dots" />
        <ScrollReveal variant="fade-up" duration={0.6}>
          <HowItWorks />
        </ScrollReveal>
        <SectionDivider variant="wave" />
        <ScrollReveal variant="slide-left" duration={0.6}>
          <TestimonialsSection />
        </ScrollReveal>
        <SectionDivider variant="gradient" />
        <ScrollReveal variant="scale-up" duration={0.6}>
          <PricingSection />
        </ScrollReveal>
        <SectionDivider variant="dots" />
        <ScrollReveal variant="fade-up" duration={0.5}>
          <FaqSection />
        </ScrollReveal>
        <SectionDivider variant="wave" />
        <ScrollReveal variant="rotate-in" duration={0.7}>
          <CtaSection />
        </ScrollReveal>
      </main>
      <ScrollReveal variant="fade-up" duration={0.5}>
        <Footer />
      </ScrollReveal>
      <ToolModal
        tool={selectedTool}
        open={modalOpen}
        onClose={handleCloseModal}
      />
      <HistoryPanel open={historyOpen} onOpenChange={setHistoryOpen} />
      <CommandPalette
        open={commandPaletteOpen}
        onOpenChange={setCommandPaletteOpen}
        onToolSelect={handleCommandToolSelect}
      />
      <KeyboardShortcutsDialog
        open={shortcutsOpen}
        onOpenChange={setShortcutsOpen}
      />
      <OnboardingModal
        open={onboardingOpen}
        onOpenChange={handleOnboardingOpenChange}
        onTryTool={handleOnboardingTryTool}
      />
      <AiChatWidget />
      <ScrollToTop />
      </div>
    </div>
  )
}
