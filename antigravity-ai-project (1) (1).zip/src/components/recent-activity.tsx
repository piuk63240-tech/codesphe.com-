'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Clock,
  Eye,
  Filter,
  Star,
  BarChart3,
  ChevronRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Tooltip,
  TooltipTrigger,
  TooltipContent,
  TooltipProvider,
} from '@/components/ui/tooltip'
import { tools, type ToolConfig } from '@/components/tools-grid'

interface HistoryItem {
  id: string
  toolType: string
  input: string
  output: string
  rating: number | null
  createdAt: string
}

const TOOL_CATEGORIES = [
  'All',
  'Ideation',
  'Content',
  'Validation',
  'Research',
  'Development',
  'Strategy',
  'Marketing',
] as const

type ToolCategoryFilter = (typeof TOOL_CATEGORIES)[number]

function getRelativeTime(dateStr: string): string {
  const date = new Date(dateStr)
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffSeconds = Math.floor(diffMs / 1000)
  const diffMinutes = Math.floor(diffSeconds / 60)
  const diffHours = Math.floor(diffMinutes / 60)
  const diffDays = Math.floor(diffHours / 24)

  if (diffSeconds < 60) return 'just now'
  if (diffMinutes < 60) return `${diffMinutes}m ago`
  if (diffHours < 24) return `${diffHours}h ago`
  if (diffDays < 7) return `${diffDays}d ago`
  return date.toLocaleDateString()
}

function isLessThan5Min(dateStr: string): boolean {
  const date = new Date(dateStr)
  const now = new Date()
  return now.getTime() - date.getTime() < 5 * 60 * 1000
}

function isLessThan1Hour(dateStr: string): boolean {
  const date = new Date(dateStr)
  const now = new Date()
  return now.getTime() - date.getTime() < 60 * 60 * 1000
}

function getCategoryForTool(toolType: string): string {
  const tool = tools.find((t) => t.id === toolType)
  return tool?.category || 'Other'
}

// Field key to human-readable label mapping
const FIELD_LABELS: Record<string, string> = {
  industry: 'Industry',
  focusArea: 'Focus Area',
  budget: 'Budget',
  timeline: 'Timeline',
  purpose: 'Purpose',
  aiModel: 'AI Model',
  style: 'Style',
  context: 'Context',
  ideaName: 'Idea Name',
  ideaDescription: 'Description',
  targetMarket: 'Target Market',
  currentStage: 'Stage',
  product: 'Product',
  region: 'Region',
  targetAudience: 'Audience',
  marketSpace: 'Market Space',
  productType: 'Product Type',
  productDescription: 'Description',
  teamSize: 'Team Size',
  scaleRequirements: 'Scale',
  productName: 'Product Name',
  pricingPreference: 'Pricing',
  appDescription: 'App Description',
  techPreferences: 'Tech Preferences',
  features: 'Features',
  scale: 'Scale',
  tone: 'Tone',
  companyName: 'Company',
  fundingStage: 'Funding Stage',
  marketSize: 'Market Size',
  _regenerationStyle: 'Style',
}

// Format a JSON input string into a human-readable summary
function formatInputSummary(inputStr: string): string {
  try {
    const parsed = JSON.parse(inputStr)
    if (typeof parsed !== 'object' || parsed === null) {
      return inputStr.substring(0, 80)
    }
    const parts = Object.entries(parsed)
      .filter(([key, value]) => value && String(value).trim() && !key.startsWith('_'))
      .slice(0, 4)
      .map(([key, value]) => {
        const label = FIELD_LABELS[key] || key.replace(/([A-Z])/g, ' $1').replace(/^./, (s) => s.toUpperCase())
        let displayValue = String(value)
          .replace(/-/g, ' ')
          .replace(/\b\w/g, (c) => c.toUpperCase())
        if (displayValue.length > 20) displayValue = displayValue.substring(0, 18) + '…'
        return `${label}: ${displayValue}`
      })
    return parts.length > 0 ? parts.join(' · ') : 'No details'
  } catch {
    return inputStr.substring(0, 80)
  }
}

// Shimmer skeleton for loading state
function ActivitySkeleton() {
  return (
    <div className="relative mb-3 last:mb-0">
      <div className="absolute -left-6 top-3.5 flex items-center justify-center">
        <Skeleton className="size-[22px] rounded-full" />
      </div>
      <div className="ml-2 rounded-xl border bg-background/60 p-3">
        <div className="flex items-center gap-3">
          <div className="flex-1 min-w-0 space-y-2">
            <div className="flex items-center gap-2">
              <Skeleton className="h-4 w-28" />
              <Skeleton className="h-4 w-14 rounded-full" />
            </div>
            <Skeleton className="h-3 w-3/4" />
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Skeleton className="h-3 w-12" />
          </div>
        </div>
      </div>
    </div>
  )
}

// Mini sparkline SVG component for the title
function MiniSparkline() {
  return (
    <svg width="18" height="14" viewBox="0 0 18 14" fill="none" className="shrink-0">
      <path
        d="M1 10 L4 7 L7 9 L10 3 L13 6 L16 1"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-emerald-500"
      />
      <path
        d="M1 10 L4 7 L7 9 L10 3 L13 6 L16 1"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-emerald-500/30"
        strokeDasharray="2 2"
      />
    </svg>
  )
}

interface RecentActivityProps {
  onViewResult?: (item: HistoryItem) => void
  onViewAll?: () => void
}

export function RecentActivity({ onViewResult, onViewAll }: RecentActivityProps) {
  const [activities, setActivities] = React.useState<HistoryItem[]>([])
  const [loading, setLoading] = React.useState(true)
  const [activeFilter, setActiveFilter] = React.useState<ToolCategoryFilter>('All')
  const [expandedId, setExpandedId] = React.useState<string | null>(null)

  const fetchActivities = React.useCallback(async () => {
    try {
      const res = await fetch('/api/tools/history?limit=10')
      if (res.ok) {
        const data = await res.json()
        setActivities(data.results || [])
      }
    } catch {
      // Silently fail
    } finally {
      setLoading(false)
    }
  }, [])

  React.useEffect(() => {
    fetchActivities()
    const interval = setInterval(fetchActivities, 30000)
    return () => clearInterval(interval)
  }, [fetchActivities])

  const getToolConfig = (toolType: string) => {
    return tools.find((t) => t.id === toolType)
  }

  // Filter activities by category
  const filteredActivities =
    activeFilter === 'All'
      ? activities
      : activities.filter((a) => getCategoryForTool(a.toolType) === activeFilter)

  return (
    <section className="py-6">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-xl border bg-card/50 backdrop-blur-sm p-6 overflow-hidden">
          {/* Subtle gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/[0.03] via-transparent to-teal-500/[0.03] dark:from-emerald-500/[0.05] dark:via-transparent dark:to-teal-500/[0.05] pointer-events-none" />

          {/* Section header with filter */}
          <div className="relative flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Clock className="size-4 text-emerald-500" />
              <h3 className="text-sm font-semibold text-foreground">
                Recent Activity
              </h3>
              <MiniSparkline />
              {activities.length > 0 && (
                <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                  {activities.length}
                </span>
              )}
            </div>

            {/* Filter dropdown for mobile */}
            <div className="flex items-center gap-2">
              <Filter className="size-3.5 text-muted-foreground" />
              <div className="flex flex-wrap gap-1">
                {TOOL_CATEGORIES.filter(
                  (cat) =>
                    cat === 'All' ||
                    activities.some(
                      (a) => getCategoryForTool(a.toolType) === cat
                    )
                ).map((category) => (
                  <Button
                    key={category}
                    variant={activeFilter === category ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setActiveFilter(category)}
                    className={`text-[10px] h-6 px-2 rounded-full ${
                      activeFilter === category
                        ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                    aria-label={`Filter by ${category}`}
                    aria-pressed={activeFilter === category}
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {/* Timeline Activity Feed */}
          {loading ? (
            <div className="relative pl-6">
              {Array.from({ length: 4 }).map((_, i) => (
                <ActivitySkeleton key={i} />
              ))}
            </div>
          ) : filteredActivities.length === 0 ? (
            <div className="flex items-center gap-2 py-8 text-muted-foreground justify-center">
              <Clock className="size-5 opacity-40" />
              <span className="text-sm">
                {activeFilter === 'All'
                  ? 'No recent activity'
                  : `No activity in ${activeFilter}`}
              </span>
            </div>
          ) : (
            <div className="relative pl-6">
              {/* Timeline connecting line */}
              <div className="absolute left-[11px] top-2 bottom-2 w-0.5 bg-gradient-to-b from-emerald-500/40 via-emerald-500/20 to-transparent" />

              <TooltipProvider>
                <AnimatePresence mode="popLayout">
                  {filteredActivities.map((activity, index) => {
                    const toolConfig = getToolConfig(activity.toolType)
                    const Icon = toolConfig?.icon || Clock
                    const iconBg =
                      toolConfig?.iconBg ||
                      'bg-gradient-to-br from-emerald-500 to-teal-500'
                    const name = toolConfig?.name || activity.toolType
                    const recent = isLessThan5Min(activity.createdAt)
                    const isRecentHour = isLessThan1Hour(activity.createdAt)
                    const isExpanded = expandedId === activity.id

                    return (
                      <motion.div
                        key={activity.id}
                        layout
                        initial={{ opacity: 0, x: -20, height: 0 }}
                        animate={{ opacity: 1, x: 0, height: 'auto' }}
                        exit={{ opacity: 0, x: -20, height: 0 }}
                        transition={{
                          duration: 0.3,
                          delay: index * 0.05,
                          layout: { duration: 0.2 },
                        }}
                        className="relative mb-3 last:mb-0"
                      >
                        {/* Timeline dot with pulse for recent items */}
                        <div className="absolute -left-6 top-3.5 flex items-center justify-center">
                          <div
                            className={`size-[22px] rounded-full ${iconBg} flex items-center justify-center shadow-sm border-2 border-background z-10`}
                          >
                            <Icon className="size-2.5 text-white" />
                          </div>
                          {/* Pulse ring for very recent items */}
                          {recent && (
                            <span className="absolute inset-0 rounded-full animate-ping bg-emerald-400/30" />
                          )}
                        </div>

                        {/* Activity card */}
                        <div
                          className={`ml-2 rounded-xl border bg-background/60 backdrop-blur-sm p-3 transition-all duration-300 cursor-pointer group ${
                            isExpanded
                              ? 'border-emerald-500/30 shadow-md shadow-emerald-500/5'
                              : 'border-border/50 hover:border-emerald-500/20 hover:shadow-lg hover:-translate-y-0.5 hover:bg-background/80'
                          }`}
                          onClick={() =>
                            setExpandedId(isExpanded ? null : activity.id)
                          }
                          role="button"
                          tabIndex={0}
                          aria-label={`${name} activity - ${getRelativeTime(activity.createdAt)}`}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              e.preventDefault()
                              setExpandedId(isExpanded ? null : activity.id)
                            }
                          }}
                        >
                          <div className="flex items-center gap-3">
                            {/* Tool info */}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-semibold text-foreground truncate">
                                  {name}
                                </span>
                                {/* Category badge */}
                                {toolConfig && (
                                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 font-medium shrink-0">
                                    {toolConfig.category}
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground truncate mt-0.5">
                                {typeof activity.input === 'string'
                                  ? formatInputSummary(activity.input)
                                  : formatInputSummary(JSON.stringify(activity.input))}
                              </p>
                            </div>

                            {/* Timestamp */}
                            <div className="flex items-center gap-2 shrink-0">
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <span className="text-xs text-muted-foreground">
                                    {getRelativeTime(activity.createdAt)}
                                  </span>
                                </TooltipTrigger>
                                <TooltipContent side="top">
                                  <p>
                                    {new Date(
                                      activity.createdAt
                                    ).toLocaleString()}
                                  </p>
                                </TooltipContent>
                              </Tooltip>

                              {/* Rating if available */}
                              {activity.rating && (
                                <div className="flex items-center gap-0.5">
                                  <Star className="size-3 fill-amber-400 text-amber-400" />
                                  <span className="text-[10px] text-amber-600 dark:text-amber-400 font-medium">
                                    {activity.rating}
                                  </span>
                                </div>
                              )}

                              {/* Pulse dot for recent items */}
                              {isRecentHour && (
                                <span className="relative flex size-2 shrink-0">
                                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                                  <span className="relative inline-flex rounded-full size-2 bg-emerald-500" />
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Expanded content */}
                          <AnimatePresence>
                            {isExpanded && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                exit={{ opacity: 0, height: 0 }}
                                transition={{ duration: 0.2 }}
                                className="overflow-hidden"
                              >
                                <div className="mt-3 pt-3 border-t border-border/50">
                                  {/* Output preview */}
                                  <p className="text-xs text-muted-foreground leading-relaxed mb-3 max-h-32 overflow-y-auto custom-scrollbar">
                                    {activity.output.substring(0, 300)}
                                    {activity.output.length > 300 && '...'}
                                  </p>

                                  {/* Actions */}
                                  <div className="flex items-center gap-2">
                                    {onViewResult && (
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={(e) => {
                                          e.stopPropagation()
                                          onViewResult(activity)
                                        }}
                                        className="text-xs border-emerald-500/30 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:text-emerald-600 dark:hover:text-emerald-400"
                                      >
                                        <Eye className="size-3.5 mr-1.5" />
                                        View Result
                                      </Button>
                                    )}
                                  </div>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      </motion.div>
                    )
                  })}
                </AnimatePresence>
              </TooltipProvider>
            </div>
          )}

          {/* View All button */}
          {activities.length > 0 && (
            <div className="relative mt-4 pt-3 border-t border-border/30 flex justify-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={onViewAll}
                className="text-xs text-muted-foreground hover:text-emerald-600 dark:hover:text-emerald-400 gap-1 group/btn"
                aria-label="View all activity history"
              >
                <BarChart3 className="size-3.5" />
                View All Activity
                <ChevronRight className="size-3 transition-transform group-hover/btn:translate-x-0.5" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </section>
  )
}
