'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { MousePointerClick, Cpu, Rocket } from 'lucide-react'

const steps = [
  {
    step: 1,
    icon: MousePointerClick,
    title: 'Choose a Tool',
    description:
      'Select from 10 specialized AI tools designed for different stages of your SaaS journey — from ideation to launch.',
  },
  {
    step: 2,
    icon: Cpu,
    title: 'Provide Your Input',
    description:
      'Fill in the details about your idea, market, or project. Our AI uses this context to generate tailored results.',
  },
  {
    step: 3,
    icon: Rocket,
    title: 'Get AI Results',
    description:
      'Receive comprehensive, actionable insights in seconds. Save, rate, and iterate on your results to refine your strategy.',
  },
]

export function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            How It <span className="animated-gradient-text">Works</span>
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            Three simple steps to transform your SaaS ideas into reality.
          </p>
        </motion.div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-12">
          {steps.map((stepData, index) => {
            const Icon = stepData.icon
            return (
              <motion.div
                key={stepData.step}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
                className="relative text-center group"
              >
                {/* Connector line with flowing gradient (hidden on mobile and last item) */}
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-12 left-[60%] w-[80%] h-[2px] overflow-hidden">
                    <div
                      className="w-full h-full animate-flow"
                      style={{
                        background:
                          'repeating-linear-gradient(90deg, transparent, transparent 4px, #10b981 4px, #10b981 8px)',
                        backgroundSize: '200% 100%',
                      }}
                    />
                  </div>
                )}

                {/* Step Number Circle */}
                <div className="mx-auto mb-6 relative">
                  {/* Glow effect behind the circle */}
                  <div className="absolute inset-0 flex size-24 mx-auto items-center justify-center rounded-full bg-emerald-400/20 dark:bg-emerald-500/10 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700" />

                  <div className="relative flex size-24 items-center justify-center rounded-full bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-900/20 dark:to-teal-900/20 border-2 border-emerald-200 dark:border-emerald-800/50 mx-auto group-hover:from-emerald-100 group-hover:to-teal-100 dark:group-hover:from-emerald-900/40 dark:group-hover:to-teal-900/40 group-hover:border-emerald-300 dark:group-hover:border-emerald-700/60 transition-all duration-500">
                    <Icon className="size-10 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  {/* Number badge with rotating gradient background */}
                  <div className="absolute -top-2 -right-2 flex size-8 items-center justify-center rounded-full text-white text-sm font-bold shadow-lg shadow-emerald-500/25 md:right-auto md:left-1/2 md:-translate-x-1/2 md:top-auto md:-bottom-2 group-hover:shadow-emerald-500/40 transition-shadow duration-300 overflow-hidden">
                    <div className="absolute inset-0 animate-rotate-gradient bg-gradient-to-br from-emerald-400 via-teal-500 to-emerald-600" />
                    <span className="relative z-10">{stepData.step}</span>
                  </div>
                </div>

                <h3 className="text-xl font-semibold text-foreground mb-3 group-hover:text-emerald-700 dark:group-hover:text-emerald-300 transition-colors duration-300">
                  {stepData.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed max-w-xs mx-auto">
                  {stepData.description}
                </p>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
