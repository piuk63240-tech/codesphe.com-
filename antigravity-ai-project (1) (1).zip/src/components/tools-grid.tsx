'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Lightbulb,
  MessageSquareCode,
  ShieldCheck,
  TrendingUp,
  Search,
  Layers,
  DollarSign,
  Code2,
  Layout,
  Presentation,
  GitCompareArrows,
  Pin,
} from 'lucide-react'
import { ToolCard, type ToolConfig } from '@/components/tool-card'

// Re-export ToolConfig for convenience (other components import from here)
export type { ToolConfig }
import { ToolComparison } from '@/components/tool-comparison'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { useFavoritesStore } from '@/store/app-store'

export const tools: ToolConfig[] = [
  {
    id: 'idea-generator',
    name: 'Idea Generator',
    description:
      'Generate innovative AI SaaS business ideas with market analysis',
    icon: Lightbulb,
    category: 'Ideation',
    difficulty: 'Beginner',
    gradient:
      'bg-gradient-to-br from-amber-500/5 to-orange-500/5 dark:from-amber-500/10 dark:to-orange-500/10',
    iconBg: 'bg-gradient-to-br from-amber-500 to-orange-500',
  },
  {
    id: 'prompt-generator',
    name: 'Prompt Generator',
    description: 'Create optimized prompts for any AI model or use case',
    icon: MessageSquareCode,
    category: 'Content',
    difficulty: 'Beginner',
    gradient:
      'bg-gradient-to-br from-emerald-500/5 to-teal-500/5 dark:from-emerald-500/10 dark:to-teal-500/10',
    iconBg: 'bg-gradient-to-br from-emerald-500 to-teal-500',
  },
  {
    id: 'idea-validator',
    name: 'Idea Validator',
    description:
      'Validate your business idea with comprehensive AI analysis',
    icon: ShieldCheck,
    category: 'Validation',
    difficulty: 'Intermediate',
    gradient:
      'bg-gradient-to-br from-green-500/5 to-emerald-500/5 dark:from-green-500/10 dark:to-emerald-500/10',
    iconBg: 'bg-gradient-to-br from-green-500 to-emerald-600',
  },
  {
    id: 'market-analyzer',
    name: 'Market Analyzer',
    description: 'Analyze market size, trends, and opportunities',
    icon: TrendingUp,
    category: 'Research',
    difficulty: 'Intermediate',
    gradient:
      'bg-gradient-to-br from-cyan-500/5 to-teal-500/5 dark:from-cyan-500/10 dark:to-teal-500/10',
    iconBg: 'bg-gradient-to-br from-cyan-500 to-teal-500',
  },
  {
    id: 'competitor-research',
    name: 'Competitor Research',
    description: 'Research competitors and find market gaps',
    icon: Search,
    category: 'Research',
    difficulty: 'Intermediate',
    gradient:
      'bg-gradient-to-br from-violet-500/5 to-purple-500/5 dark:from-violet-500/10 dark:to-purple-500/10',
    iconBg: 'bg-gradient-to-br from-violet-500 to-purple-500',
  },
  {
    id: 'tech-stack-recommender',
    name: 'Tech Stack Recommender',
    description:
      'Get AI-recommended tech stacks for your project',
    icon: Layers,
    category: 'Development',
    difficulty: 'Advanced',
    gradient:
      'bg-gradient-to-br from-rose-500/5 to-pink-500/5 dark:from-rose-500/10 dark:to-pink-500/10',
    iconBg: 'bg-gradient-to-br from-rose-500 to-pink-500',
  },
  {
    id: 'business-model-generator',
    name: 'Business Model Generator',
    description:
      'Generate complete business models and pricing strategies',
    icon: DollarSign,
    category: 'Strategy',
    difficulty: 'Intermediate',
    gradient:
      'bg-gradient-to-br from-emerald-500/5 to-green-500/5 dark:from-emerald-500/10 dark:to-green-500/10',
    iconBg: 'bg-gradient-to-br from-emerald-500 to-green-600',
  },
  {
    id: 'code-scaffolder',
    name: 'Code Scaffolder',
    description:
      'Generate production-ready code scaffolding and project structure',
    icon: Code2,
    category: 'Development',
    difficulty: 'Advanced',
    gradient:
      'bg-gradient-to-br from-teal-500/5 to-cyan-500/5 dark:from-teal-500/10 dark:to-cyan-500/10',
    iconBg: 'bg-gradient-to-br from-teal-500 to-cyan-500',
  },
  {
    id: 'landing-page-optimizer',
    name: 'Landing Page Optimizer',
    description: 'Generate high-converting landing page copy',
    icon: Layout,
    category: 'Marketing',
    difficulty: 'Beginner',
    gradient:
      'bg-gradient-to-br from-sky-500/5 to-blue-500/5 dark:from-sky-500/10 dark:to-blue-500/10',
    iconBg: 'bg-gradient-to-br from-sky-500 to-blue-500',
  },
  {
    id: 'pitch-deck-generator',
    name: 'Pitch Deck Generator',
    description:
      'Create compelling pitch deck content for investors',
    icon: Presentation,
    category: 'Strategy',
    difficulty: 'Advanced',
    gradient:
      'bg-gradient-to-br from-orange-500/5 to-red-500/5 dark:from-orange-500/10 dark:to-red-500/10',
    iconBg: 'bg-gradient-to-br from-orange-500 to-red-500',
  },
]

const categories = [
  'All',
  'Favorites',
  'Ideation',
  'Content',
  'Validation',
  'Research',
  'Development',
  'Strategy',
  'Marketing',
] as const

type Category = (typeof categories)[number]

function ToolCardSkeleton() {
  return (
    <div className="rounded-xl border bg-card p-6">
      <div className="flex items-start justify-between mb-4">
        <Skeleton className="size-12 rounded-lg" />
        <Skeleton className="h-5 w-16 rounded-full" />
      </div>
      <Skeleton className="h-5 w-3/4 mb-2" />
      <Skeleton className="h-4 w-full mb-1" />
      <Skeleton className="h-4 w-2/3" />
    </div>
  )
}

/** Compact card for favorited tools shown in the top section */
function CompactFavoriteCard({ tool, onClick }: { tool: ToolConfig; onClick: (tool: ToolConfig) => void }) {
  const Icon = tool.icon
  return (
    <motion.button
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.97 }}
      onClick={() => onClick(tool)}
      className="flex items-center gap-2.5 rounded-lg border border-emerald-500/20 bg-card/80 backdrop-blur-sm px-3 py-2 shadow-sm hover:shadow-md hover:border-emerald-500/40 transition-all duration-200 cursor-pointer text-left"
      aria-label={`Open ${tool.name} tool`}
    >
      <div
        className={`flex size-8 items-center justify-center rounded-md ${tool.iconBg} shrink-0`}
      >
        <Icon className="size-4 text-white" />
      </div>
      <div className="min-w-0">
        <p className="text-sm font-medium text-foreground truncate">{tool.name}</p>
        <p className="text-[11px] text-muted-foreground truncate">{tool.category}</p>
      </div>
      <Pin className="size-3 text-emerald-500 fill-emerald-500 dark:text-emerald-400 dark:fill-emerald-400 shrink-0 ml-auto" />
    </motion.button>
  )
}

interface ToolsGridProps {
  onToolClick: (tool: ToolConfig) => void
  loading?: boolean
}

export function ToolsGrid({ onToolClick, loading = false }: ToolsGridProps) {
  const [activeCategory, setActiveCategory] = React.useState<Category>('All')
  const [showComparison, setShowComparison] = React.useState(false)
  const { favorites, hydrate: hydrateFavorites } = useFavoritesStore()

  // Hydrate store from localStorage on mount
  React.useEffect(() => {
    hydrateFavorites()
  }, [hydrateFavorites])

  // Get favorited tools
  const favoriteTools = tools.filter((t) => favorites.includes(t.id))

  const filteredTools = (() => {
    if (activeCategory === 'All') return tools
    if (activeCategory === 'Favorites') return favoriteTools
    return tools.filter((tool) => tool.category === activeCategory)
  })()

  return (
    <section id="tools" className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Powerful AI Tools at Your Fingertips
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            10 specialized AI tools to help you ideate, validate, build, and
            launch your SaaS business faster than ever.
          </p>
        </motion.div>

        {/* Favorites Quick Access Section */}
        <AnimatePresence>
          {favoriteTools.length > 0 && activeCategory !== 'Favorites' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="mb-8 overflow-hidden"
            >
              <div className="flex items-center gap-2 mb-3">
                <Pin className="size-4 text-emerald-500 fill-emerald-500 dark:text-emerald-400 dark:fill-emerald-400" />
                <h3 className="text-sm font-semibold text-foreground">
                  Pinned Favorites
                </h3>
                <span className="text-xs text-muted-foreground">
                  ({favoriteTools.length})
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                <AnimatePresence mode="popLayout">
                  {favoriteTools.map((tool) => (
                    <CompactFavoriteCard key={tool.id} tool={tool} onClick={onToolClick} />
                  ))}
                </AnimatePresence>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Category Filter Tabs + Compare Button */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="flex flex-wrap items-center justify-center gap-2 mb-10"
        >
          {categories.map((category) => {
            const isActive = activeCategory === category
            const count = (() => {
              if (category === 'All') return tools.length
              if (category === 'Favorites') return favoriteTools.length
              return tools.filter((t) => t.category === category).length
            })()

            const isMuted = category === 'Favorites' && favoriteTools.length === 0

            return (
              <Button
                key={category}
                variant={isActive ? 'default' : 'outline'}
                size="sm"
                onClick={() => setActiveCategory(category)}
                aria-label={`Filter by ${category} category`}
                aria-pressed={isActive}
                className={`rounded-full transition-all duration-200 ${
                  isActive
                    ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/25'
                    : isMuted
                    ? 'opacity-50 hover:opacity-80 hover:border-emerald-300 dark:hover:border-emerald-700 hover:text-emerald-600 dark:hover:text-emerald-400'
                    : 'hover:border-emerald-300 dark:hover:border-emerald-700 hover:text-emerald-600 dark:hover:text-emerald-400'
                }`}
              >
                {category === 'Favorites' && (
                  <Pin className="size-3 mr-1" />
                )}
                {category}
                <span
                  className={`ml-1.5 text-xs ${
                    isActive
                      ? 'text-emerald-100'
                      : 'text-muted-foreground'
                  }`}
                >
                  {count}
                </span>
              </Button>
            )
          })}
          {/* Compare Button */}
          <Button
            variant={showComparison ? 'default' : 'outline'}
            size="sm"
            onClick={() => setShowComparison(!showComparison)}
            aria-label="Compare tools"
            className={`rounded-full transition-all duration-200 gap-1.5 ${
              showComparison
                ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/25'
                : 'hover:border-emerald-300 dark:hover:border-emerald-700 hover:text-emerald-600 dark:hover:text-emerald-400'
            }`}
          >
            <GitCompareArrows className="size-3.5" />
            Compare
          </Button>
        </motion.div>

        {/* Tool Comparison View */}
        <AnimatePresence>
          {showComparison && (
            <ToolComparison onClose={() => setShowComparison(false)} />
          )}
        </AnimatePresence>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 sm:gap-6">
          {loading ? (
            Array.from({ length: 10 }).map((_, i) => (
              <ToolCardSkeleton key={`skeleton-${i}`} />
            ))
          ) : (
            <AnimatePresence mode="popLayout">
              {filteredTools.map((tool, index) => (
                <motion.div
                  key={tool.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{
                    duration: 0.3,
                    delay: index * 0.04,
                    layout: { duration: 0.3 },
                  }}
                >
                  <ToolCard
                    tool={tool}
                    index={0}
                    onClick={onToolClick}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          )}
        </div>

        {/* Empty state for filtered results */}
        {!loading && filteredTools.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <Pin className="size-10 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-muted-foreground">
              {activeCategory === 'Favorites'
                ? 'No pinned tools yet. Hover over a tool card and click the pin icon to add favorites.'
                : 'No tools found in this category.'}
            </p>
          </motion.div>
        )}
      </div>
    </section>
  )
}
