'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import ReactMarkdown from 'react-markdown'
import {
  GitCompareArrows,
  ChevronDown,
  Loader2,
  ArrowLeftRight,
  Eye,
  GitMerge,
  Inbox,
} from 'lucide-react'
import { toast } from 'sonner'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'

// Tool name map for display
const toolNameMap: Record<string, string> = {
  'idea-generator': 'Idea Generator',
  'prompt-generator': 'Prompt Generator',
  'idea-validator': 'Idea Validator',
  'market-analyzer': 'Market Analyzer',
  'competitor-research': 'Competitor Research',
  'tech-stack-recommender': 'Tech Stack Recommender',
  'business-model-generator': 'Business Model Generator',
  'code-scaffolder': 'Code Scaffolder',
  'landing-page-optimizer': 'Landing Page Optimizer',
  'pitch-deck-generator': 'Pitch Deck Generator',
}

// Tool accent colors
const toolAccentMap: Record<string, string> = {
  'idea-generator': 'text-amber-600 dark:text-amber-400',
  'prompt-generator': 'text-emerald-600 dark:text-emerald-400',
  'idea-validator': 'text-green-600 dark:text-green-400',
  'market-analyzer': 'text-cyan-600 dark:text-cyan-400',
  'competitor-research': 'text-violet-600 dark:text-violet-400',
  'tech-stack-recommender': 'text-rose-600 dark:text-rose-400',
  'business-model-generator': 'text-emerald-600 dark:text-emerald-400',
  'code-scaffolder': 'text-teal-600 dark:text-teal-400',
  'landing-page-optimizer': 'text-sky-600 dark:text-sky-400',
  'pitch-deck-generator': 'text-orange-600 dark:text-orange-400',
}

interface HistoryItem {
  id: string
  toolType: string
  input: string | Record<string, string>
  output: string
  rating: number | null
  createdAt: string
}

// Simple word-level diff implementation
function computeDiff(
  textA: string,
  textB: string
): { type: 'same' | 'added' | 'removed'; word: string }[] {
  const wordsA = textA.split(/(\s+)/)
  const wordsB = textB.split(/(\s+)/)

  // Simple LCS-based diff at word level
  const m = wordsA.length
  const n = wordsB.length

  // Build LCS table
  const dp: number[][] = Array.from({ length: m + 1 }, () =>
    Array(n + 1).fill(0)
  )
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (wordsA[i - 1] === wordsB[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1] + 1
      } else {
        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1])
      }
    }
  }

  // Backtrack to find diff
  const result: { type: 'same' | 'added' | 'removed'; word: string }[] = []
  let i = m
  let j = n
  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && wordsA[i - 1] === wordsB[j - 1]) {
      result.unshift({ type: 'same', word: wordsA[i - 1] })
      i--
      j--
    } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
      result.unshift({ type: 'added', word: wordsB[j - 1] })
      j--
    } else if (i > 0) {
      result.unshift({ type: 'removed', word: wordsA[i - 1] })
      i--
    }
  }

  return result
}

// Markdown rendering components (matching result-panel style)
const comparisonMarkdownComponents = {
  h1: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <h1 className="text-xl font-bold text-foreground mt-6 mb-3 first:mt-0">
      {children}
    </h1>
  ),
  h2: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <h2 className="text-lg font-bold text-foreground mt-5 mb-2">{children}</h2>
  ),
  h3: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <h3 className="text-base font-semibold text-foreground mt-4 mb-2">
      {children}
    </h3>
  ),
  p: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <p className="text-sm text-muted-foreground leading-relaxed mb-3">
      {children}
    </p>
  ),
  ul: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <ul className="text-sm text-muted-foreground list-disc pl-5 mb-3 space-y-1">
      {children}
    </ul>
  ),
  ol: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <ol className="text-sm text-muted-foreground list-decimal pl-5 mb-3 space-y-1">
      {children}
    </ol>
  ),
  li: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <li className="text-sm text-muted-foreground">{children}</li>
  ),
  strong: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <strong className="text-foreground font-semibold">{children}</strong>
  ),
  blockquote: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <blockquote className="border-l-4 border-emerald-500 pl-4 italic text-muted-foreground my-3">
      {children}
    </blockquote>
  ),
  code: ({
    children,
    className,
  }: React.HTMLAttributes<HTMLElement> & { children?: React.ReactNode }) => {
    const match = /language-(\w+)/.exec(className || '')
    if (match) {
      return (
        <div className="relative my-3">
          <pre className="bg-muted rounded-lg p-3 text-xs overflow-x-auto">
            <code>{children}</code>
          </pre>
        </div>
      )
    }
    return (
      <code className="bg-muted px-1.5 py-0.5 rounded text-sm font-mono text-emerald-600 dark:text-emerald-400">
        {children}
      </code>
    )
  },
  hr: () => <hr className="border-border my-4" />,
  table: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <div className="overflow-x-auto my-3">
      <table className="w-full text-sm border-collapse">{children}</table>
    </div>
  ),
  th: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <th className="border border-border px-3 py-2 bg-muted text-foreground font-semibold text-left">
      {children}
    </th>
  ),
  td: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <td className="border border-border px-3 py-2 text-muted-foreground">
      {children}
    </td>
  ),
}

// Diff view component for showing word-level differences
function DiffView({
  diffItems,
}: {
  diffItems: { type: 'same' | 'added' | 'removed'; word: string }[]
}) {
  // Group consecutive diff items of same type for rendering
  const groups: { type: 'same' | 'added' | 'removed'; text: string }[] = []
  for (const item of diffItems) {
    const lastGroup = groups[groups.length - 1]
    if (lastGroup && lastGroup.type === item.type) {
      lastGroup.text += item.word
    } else {
      groups.push({ type: item.type, text: item.word })
    }
  }

  return (
    <div className="text-sm leading-relaxed whitespace-pre-wrap break-words">
      {groups.map((group, i) => {
        if (group.type === 'same') {
          return <span key={i}>{group.text}</span>
        }
        if (group.type === 'added') {
          return (
            <span
              key={i}
              className="bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 rounded px-0.5"
            >
              {group.text}
            </span>
          )
        }
        if (group.type === 'removed') {
          return (
            <span
              key={i}
              className="bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300 line-through rounded px-0.5"
            >
              {group.text}
            </span>
          )
        }
        return null
      })}
    </div>
  )
}

// Individual result panel in the comparison view
function ComparisonPanel({
  label,
  items,
  selectedId,
  onSelect,
}: {
  label: string
  items: HistoryItem[]
  selectedId: string
  onSelect: (id: string) => void
}) {
  const selectedItem = items.find((item) => item.id === selectedId)

  const getInputSummary = (item: HistoryItem): string => {
    try {
      const input =
        typeof item.input === 'string' ? JSON.parse(item.input) : item.input
      const values = Object.values(input || {})
      for (const val of values) {
        const trimmed = String(val || '').trim()
        if (trimmed) {
          return trimmed.length > 50 ? trimmed.substring(0, 50) + '...' : trimmed
        }
      }
      return 'No input'
    } catch {
      return 'No input'
    }
  }

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* Selection header */}
      <div className="space-y-2 pb-3">
        <div className="flex items-center gap-2">
          <Badge
            variant="secondary"
            className="text-xs bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/50"
          >
            {label}
          </Badge>
          {selectedItem && (
            <Badge
              variant="outline"
              className={`text-xs ${toolAccentMap[selectedItem.toolType] || 'text-muted-foreground'}`}
            >
              {toolNameMap[selectedItem.toolType] || selectedItem.toolType}
            </Badge>
          )}
        </div>
        <Select value={selectedId} onValueChange={onSelect}>
          <SelectTrigger className="w-full text-sm">
            <SelectValue placeholder="Select a result..." />
          </SelectTrigger>
          <SelectContent>
            {items.map((item) => (
              <SelectItem key={item.id} value={item.id}>
                <div className="flex items-center gap-2">
                  <span className="font-medium">
                    {toolNameMap[item.toolType] || item.toolType}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    — {getInputSummary(item)}
                  </span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {selectedItem && (
          <p className="text-xs text-muted-foreground">
            {new Date(selectedItem.createdAt).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            })}
          </p>
        )}
      </div>

      <Separator className="mb-3" />

      {/* Result content */}
      <ScrollArea className="flex-1 min-h-0">
        {selectedItem ? (
          <div className="pr-3">
            <ReactMarkdown components={comparisonMarkdownComponents}>
              {selectedItem.output}
            </ReactMarkdown>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 gap-3">
            <div className="size-12 rounded-full bg-muted flex items-center justify-center">
              <ChevronDown className="size-5 text-muted-foreground" />
            </div>
            <p className="text-xs text-muted-foreground">
              Select a result above to view
            </p>
          </div>
        )}
      </ScrollArea>
    </div>
  )
}

type ViewMode = 'side-by-side' | 'diff'

interface ResultComparisonProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  currentToolType?: string
}

export function ResultComparison({
  open,
  onOpenChange,
  currentToolType,
}: ResultComparisonProps) {
  const [historyItems, setHistoryItems] = React.useState<HistoryItem[]>([])
  const [loading, setLoading] = React.useState(false)
  const [selectedA, setSelectedA] = React.useState<string>('')
  const [selectedB, setSelectedB] = React.useState<string>('')
  const [viewMode, setViewMode] = React.useState<ViewMode>('side-by-side')

  // Fetch history items when dialog opens
  React.useEffect(() => {
    if (!open) return
    setLoading(true)
    fetch('/api/tools/history?limit=50')
      .then((res) => res.json())
      .then((data) => {
        const items: HistoryItem[] = data.results || []
        setHistoryItems(items)
        // Auto-select first two items if available
        if (items.length >= 2) {
          // If currentToolType is provided, prefer items of that type
          const sameType = currentToolType
            ? items.filter((i) => i.toolType === currentToolType)
            : []
          if (sameType.length >= 2) {
            setSelectedA(sameType[0].id)
            setSelectedB(sameType[1].id)
          } else {
            setSelectedA(items[0].id)
            setSelectedB(items[1].id)
          }
        } else if (items.length === 1) {
          setSelectedA(items[0].id)
          setSelectedB('')
        } else {
          setSelectedA('')
          setSelectedB('')
        }
      })
      .catch(() => {
        toast.error('Failed to load history')
      })
      .finally(() => setLoading(false))
  }, [open, currentToolType])

  const itemA = historyItems.find((item) => item.id === selectedA)
  const itemB = historyItems.find((item) => item.id === selectedB)

  // Compute diff when both items are selected and in diff mode
  const diffItems =
    viewMode === 'diff' && itemA && itemB
      ? computeDiff(itemA.output, itemB.output)
      : []

  const getInputSummary = (item: HistoryItem): string => {
    try {
      const input =
        typeof item.input === 'string' ? JSON.parse(item.input) : item.input
      const values = Object.values(input || {})
      for (const val of values) {
        const trimmed = String(val || '').trim()
        if (trimmed) {
          return trimmed.length > 40 ? trimmed.substring(0, 40) + '...' : trimmed
        }
      }
      return 'No input'
    } catch {
      return 'No input'
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-6xl max-h-[90vh] p-0 gap-0 overflow-hidden backdrop-blur-xl bg-background/80 shadow-2xl shadow-emerald-500/5 border-white/10 dark:border-white/5">
        {/* Gradient border wrapper */}
        <div className="absolute inset-0 rounded-lg pointer-events-none p-[1px]">
          <div className="w-full h-full rounded-lg bg-gradient-to-br from-emerald-400/20 via-transparent to-teal-400/20 dark:from-emerald-400/10 dark:via-transparent dark:to-teal-400/10" />
        </div>

        {/* Header */}
        <div className="relative border-b px-6 py-4 bg-background/60 backdrop-blur-md border-white/10 dark:border-white/5">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 shadow-sm">
                  <GitCompareArrows className="size-5 text-white" />
                </div>
                <div>
                  <DialogTitle className="text-lg">Compare Results</DialogTitle>
                  <DialogDescription>
                    Compare two AI-generated results side by side with diff highlighting
                  </DialogDescription>
                </div>
              </div>

              {/* View mode toggle */}
              <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
                <Button
                  size="sm"
                  variant={viewMode === 'side-by-side' ? 'default' : 'ghost'}
                  onClick={() => setViewMode('side-by-side')}
                  className={`text-xs gap-1.5 ${
                    viewMode === 'side-by-side'
                      ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
                      : ''
                  }`}
                >
                  <Eye className="size-3.5" />
                  Side by Side
                </Button>
                <Button
                  size="sm"
                  variant={viewMode === 'diff' ? 'default' : 'ghost'}
                  onClick={() => setViewMode('diff')}
                  className={`text-xs gap-1.5 ${
                    viewMode === 'diff'
                      ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
                      : ''
                  }`}
                >
                  <GitMerge className="size-3.5" />
                  Diff View
                </Button>
              </div>
            </div>
          </DialogHeader>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center py-20 gap-3">
              <Loader2 className="size-6 animate-spin text-emerald-500" />
              <p className="text-sm text-muted-foreground">
                Loading history...
              </p>
            </div>
          ) : historyItems.length < 2 ? (
            <div className="flex flex-col items-center justify-center py-20 gap-4">
              <div className="size-16 rounded-full bg-muted flex items-center justify-center">
                <Inbox className="size-8 text-muted-foreground/50" />
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-foreground">
                  Not enough results to compare
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Generate at least 2 results to use the comparison feature
                </p>
              </div>
            </div>
          ) : viewMode === 'side-by-side' ? (
            /* Side by side view */
            <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border h-full max-h-[calc(90vh-140px)]">
              <div className="p-4 min-h-0 overflow-hidden">
                <ComparisonPanel
                  label="Result A"
                  items={historyItems}
                  selectedId={selectedA}
                  onSelect={setSelectedA}
                />
              </div>
              <div className="p-4 min-h-0 overflow-hidden">
                <ComparisonPanel
                  label="Result B"
                  items={historyItems}
                  selectedId={selectedB}
                  onSelect={setSelectedB}
                />
              </div>
            </div>
          ) : (
            /* Diff view */
            <div className="p-6 h-full max-h-[calc(90vh-140px)] flex flex-col">
              {itemA && itemB ? (
                <>
                  {/* Diff header */}
                  <div className="flex items-center gap-4 mb-4 flex-wrap">
                    <div className="flex items-center gap-2">
                      <Badge
                        variant="secondary"
                        className="text-xs bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
                      >
                        Result A
                      </Badge>
                      <span className={`text-sm font-medium ${toolAccentMap[itemA.toolType] || ''}`}>
                        {toolNameMap[itemA.toolType] || itemA.toolType}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        — {getInputSummary(itemA)}
                      </span>
                    </div>
                    <ArrowLeftRight className="size-4 text-muted-foreground shrink-0" />
                    <div className="flex items-center gap-2">
                      <Badge
                        variant="secondary"
                        className="text-xs bg-teal-50 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300"
                      >
                        Result B
                      </Badge>
                      <span className={`text-sm font-medium ${toolAccentMap[itemB.toolType] || ''}`}>
                        {toolNameMap[itemB.toolType] || itemB.toolType}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        — {getInputSummary(itemB)}
                      </span>
                    </div>
                  </div>

                  {/* Legend */}
                  <div className="flex items-center gap-4 mb-3 text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="inline-block w-3 h-3 rounded bg-emerald-100 dark:bg-emerald-900/40 border border-emerald-300 dark:border-emerald-700" />
                      <span className="text-muted-foreground">Added in B</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="inline-block w-3 h-3 rounded bg-red-100 dark:bg-red-900/40 border border-red-300 dark:border-red-700" />
                      <span className="text-muted-foreground">Removed from A</span>
                    </div>
                  </div>

                  {/* Selection controls for diff mode */}
                  <div className="flex items-center gap-3 mb-3">
                    <Select value={selectedA} onValueChange={setSelectedA}>
                      <SelectTrigger className="w-60 text-xs">
                        <SelectValue placeholder="Select Result A" />
                      </SelectTrigger>
                      <SelectContent>
                        {historyItems.map((item) => (
                          <SelectItem key={item.id} value={item.id}>
                            {toolNameMap[item.toolType] || item.toolType} —{' '}
                            {getInputSummary(item)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={selectedB} onValueChange={setSelectedB}>
                      <SelectTrigger className="w-60 text-xs">
                        <SelectValue placeholder="Select Result B" />
                      </SelectTrigger>
                      <SelectContent>
                        {historyItems.map((item) => (
                          <SelectItem key={item.id} value={item.id}>
                            {toolNameMap[item.toolType] || item.toolType} —{' '}
                            {getInputSummary(item)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator className="mb-3" />

                  {/* Diff content */}
                  <ScrollArea className="flex-1 min-h-0">
                    <div className="p-4 rounded-lg bg-muted/30 border border-emerald-500/10">
                      <DiffView diffItems={diffItems} />
                    </div>
                  </ScrollArea>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 gap-3">
                  <p className="text-sm text-muted-foreground">
                    Select two results above to see the diff
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
