'use client'

import * as React from 'react'
import { motion, useInView, AnimatePresence } from 'framer-motion'
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react'

const testimonials = [
  {
    name: 'Sarah Chen',
    role: 'Founder, DataFlow AI',
    content: 'Antigravity AI helped me validate my SaaS idea in minutes. The market analysis was spot-on and saved me months of research.',
    rating: 5,
    avatar: 'SC',
  },
  {
    name: 'Marcus Johnson',
    role: 'CTO, BuildStack',
    content: 'The tech stack recommender is incredible. It suggested the exact combination we ended up using for our production deployment.',
    rating: 5,
    avatar: 'MJ',
  },
  {
    name: 'Elena Rodriguez',
    role: 'Indie Hacker',
    content: 'I used the idea generator and validator together. It helped me pivot from a weak concept to a validated business in one afternoon.',
    rating: 5,
    avatar: 'ER',
  },
  {
    name: 'David Kim',
    role: 'Product Manager, ScaleOps',
    content: 'The pitch deck generator gave us a framework that impressed our investors. We closed our seed round in 3 weeks.',
    rating: 5,
    avatar: 'DK',
  },
  {
    name: 'Aisha Patel',
    role: 'CEO, LearnPro',
    content: 'From idea validation to business model generation — Antigravity AI covers every step of the SaaS building journey.',
    rating: 5,
    avatar: 'AP',
  },
  {
    name: 'Tom Wilson',
    role: 'Solo Founder, InboxZero',
    content: 'The landing page optimizer helped me increase my conversion rate by 40%. The AI-generated copy was better than what I paid a copywriter for.',
    rating: 5,
    avatar: 'TW',
  },
]

// ── Star Rating with fill animation ──────────────────────────────────────────
function AnimatedStarRating({ rating, delay = 0 }: { rating: number; delay?: number }) {
  const ref = React.useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true })

  return (
    <div ref={ref} className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ scale: 0, opacity: 0 }}
          animate={inView ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }}
          transition={{
            type: 'spring',
            stiffness: 400,
            damping: 15,
            delay: delay + i * 0.08,
          }}
        >
          <Star
            className={`size-4 ${
              i < rating
                ? 'fill-amber-400 text-amber-400'
                : 'fill-muted text-muted-foreground/30'
            }`}
          />
        </motion.div>
      ))}
    </div>
  )
}

export function TestimonialsSection() {
  const scrollContainerRef = React.useRef<HTMLDivElement>(null)
  const [activeIndex, setActiveIndex] = React.useState(0)
  const [isPaused, setIsPaused] = React.useState(false)

  // Duplicate testimonials for infinite loop feel
  const extendedTestimonials = [...testimonials, ...testimonials]

  // Auto-scroll logic
  React.useEffect(() => {
    if (isPaused) return

    const interval = setInterval(() => {
      setActiveIndex((prev) => {
        const next = prev + 1
        if (next >= testimonials.length) {
          // Reset to 0 seamlessly after a brief pause
          return 0
        }
        return next
      })
    }, 4000)

    return () => clearInterval(interval)
  }, [isPaused])

  // Smooth scroll to the active index
  React.useEffect(() => {
    const container = scrollContainerRef.current
    if (!container) return

    const cardWidth = container.scrollWidth / extendedTestimonials.length
    container.scrollTo({
      left: cardWidth * activeIndex,
      behavior: 'smooth',
    })
  }, [activeIndex, extendedTestimonials.length])

  const handlePrev = () => {
    setActiveIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  const handleNext = () => {
    setActiveIndex((prev) => (prev + 1) % testimonials.length)
  }

  return (
    <section className="py-20 sm:py-28 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Loved by <span className="animated-gradient-text">Founders</span> & Builders
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            Join thousands of entrepreneurs who trust Antigravity AI to power
            their SaaS journey.
          </p>
        </motion.div>

        {/* Carousel Container */}
        <div
          className="relative"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          {/* Fade edges */}
          <div className="absolute left-0 top-0 bottom-0 w-8 sm:w-16 z-10 bg-gradient-to-r from-muted/30 to-transparent pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-8 sm:w-16 z-10 bg-gradient-to-l from-muted/30 to-transparent pointer-events-none" />

          {/* Scroll container */}
          <div
            ref={scrollContainerRef}
            className="flex gap-6 overflow-x-auto scrollbar-hide snap-x snap-mandatory pb-4"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {extendedTestimonials.map((testimonial, index) => (
              <div
                key={`${testimonial.name}-${index}`}
                className="flex-shrink-0 w-[320px] sm:w-[380px] snap-center"
              >
                <div className="group h-full">
                  <div className="relative rounded-xl border bg-card/80 backdrop-blur-sm p-6 h-full transition-all duration-300 hover:shadow-xl hover:scale-[1.02] hover:border-emerald-200 dark:hover:border-emerald-800/50 overflow-hidden">
                    {/* Emerald gradient line at top */}
                    <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-emerald-400 via-teal-400 to-emerald-400 opacity-60" />

                    {/* Quote icon watermark behind content */}
                    <Quote className="absolute top-4 right-4 size-20 text-emerald-100 dark:text-emerald-900/30 pointer-events-none select-none" />

                    {/* Quote icon */}
                    <motion.div
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                      className="relative mb-4 inline-block"
                    >
                      <Quote className="size-8 text-emerald-300 dark:text-emerald-700/60" />
                    </motion.div>

                    {/* Stars with fill animation */}
                    <div className="relative mb-4">
                      <AnimatedStarRating rating={testimonial.rating} delay={0.3} />
                    </div>

                    {/* Content */}
                    <p className="relative text-sm text-muted-foreground leading-relaxed mb-6 transition-all duration-300 group-hover:text-shadow-[0_0_8px_rgba(16,185,129,0.3)]">
                      &ldquo;{testimonial.content}&rdquo;
                    </p>

                    {/* Author */}
                    <div className="relative flex items-center gap-3 mt-auto">
                      <div className="flex size-10 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 text-white text-sm font-semibold">
                        {testimonial.avatar}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-card-foreground">
                          {testimonial.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {testimonial.role}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation arrows */}
          <button
            type="button"
            onClick={handlePrev}
            className="absolute left-2 sm:-left-4 top-1/2 -translate-y-1/2 z-20 flex size-8 sm:size-10 items-center justify-center rounded-full bg-background border shadow-lg hover:bg-emerald-50 dark:hover:bg-emerald-900/30 hover:border-emerald-300 dark:hover:border-emerald-700 text-muted-foreground hover:text-emerald-600 dark:hover:text-emerald-400 transition-all duration-300"
            aria-label="Previous testimonial"
          >
            <ChevronLeft className="size-4 sm:size-5" />
          </button>
          <button
            type="button"
            onClick={handleNext}
            className="absolute right-2 sm:-right-4 top-1/2 -translate-y-1/2 z-20 flex size-8 sm:size-10 items-center justify-center rounded-full bg-background border shadow-lg hover:bg-emerald-50 dark:hover:bg-emerald-900/30 hover:border-emerald-300 dark:hover:border-emerald-700 text-muted-foreground hover:text-emerald-600 dark:hover:text-emerald-400 transition-all duration-300"
            aria-label="Next testimonial"
          >
            <ChevronRight className="size-4 sm:size-5" />
          </button>
        </div>

        {/* Navigation dots */}
        <div className="flex items-center justify-center gap-2 mt-8">
          {testimonials.map((_, index) => (
            <button
              key={index}
              type="button"
              onClick={() => setActiveIndex(index)}
              className={`transition-all duration-300 rounded-full ${
                index === activeIndex
                  ? 'w-6 h-2 bg-emerald-500'
                  : 'w-2 h-2 bg-emerald-300/40 dark:bg-emerald-600/40 hover:bg-emerald-400/60'
              }`}
              aria-label={`Go to testimonial ${index + 1}`}
              aria-current={index === activeIndex ? 'true' : undefined}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
