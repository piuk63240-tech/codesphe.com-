'use client'

import * as React from 'react'
import { Keyboard } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

interface KeyboardShortcutsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const shortcuts = [
  {
    keys: ['⌘', 'K'],
    keysWin: ['Ctrl', 'K'],
    description: 'Open Command Palette',
  },
  {
    keys: ['⌘', '/'],
    keysWin: ['Ctrl', '/'],
    description: 'Show Keyboard Shortcuts',
  },
  {
    keys: ['Esc'],
    keysWin: ['Esc'],
    description: 'Close modal/dialog',
  },
  {
    keys: ['1', '-', '9'],
    keysWin: ['1', '-', '9'],
    description: 'Quick open tool 1-9 (when no modal is open)',
  },
  {
    keys: ['⌘', 'D'],
    keysWin: ['Ctrl', 'D'],
    description: 'Toggle dark mode',
  },
]

function KbdKey({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="pointer-events-none inline-flex h-5 items-center gap-0.5 rounded border border-border/60 bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground">
      {children}
    </kbd>
  )
}

export function KeyboardShortcutsDialog({
  open,
  onOpenChange,
}: KeyboardShortcutsDialogProps) {
  const [isMac, setIsMac] = React.useState(true)

  React.useEffect(() => {
    setIsMac(navigator.platform.toUpperCase().indexOf('MAC') >= 0)
  }, [])

  // Listen for ⌘/ or Ctrl+/ to open this dialog
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === '/') {
        e.preventDefault()
        onOpenChange(true)
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [onOpenChange])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-lg bg-emerald-100 dark:bg-emerald-900/30">
              <Keyboard className="size-4 text-emerald-600 dark:text-emerald-400" />
            </div>
            <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              Keyboard Shortcuts
            </span>
          </DialogTitle>
          <DialogDescription>
            Use these shortcuts to navigate faster
          </DialogDescription>
        </DialogHeader>

        <div className="mt-2 space-y-1">
          {shortcuts.map((shortcut, index) => (
            <div
              key={index}
              className="flex items-center justify-between rounded-lg px-3 py-2.5 hover:bg-emerald-50 dark:hover:bg-emerald-900/10 transition-colors"
            >
              <span className="text-sm text-foreground">
                {shortcut.description}
              </span>
              <div className="flex items-center gap-1">
                {(isMac ? shortcut.keys : shortcut.keysWin).map(
                  (key, keyIndex) => (
                    <React.Fragment key={keyIndex}>
                      {keyIndex > 0 && (
                        <span className="text-muted-foreground/50 text-[10px]">
                          {key === '-' ? '' : '+'}
                        </span>
                      )}
                      <KbdKey>
                        <span className={key.length > 1 ? 'text-xs' : ''}>
                          {key}
                        </span>
                      </KbdKey>
                    </React.Fragment>
                  )
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-2 pt-3 border-t border-border/60">
          <p className="text-xs text-muted-foreground text-center">
            Shortcuts work when no input field is focused
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}
