'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts'
import {
  BarChart3,
  TrendingUp,
  Star,
  Zap,
} from 'lucide-react'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { tools } from '@/components/tools-grid'

// ── Types ──────────────────────────────────────────────────────────────────────
interface StatsData {
  totalGenerations: number
  totalSavedIdeas: number
  generationsPerTool: { toolType: string; count: number }[]
  generationsPerDay: { date: string; count: number }[]
  averageRatingPerTool: { toolType: string; averageRating: number }[]
  mostPopularTools: { toolType: string; count: number }[]
  overallAvgRating: number
}

// ── Tool name formatter ────────────────────────────────────────────────────────
function getToolName(toolType: string): string {
  const tool = tools.find((t) => t.id === toolType)
  return tool ? tool.name : toolType.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
}

// ── Custom tooltip for charts ──────────────────────────────────────────────────
function CustomTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{ value: number; name: string }>
  label?: string
}) {
  if (!active || !payload || !payload.length) return null

  return (
    <div className="rounded-lg border bg-card px-3 py-2 shadow-xl">
      <p className="text-xs font-medium text-muted-foreground mb-1">{label}</p>
      {payload.map((entry, index) => (
        <p key={index} className="text-sm font-semibold text-emerald-600 dark:text-emerald-400">
          {entry.name}: {entry.value}
        </p>
      ))}
    </div>
  )
}

// ── Skeleton loaders ───────────────────────────────────────────────────────────
function StatCardSkeleton() {
  return (
    <Card className="border-border/50">
      <CardContent className="p-4 sm:p-6">
        <div className="flex items-center gap-3 mb-3">
          <Skeleton className="size-10 rounded-lg" />
          <Skeleton className="h-4 w-24" />
        </div>
        <Skeleton className="h-8 w-20 mb-1" />
        <Skeleton className="h-3 w-32" />
      </CardContent>
    </Card>
  )
}

function ChartSkeleton() {
  return (
    <Card className="border-border/50">
      <CardHeader className="pb-2">
        <Skeleton className="h-5 w-40" />
        <Skeleton className="h-3 w-56" />
      </CardHeader>
      <CardContent className="p-6 pt-0">
        <Skeleton className="h-[260px] w-full rounded-lg" />
      </CardContent>
    </Card>
  )
}

// ── Stat cards ─────────────────────────────────────────────────────────────────
interface StatCardProps {
  icon: React.ElementType
  label: string
  value: string | number
  subtitle: string
  index: number
}

function StatCard({ icon: Icon, label, value, subtitle, index }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.08 }}
    >
      <Card className="border-border/50 hover:border-emerald-200 dark:hover:border-emerald-800/50 transition-colors duration-300 overflow-hidden group">
        <CardContent className="p-4 sm:p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="flex size-10 items-center justify-center rounded-lg bg-emerald-50 dark:bg-emerald-900/20 group-hover:bg-emerald-100 dark:group-hover:bg-emerald-900/40 transition-colors duration-300">
              <Icon className="size-5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <span className="text-xs sm:text-sm font-medium text-muted-foreground">{label}</span>
          </div>
          <p className="text-xl sm:text-2xl font-bold text-foreground">{value}</p>
          <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
        </CardContent>
      </Card>
    </motion.div>
  )
}

// ── Main Analytics Section ─────────────────────────────────────────────────────
export function AnalyticsSection() {
  const [stats, setStats] = React.useState<StatsData | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState(false)

  React.useEffect(() => {
    async function fetchStats() {
      try {
        const res = await fetch('/api/tools/stats')
        if (!res.ok) throw new Error('Failed to fetch')
        const data = await res.json()
        setStats(data)
      } catch {
        setError(true)
      } finally {
        setLoading(false)
      }
    }
    fetchStats()
  }, [])

  // ── Loading state ─────────────────────────────────────────────────────────
  if (loading) {
    return (
      <section id="analytics" className="py-14 sm:py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-10 sm:mb-14"
          >
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Your Activity <span className="animated-gradient-text">Dashboard</span>
            </h2>
            <p className="mx-auto max-w-2xl text-sm sm:text-base lg:text-lg text-muted-foreground">
              Track your AI tool usage and generation patterns
            </p>
          </motion.div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-6 mb-6 sm:mb-8">
            {Array.from({ length: 4 }).map((_, i) => (
              <StatCardSkeleton key={i} />
            ))}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
            <ChartSkeleton />
            <ChartSkeleton />
          </div>
        </div>
      </section>
    )
  }

  // ── Error state ───────────────────────────────────────────────────────────
  if (error) {
    return (
      <section id="analytics" className="py-14 sm:py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-10 sm:mb-14"
          >
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Your Activity <span className="animated-gradient-text">Dashboard</span>
            </h2>
            <p className="mx-auto max-w-2xl text-sm sm:text-base lg:text-lg text-muted-foreground">
              Track your AI tool usage and generation patterns
            </p>
          </motion.div>
          <Card className="border-border/50 max-w-md mx-auto">
            <CardContent className="p-8 text-center">
              <BarChart3 className="size-12 text-muted-foreground/40 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Unable to load analytics</h3>
              <p className="text-sm text-muted-foreground">
                Something went wrong while loading your stats. Please try again later.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    )
  }

  // ── Empty state (no data) ─────────────────────────────────────────────────
  if (stats && stats.totalGenerations === 0) {
    return (
      <section id="analytics" className="py-14 sm:py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-10 sm:mb-14"
          >
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Your Activity <span className="animated-gradient-text">Dashboard</span>
            </h2>
            <p className="mx-auto max-w-2xl text-sm sm:text-base lg:text-lg text-muted-foreground">
              Track your AI tool usage and generation patterns
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card className="border-border/50 max-w-lg mx-auto">
              <CardContent className="p-10 text-center">
                <div className="flex size-16 items-center justify-center rounded-2xl bg-emerald-50 dark:bg-emerald-900/20 mx-auto mb-5">
                  <Zap className="size-8 text-emerald-500" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">
                  No activity yet
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed max-w-sm mx-auto">
                  Start using our AI tools to generate ideas, validate concepts, and build your
                  SaaS business. Your usage patterns and stats will appear here.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>
    )
  }

  // ── Data available ────────────────────────────────────────────────────────
  const mostUsedTool = stats?.mostPopularTools[0]
    ? getToolName(stats.mostPopularTools[0].toolType)
    : 'N/A'

  // Prepare bar chart data with readable names
  const barChartData =
    stats?.generationsPerTool.map((item) => ({
      name: getToolName(item.toolType),
      count: item.count,
    })) ?? []

  // Area chart data already has date labels
  const areaChartData = stats?.generationsPerDay ?? []

  return (
    <section id="analytics" className="py-14 sm:py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10 sm:mb-14"
        >
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Your Activity <span className="animated-gradient-text">Dashboard</span>
          </h2>
          <p className="mx-auto max-w-2xl text-sm sm:text-base lg:text-lg text-muted-foreground">
            Track your AI tool usage and generation patterns
          </p>
        </motion.div>

        {/* Stat Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-6 mb-6 sm:mb-8">
          <StatCard
            icon={Zap}
            label="Total Generations"
            value={stats?.totalGenerations ?? 0}
            subtitle="AI-powered generations"
            index={0}
          />
          <StatCard
            icon={TrendingUp}
            label="Saved Ideas"
            value={stats?.totalSavedIdeas ?? 0}
            subtitle="Ideas bookmarked"
            index={1}
          />
          <StatCard
            icon={Star}
            label="Avg Rating"
            value={stats?.overallAvgRating ?? 0}
            subtitle="Average quality score"
            index={2}
          />
          <StatCard
            icon={BarChart3}
            label="Most Used Tool"
            value={mostUsedTool}
            subtitle="Top tool by usage"
            index={3}
          />
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
          {/* Bar Chart - Tool Usage by Type */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.15 }}
          >
            <Card className="border-border/50 hover:border-emerald-200 dark:hover:border-emerald-800/50 transition-colors duration-300 overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2">
                  <BarChart3 className="size-5 text-emerald-600 dark:text-emerald-400" />
                  <CardTitle className="text-base font-semibold">Tool Usage</CardTitle>
                </div>
                <p className="text-xs text-muted-foreground">
                  Number of generations per tool type
                </p>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-2">
                <div className="h-[200px] sm:h-[280px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={barChartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                      <defs>
                        <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#10b981" stopOpacity={1} />
                          <stop offset="100%" stopColor="#059669" stopOpacity={0.8} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                      <XAxis
                        dataKey="name"
                        tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                        axisLine={{ stroke: 'hsl(var(--border))' }}
                        tickLine={false}
                        angle={-30}
                        textAnchor="end"
                        height={60}
                      />
                      <YAxis
                        tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                        axisLine={false}
                        tickLine={false}
                        allowDecimals={false}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar
                        dataKey="count"
                        name="Generations"
                        fill="url(#barGradient)"
                        radius={[4, 4, 0, 0]}
                        maxBarSize={48}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Area Chart - Generations Over Last 7 Days */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="border-border/50 hover:border-emerald-200 dark:hover:border-emerald-800/50 transition-colors duration-300 overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2">
                  <TrendingUp className="size-5 text-emerald-600 dark:text-emerald-400" />
                  <CardTitle className="text-base font-semibold">Generation Trends</CardTitle>
                </div>
                <p className="text-xs text-muted-foreground">
                  Daily generations over the last 7 days
                </p>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-2">
                <div className="h-[200px] sm:h-[280px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={areaChartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                      <defs>
                        <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#10b981" stopOpacity={0.3} />
                          <stop offset="100%" stopColor="#10b981" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                      <XAxis
                        dataKey="date"
                        tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                        axisLine={{ stroke: 'hsl(var(--border))' }}
                        tickLine={false}
                      />
                      <YAxis
                        tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                        axisLine={false}
                        tickLine={false}
                        allowDecimals={false}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Area
                        type="monotone"
                        dataKey="count"
                        name="Generations"
                        stroke="#10b981"
                        strokeWidth={2.5}
                        fill="url(#areaGradient)"
                        dot={{ fill: '#10b981', strokeWidth: 2, stroke: '#fff', r: 4 }}
                        activeDot={{ r: 6, fill: '#059669', stroke: '#fff', strokeWidth: 2 }}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
