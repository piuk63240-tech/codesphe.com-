'use client'

import * as React from 'react'
import ReactMarkdown from 'react-markdown'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism'
import { X } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogTitle,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'

interface FullscreenResultDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  result: string | null
}

// Code block component with syntax highlighting
function CodeBlock({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLElement> & { children?: React.ReactNode }) {
  const match = /language-(\w+)/.exec(className || '')
  const codeString = String(children).replace(/\n$/, '')

  if (match) {
    return (
      <div className="relative group my-3">
        <SyntaxHighlighter
          style={oneDark}
          language={match[1]}
          PreTag="div"
          customStyle={{
            margin: 0,
            borderRadius: '0.5rem',
            fontSize: '0.8125rem',
          }}
        >
          {codeString}
        </SyntaxHighlighter>
      </div>
    )
  }

  return (
    <code
      className="bg-muted px-1.5 py-0.5 rounded text-sm font-mono text-emerald-600 dark:text-emerald-400"
      {...props}
    >
      {children}
    </code>
  )
}

// Simplified markdown components matching result-panel styling
const fullscreenMarkdownComponents = {
  code: CodeBlock,
  h1: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <h1 className="text-2xl font-bold text-foreground mt-8 mb-4 first:mt-0">{children}</h1>
  ),
  h2: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <h2 className="text-xl font-bold text-foreground mt-6 mb-3">{children}</h2>
  ),
  h3: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <h3 className="text-lg font-semibold text-foreground mt-5 mb-2">{children}</h3>
  ),
  p: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <p className="text-base text-muted-foreground leading-relaxed mb-4">{children}</p>
  ),
  ul: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <ul className="text-base text-muted-foreground list-disc pl-6 mb-4 space-y-1.5">{children}</ul>
  ),
  ol: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <ol className="text-base text-muted-foreground list-decimal pl-6 mb-4 space-y-1.5">{children}</ol>
  ),
  li: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <li className="text-base text-muted-foreground">{children}</li>
  ),
  strong: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <strong className="text-foreground font-semibold">{children}</strong>
  ),
  blockquote: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <blockquote className="border-l-4 border-emerald-500 pl-5 italic text-muted-foreground my-4">{children}</blockquote>
  ),
  table: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <div className="overflow-x-auto my-4"><table className="w-full text-sm border-collapse">{children}</table></div>
  ),
  th: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <th className="border border-border px-4 py-2 bg-muted text-foreground font-semibold text-left">{children}</th>
  ),
  td: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <td className="border border-border px-4 py-2 text-muted-foreground">{children}</td>
  ),
  hr: () => <hr className="border-border my-6" />,
  a: ({ children, href }: React.AnchorHTMLAttributes<HTMLAnchorElement>) => (
    <a
      href={href}
      className="text-emerald-600 dark:text-emerald-400 underline underline-offset-2 hover:text-emerald-700 dark:hover:text-emerald-300"
      target="_blank"
      rel="noopener noreferrer"
    >
      {children}
    </a>
  ),
}

export function FullscreenResultDialog({ open, onOpenChange, result }: FullscreenResultDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-none w-[95vw] h-[90vh] bg-black/80 backdrop-blur-sm border-white/10 p-0 gap-0 overflow-hidden"
        showCloseButton={false}
      >
        {/* Close button */}
        <button
          onClick={() => onOpenChange(false)}
          className="absolute top-4 right-4 z-50 flex size-10 items-center justify-center rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          aria-label="Close full screen"
        >
          <X className="size-5" />
        </button>

        {/* Content */}
        <ScrollArea className="h-full">
          <div className="max-w-4xl mx-auto px-6 sm:px-8 py-8 sm:py-12">
            {result && (
              <div className="prose-custom">
                <ReactMarkdown components={fullscreenMarkdownComponents}>
                  {result}
                </ReactMarkdown>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Accessible title */}
        <DialogTitle className="sr-only">Full Screen Result</DialogTitle>
      </DialogContent>
    </Dialog>
  )
}
