'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  MessageCircle,
  Sparkles,
  X,
  Send,
  Loader2,
  Trash2,
  Maximize2,
  Minimize2,
  Lightbulb,
  HelpCircle,
  Compass,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Tooltip,
  TooltipTrigger,
  TooltipContent,
} from '@/components/ui/tooltip'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: number
}

const CHAT_STORAGE_KEY = 'antigravity-chat-history'

const SUGGESTED_PROMPTS = [
  {
    icon: HelpCircle,
    label: 'Help me pick a tool',
    prompt: 'Which AI tool should I use? I\'m not sure where to start.',
  },
  {
    icon: Lightbulb,
    label: 'Explain Idea Generator',
    prompt: 'What does the Idea Generator tool do and how can I use it effectively?',
  },
  {
    icon: Compass,
    label: "What's new?",
    prompt: 'What are the latest features and tools available on Antigravity AI?',
  },
]

const SIZE_CONFIG = {
  small: { width: 'w-[calc(100vw-3rem)] sm:w-[320px]', height: 'h-[380px]' },
  medium: { width: 'w-[calc(100vw-3rem)] sm:w-[400px]', height: 'h-[500px]' },
  large: { width: 'w-[calc(100vw-3rem)] sm:w-[480px]', height: 'h-[600px]' },
} as const

type ChatSize = keyof typeof SIZE_CONFIG

// Typing indicator dots animation
function TypingIndicator() {
  return (
    <div className="flex items-center gap-1.5 px-4 py-3">
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="size-2 rounded-full bg-emerald-500"
          animate={{
            y: [0, -8, 0],
            opacity: [0.4, 1, 0.4],
          }}
          transition={{
            duration: 0.8,
            repeat: Infinity,
            delay: i * 0.2,
            ease: 'easeInOut',
          }}
        />
      ))}
    </div>
  )
}

// Load chat history from localStorage
function loadChatHistory(): Message[] {
  if (typeof window === 'undefined') return []
  try {
    const stored = localStorage.getItem(CHAT_STORAGE_KEY)
    if (stored) {
      const parsed = JSON.parse(stored) as Message[]
      // Only keep last 50 messages
      return parsed.slice(-50)
    }
  } catch {
    // Silently fail
  }
  return []
}

// Save chat history to localStorage
function saveChatHistory(messages: Message[]) {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(messages.slice(-50)))
  } catch {
    // Silently fail
  }
}

export function AiChatWidget() {
  const [isOpen, setIsOpen] = React.useState(false)
  const [messages, setMessages] = React.useState<Message[]>([])
  const [inputValue, setInputValue] = React.useState('')
  const [isLoading, setIsLoading] = React.useState(false)
  const [hasInitialized, setHasInitialized] = React.useState(false)
  const [chatSize, setChatSize] = React.useState<ChatSize>('medium')
  const scrollRef = React.useRef<HTMLDivElement>(null)
  const inputRef = React.useRef<HTMLInputElement>(null)

  // Load chat history on mount
  React.useEffect(() => {
    if (!hasInitialized) {
      const history = loadChatHistory()
      if (history.length > 0) {
        setMessages(history)
      }
      setHasInitialized(true)
    }
  }, [hasInitialized])

  // Save chat history whenever messages change
  React.useEffect(() => {
    if (hasInitialized && messages.length > 0) {
      saveChatHistory(messages)
    }
  }, [messages, hasInitialized])

  // Add welcome message on first open if no history
  React.useEffect(() => {
    if (isOpen && messages.length === 0 && hasInitialized) {
      const welcomeMsg: Message = {
        id: 'welcome',
        role: 'assistant',
        content: "Hi! I'm your Antigravity AI assistant. I can help you find the right tool, explain features, or answer questions. What would you like to know?",
        timestamp: Date.now(),
      }
      setMessages([welcomeMsg])
    }
  }, [isOpen, messages.length, hasInitialized])

  // Auto-scroll to bottom on new messages
  React.useEffect(() => {
    if (scrollRef.current) {
      const scrollContainer = scrollRef.current.querySelector(
        '[data-radix-scroll-area-viewport]'
      )
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight
      }
    }
  }, [messages, isLoading])

  // Focus input when panel opens
  React.useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 300)
    }
  }, [isOpen])

  const sendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text.trim(),
      timestamp: Date.now(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue('')
    setIsLoading(true)

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text.trim() }),
      })

      const data = await response.json()

      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content:
          data.response ||
          'Sorry, I could not generate a response. Please try again.',
        timestamp: Date.now(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch {
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        role: 'assistant',
        content: 'Sorry, something went wrong. Please try again.',
        timestamp: Date.now(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    sendMessage(inputValue)
  }

  const handleQuickAction = (prompt: string) => {
    sendMessage(prompt)
  }

  const handleClearChat = () => {
    const welcomeMsg: Message = {
      id: `welcome-${Date.now()}`,
      role: 'assistant',
      content: "Chat cleared! How can I help you today?",
      timestamp: Date.now(),
    }
    setMessages([welcomeMsg])
    try {
      localStorage.removeItem(CHAT_STORAGE_KEY)
    } catch {
      // Silently fail
    }
  }

  const cycleSize = () => {
    const sizes: ChatSize[] = ['small', 'medium', 'large']
    const currentIdx = sizes.indexOf(chatSize)
    setChatSize(sizes[(currentIdx + 1) % sizes.length])
  }

  const sizeConfig = SIZE_CONFIG[chatSize]

  return (
    <>
      {/* Floating Chat Bubble Button - Bottom Left */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.2 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 left-6 z-50 size-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/30 flex items-center justify-center transition-colors group"
            aria-label="Open AI Assistant"
          >
            <MessageCircle className="size-6 group-hover:scale-110 transition-transform" />
            {/* Notification dot */}
            {messages.length <= 1 && (
              <span className="absolute -top-1 -right-1 size-3.5 rounded-full bg-teal-400 border-2 border-background animate-pulse" />
            )}
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className={`fixed bottom-6 left-6 z-50 ${sizeConfig.width} ${sizeConfig.height} flex flex-col rounded-2xl border border-white/10 dark:border-white/5 bg-card/70 backdrop-blur-2xl shadow-2xl shadow-emerald-500/10 overflow-hidden`}
            style={{
              background: 'linear-gradient(135deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 100%)',
            }}
          >
            {/* Glass overlay effect */}
            <div className="absolute inset-0 bg-card/60 backdrop-blur-2xl -z-10" />

            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 dark:border-white/5 bg-background/40 backdrop-blur-md">
              <div className="flex items-center gap-2.5">
                <div className="size-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center shadow-md shadow-emerald-500/20">
                  <Sparkles className="size-4 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-foreground">
                    AI Assistant
                  </h3>
                  <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                    Online
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {/* Resize toggle */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={cycleSize}
                      className="size-7 text-muted-foreground hover:text-foreground"
                      aria-label={`Resize chat (${chatSize})`}
                    >
                      {chatSize === 'large' ? (
                        <Minimize2 className="size-3.5" />
                      ) : (
                        <Maximize2 className="size-3.5" />
                      )}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">
                    <p>Resize ({chatSize})</p>
                  </TooltipContent>
                </Tooltip>

                {/* Clear chat */}
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleClearChat}
                      className="size-7 text-muted-foreground hover:text-foreground"
                      aria-label="Clear chat"
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">
                    <p>Clear chat</p>
                  </TooltipContent>
                </Tooltip>

                {/* Close */}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="size-7 text-muted-foreground hover:text-foreground"
                  aria-label="Minimize chat"
                >
                  <X className="size-3.5" />
                </Button>
              </div>
            </div>

            {/* Messages Area */}
            <ScrollArea ref={scrollRef} className="flex-1 min-h-0">
              <div className="p-4 space-y-3">
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                    className={`flex ${
                      msg.role === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    <div
                      className={`max-w-[85%] px-4 py-2.5 text-sm leading-relaxed ${
                        msg.role === 'user'
                          ? 'bg-gradient-to-br from-emerald-500 to-teal-500 text-white rounded-2xl rounded-br-md shadow-md shadow-emerald-500/20'
                          : 'bg-background/60 backdrop-blur-sm text-foreground rounded-2xl rounded-bl-md border border-white/10 dark:border-white/5'
                      }`}
                    >
                      {msg.content}
                    </div>
                  </motion.div>
                ))}

                {/* Typing Indicator */}
                {isLoading && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex justify-start"
                  >
                    <div className="bg-background/60 backdrop-blur-sm rounded-2xl rounded-bl-md border border-white/10 dark:border-white/5">
                      <TypingIndicator />
                    </div>
                  </motion.div>
                )}

                {/* Suggested Prompts - show when few messages */}
                {messages.length <= 2 && !isLoading && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    className="flex flex-col gap-2 pt-2"
                  >
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold px-1">
                      Suggested
                    </p>
                    {SUGGESTED_PROMPTS.map((prompt) => (
                      <button
                        key={prompt.label}
                        onClick={() => handleQuickAction(prompt.prompt)}
                        className="flex items-center gap-2.5 text-left text-xs px-3 py-2.5 rounded-xl border border-emerald-500/20 hover:border-emerald-500/40 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 transition-colors group"
                      >
                        <prompt.icon className="size-4 shrink-0 group-hover:scale-110 transition-transform text-emerald-500" />
                        <span className="font-medium">{prompt.label}</span>
                      </button>
                    ))}
                  </motion.div>
                )}
              </div>
            </ScrollArea>

            {/* Input Area */}
            <div className="border-t border-white/10 dark:border-white/5 p-3 bg-background/40 backdrop-blur-md">
              <form onSubmit={handleSubmit} className="flex items-center gap-2">
                <Input
                  ref={inputRef}
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Ask me anything..."
                  disabled={isLoading}
                  className="flex-1 text-sm bg-background/60 border-white/10 dark:border-white/5 focus-visible:ring-emerald-500/30 backdrop-blur-sm"
                />
                <Button
                  type="submit"
                  size="icon"
                  disabled={isLoading || !inputValue.trim()}
                  className="size-9 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white shrink-0 shadow-md shadow-emerald-500/25"
                  aria-label="Send message"
                >
                  {isLoading ? (
                    <Loader2 className="size-4 animate-spin" />
                  ) : (
                    <Send className="size-4" />
                  )}
                </Button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
