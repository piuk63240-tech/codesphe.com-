'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  Zap,
  Brain,
  Shield,
  BarChart3,
  Code2,
  Users,
} from 'lucide-react'

const features = [
  {
    icon: Brain,
    title: 'AI-Powered Intelligence',
    description:
      'Advanced AI models analyze your inputs to generate comprehensive, actionable insights for your SaaS business.',
  },
  {
    icon: Zap,
    title: 'Instant Results',
    description:
      'Get results in seconds, not hours. Our AI tools process your inputs and deliver insights instantly.',
  },
  {
    icon: Shield,
    title: 'Validated Ideas',
    description:
      'Don\'t waste time on unvalidated ideas. Get comprehensive validation with market data and competitive analysis.',
  },
  {
    icon: BarChart3,
    title: 'Data-Driven Insights',
    description:
      'Make decisions backed by data. Market analysis, competitor research, and business modeling all powered by AI.',
  },
  {
    icon: Code2,
    title: 'Production Ready',
    description:
      'From idea to code in minutes. Generate production-ready scaffolding, prompts, and landing page copy.',
  },
  {
    icon: Users,
    title: 'Built for Founders',
    description:
      'Designed specifically for SaaS founders, indie hackers, and product builders who want to move fast.',
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="py-20 sm:py-28 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Why Choose <span className="animated-gradient-text">Antigravity AI</span>?
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            Everything you need to go from idea to launch, powered by
            cutting-edge <span className="text-emerald-600 dark:text-emerald-400 font-medium">AI technology</span>.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.4, delay: index * 0.08 }}
                className="group"
              >
                <div className="relative rounded-xl border bg-card/80 backdrop-blur-sm p-6 h-full transition-all duration-300 hover:shadow-lg hover:border-emerald-200 dark:hover:border-emerald-800/50 overflow-hidden">
                  {/* Emerald gradient line at top */}
                  <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-emerald-400 via-teal-400 to-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                  {/* Subtle gradient background on hover */}
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/[0.03] to-teal-500/[0.03] dark:from-emerald-500/[0.06] dark:to-teal-500/[0.06] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                  {/* Number counter in top-right */}
                  <span className="absolute top-4 right-4 text-xs font-mono text-muted-foreground/30 select-none">
                    {String(index + 1).padStart(2, '0')}
                  </span>

                  {/* Content */}
                  <div className="relative z-10">
                    <div className="flex size-12 items-center justify-center rounded-lg bg-emerald-50 dark:bg-emerald-900/20 mb-4 group-hover:bg-gradient-to-br group-hover:from-emerald-100 group-hover:to-teal-100 dark:group-hover:from-emerald-900/40 dark:group-hover:to-teal-900/40 group-hover:scale-110 group-hover:rotate-[5deg] transition-all duration-500">
                      <Icon className="size-6 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <h3 className="text-lg font-semibold text-card-foreground mb-2 group-hover:text-emerald-700 dark:group-hover:text-emerald-300 transition-colors duration-300">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
