'use client'

import * as React from 'react'
import { motion, useInView, AnimatePresence } from 'framer-motion'
import { Check, X, Sparkles, Building2, Zap, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface PricingFeature {
  text: string
  included: boolean
}

interface PricingTier {
  name: string
  price: { monthly: number; annual: number }
  description: string
  icon: React.ReactNode
  badge?: string
  features: PricingFeature[]
  buttonText: string
  buttonVariant: 'default' | 'outline'
  highlighted: boolean
  premium: boolean
}

const tiers: PricingTier[] = [
  {
    name: 'Starter',
    price: { monthly: 0, annual: 0 },
    description: 'Perfect for exploring AI-powered tools and getting started.',
    icon: <Zap className="size-5" />,
    features: [
      { text: '5 AI generations/day', included: true },
      { text: '3 tools available', included: true },
      { text: 'Basic results', included: true },
      { text: 'Community support', included: true },
      { text: 'Unlimited generations', included: false },
      { text: 'Advanced analysis', included: false },
      { text: 'Export & share', included: false },
      { text: 'Save unlimited ideas', included: false },
    ],
    buttonText: 'Get Started',
    buttonVariant: 'default',
    highlighted: false,
    premium: false,
  },
  {
    name: 'Pro',
    price: { monthly: 29, annual: 23 },
    description: 'For serious founders who want unlimited AI power.',
    icon: <Sparkles className="size-5" />,
    badge: 'Most Popular',
    features: [
      { text: 'Unlimited AI generations', included: true },
      { text: 'All 10 tools available', included: true },
      { text: 'Advanced results with analysis', included: true },
      { text: 'Priority support', included: true },
      { text: 'Export & share results', included: true },
      { text: 'Save unlimited ideas', included: true },
      { text: 'Custom AI models', included: false },
      { text: 'API access', included: false },
    ],
    buttonText: 'Get Started',
    buttonVariant: 'default',
    highlighted: true,
    premium: false,
  },
  {
    name: 'Enterprise',
    price: { monthly: 99, annual: 79 },
    description: 'For teams that need custom AI solutions at scale.',
    icon: <Building2 className="size-5" />,
    features: [
      { text: 'Everything in Pro', included: true },
      { text: 'Custom AI models', included: true },
      { text: 'API access', included: true },
      { text: 'Dedicated support', included: true },
      { text: 'Team collaboration', included: true },
      { text: 'Custom integrations', included: true },
      { text: 'Unlimited generations', included: true },
      { text: 'Advanced security', included: true },
    ],
    buttonText: 'Contact Sales',
    buttonVariant: 'outline',
    highlighted: false,
    premium: true,
  },
]

// ── Animated checkmark icon ──────────────────────────────────────────────────
function AnimatedCheck({ delay = 0 }: { delay?: number }) {
  const ref = React.useRef<HTMLSpanElement>(null)
  const inView = useInView(ref, { once: true })

  return (
    <span ref={ref} className="shrink-0 mt-0.5">
      <motion.span
        initial={{ scale: 0, opacity: 0 }}
        animate={inView ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 400, damping: 15, delay }}
        className="inline-flex items-center justify-center"
      >
        <Check className="size-4 text-emerald-500" />
      </motion.span>
    </span>
  )
}

function PricingCard({
  tier,
  annual,
  index,
}: {
  tier: PricingTier
  annual: boolean
  index: number
}) {
  const price = annual ? tier.price.annual : tier.price.monthly
  const cardRef = React.useRef<HTMLDivElement>(null)
  const [isHovered, setIsHovered] = React.useState(false)

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5, delay: index * 0.12 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className={`relative flex flex-col rounded-2xl p-[1.5px] ${
        tier.highlighted
          ? 'scale-100 md:scale-105 z-10'
          : ''
      }`}
    >
      {/* Animated gradient border for Pro tier */}
      {tier.highlighted && (
        <div className="absolute inset-0 rounded-2xl overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-400 via-teal-400 to-emerald-500" />
          {/* Rotating gradient overlay for animated effect */}
          <motion.div
            className="absolute inset-[-50%]"
            animate={{ rotate: 360 }}
            transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
            style={{
              background: 'conic-gradient(from 0deg, transparent 0%, rgba(255,255,255,0.3) 10%, transparent 20%)',
            }}
          />
        </div>
      )}

      {/* Glassmorphism border for Enterprise */}
      {tier.premium && (
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 via-emerald-300/30 to-teal-300/20 dark:from-white/10 dark:via-emerald-500/20 dark:to-teal-500/10" />
      )}

      {/* Subtle border for Starter */}
      {!tier.highlighted && !tier.premium && (
        <div className="absolute inset-0 rounded-2xl bg-border" />
      )}

      <motion.div
        className={`relative flex flex-col h-full rounded-2xl ${
          tier.premium
            ? 'bg-card/80 backdrop-blur-xl'
            : 'bg-card'
        } ${tier.highlighted ? 'shadow-xl shadow-emerald-500/20' : 'shadow-sm'}`}
        style={{
          transition: 'transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.4s ease-out',
          transform: isHovered ? 'translateY(-8px)' : 'translateY(0)',
          boxShadow: isHovered
            ? tier.highlighted
              ? '0 20px 40px rgba(16, 185, 129, 0.2), 0 8px 16px rgba(0,0,0,0.1)'
              : '0 16px 32px rgba(0,0,0,0.1), 0 4px 8px rgba(0,0,0,0.05)'
            : undefined,
        }}
      >
        {/* Glowing shadow for Pro - enhanced glow */}
        {tier.highlighted && (
          <motion.div
            className="absolute -inset-2 rounded-2xl blur-2xl -z-10"
            animate={{
              boxShadow: isHovered
                ? '0 0 40px rgba(16, 185, 129, 0.3), 0 0 80px rgba(20, 184, 166, 0.15)'
                : '0 0 20px rgba(16, 185, 129, 0.15), 0 0 40px rgba(20, 184, 166, 0.08)',
            }}
            transition={{ duration: 0.4 }}
            style={{
              background: 'linear-gradient(135deg, rgba(16,185,129,0.2), rgba(20,184,166,0.2), rgba(16,185,129,0.2))',
            }}
          />
        )}

        {/* Hover glow border for non-highlighted cards */}
        {!tier.highlighted && (
          <div className="absolute -inset-[1px] rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-400/40 via-teal-400/40 to-emerald-400/40" />
          </div>
        )}

        {/* Most Popular ribbon for Pro card */}
        {tier.highlighted && (
          <div className="absolute -right-1 top-6 z-20">
            <div className="relative">
              <div className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-l-sm shadow-lg flex items-center gap-1">
                <Sparkles className="size-3" />
                Most Popular
              </div>
              {/* Ribbon fold */}
              <div className="absolute -bottom-1.5 right-0 w-0 h-0 border-l-[6px] border-l-emerald-700/30 border-b-[6px] border-b-transparent" />
            </div>
          </div>
        )}

        <div className="p-6 sm:p-8 flex flex-col h-full">
          {/* Badge (moved to ribbon, but keep for non-highlighted) */}
          {!tier.highlighted && tier.badge && (
            <div className="inline-flex self-start items-center gap-1.5 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 px-3 py-1 text-xs font-semibold text-white mb-4">
              <Sparkles className="size-3" />
              {tier.badge}
            </div>
          )}

          {/* Icon + Name */}
          <div className="flex items-center gap-3 mb-2">
            <div
              className={`flex size-10 items-center justify-center rounded-lg ${
                tier.highlighted
                  ? 'bg-gradient-to-br from-emerald-500 to-teal-500 text-white'
                  : tier.premium
                    ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400'
                    : 'bg-muted text-muted-foreground'
              }`}
            >
              {tier.icon}
            </div>
            <h3 className="text-xl font-bold text-card-foreground">
              {tier.name}
            </h3>
          </div>

          {/* Description */}
          <p className="text-sm text-muted-foreground mb-6">
            {tier.description}
          </p>

          {/* Price */}
          <div className="mb-6">
            <div className="flex items-baseline gap-1">
              <AnimatePresence mode="wait">
                <motion.span
                  key={`${tier.name}-${price}`}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  transition={{ duration: 0.2 }}
                  className="text-4xl sm:text-5xl font-extrabold text-card-foreground"
                >
                  ${price}
                </motion.span>
              </AnimatePresence>
              <span className="text-sm text-muted-foreground">/mo</span>
            </div>
            {annual && tier.price.monthly > 0 && (
              <div className="flex items-center gap-2 mt-1.5">
                <span className="inline-flex items-center rounded-full bg-emerald-100 dark:bg-emerald-900/30 px-2 py-0.5 text-[10px] font-bold text-emerald-700 dark:text-emerald-400">
                  Save 20%
                </span>
                <p className="text-xs text-emerald-600 dark:text-emerald-400">
                  ${(tier.price.monthly - tier.price.annual) * 12}/year savings
                </p>
              </div>
            )}
          </div>

          {/* CTA Button */}
          <Button
            className={`w-full mb-6 ${
              tier.highlighted
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white shadow-lg shadow-emerald-500/25'
                : tier.premium
                  ? ''
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white'
            }`}
            variant={tier.buttonVariant}
            size="lg"
          >
            {tier.buttonText}
          </Button>

          {/* Features */}
          <ul className="space-y-3 mt-auto" role="list">
            {tier.features.map((feature, featureIndex) => (
              <li key={feature.text} className="flex items-start gap-3">
                {feature.included ? (
                  <AnimatedCheck delay={featureIndex * 0.05 + 0.2} />
                ) : (
                  <X className="size-4 mt-0.5 shrink-0 text-muted-foreground/40" />
                )}
                <span
                  className={`text-sm ${
                    feature.included
                      ? 'text-card-foreground'
                      : 'text-muted-foreground/50'
                  }`}
                >
                  {feature.text}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </motion.div>
    </motion.div>
  )
}

// ── Guarantee Section ────────────────────────────────────────────────────────
function GuaranteeSection() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="mt-12 text-center"
    >
      <div className="inline-flex items-center gap-3 rounded-xl border border-emerald-200 dark:border-emerald-800/50 bg-emerald-50/50 dark:bg-emerald-900/10 px-6 py-4">
        <div className="flex size-10 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 text-white shadow-lg shadow-emerald-500/25">
          <Shield className="size-5" />
        </div>
        <div className="text-left">
          <p className="text-sm font-semibold text-card-foreground">30-Day Money-Back Guarantee</p>
          <p className="text-xs text-muted-foreground">
            Not satisfied? Get a full refund within 30 days, no questions asked.
          </p>
        </div>
      </div>
    </motion.div>
  )
}

export function PricingSection() {
  const [annual, setAnnual] = React.useState(false)

  return (
    <section className="py-20 sm:py-28 bg-muted/30" id="pricing" aria-labelledby="pricing-heading">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2
            id="pricing-heading"
            className="text-3xl sm:text-4xl font-bold text-foreground mb-4"
            aria-label="Simple, Transparent Pricing"
          >
            Simple, Transparent{' '}
            <span className="bg-gradient-to-r from-emerald-500 to-teal-500 bg-clip-text text-transparent">
              Pricing
            </span>
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            Choose the plan that fits your ambition. Upgrade or downgrade at any
            time.
          </p>
        </motion.div>

        {/* Annual Toggle */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: 0.15 }}
          className="flex items-center justify-center gap-3 mb-12"
        >
          <span
            className={`text-sm font-medium transition-colors duration-300 ${
              !annual ? 'text-foreground' : 'text-muted-foreground'
            }`}
          >
            Monthly
          </span>
          <button
            type="button"
            role="switch"
            aria-checked={annual}
            aria-label="Toggle annual pricing"
            onClick={() => setAnnual(!annual)}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-300 ease-in-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 ${
              annual ? 'bg-emerald-500' : 'bg-muted-foreground/30'
            }`}
          >
            <motion.span
              className="pointer-events-none inline-block size-5 rounded-full bg-white shadow-sm ring-0"
              animate={{
                translateX: annual ? 20 : 0,
              }}
              transition={{
                type: 'spring',
                stiffness: 500,
                damping: 30,
              }}
            />
          </button>
          <span
            className={`text-sm font-medium transition-colors duration-300 ${
              annual ? 'text-foreground' : 'text-muted-foreground'
            }`}
          >
            Annual
          </span>
          <AnimatePresence>
            {annual && (
              <motion.span
                initial={{ opacity: 0, scale: 0.8, x: -10 }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.8, x: -10 }}
                transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                className="inline-flex items-center rounded-full bg-emerald-100 dark:bg-emerald-900/30 px-2.5 py-0.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400"
              >
                Save 20%
              </motion.span>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 items-start">
          {tiers.map((tier, index) => (
            <PricingCard
              key={tier.name}
              tier={tier}
              annual={annual}
              index={index}
            />
          ))}
        </div>

        {/* Guarantee */}
        <GuaranteeSection />
      </div>
    </section>
  )
}
