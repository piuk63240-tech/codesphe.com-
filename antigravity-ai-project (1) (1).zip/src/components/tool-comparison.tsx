'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  GitCompareArrows,
  X,
  Check,
  Star,
  History,
  ChevronDown,
  ArrowUpDown,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { tools, type ToolConfig } from '@/components/tools-grid'

interface ComparisonData {
  category: string
  bestFor: string
  inputFields: string
  outputType: string
  useCase: string
  difficulty: string
  speedScore: number
  depthScore: number
  usabilityScore: number
}

interface HistoryItem {
  id: string
  toolType: string
  input: string
  output: string
  rating: number | null
  createdAt: string
}

const toolComparisonData: Record<string, ComparisonData> = {
  'idea-generator': {
    category: 'Ideation',
    bestFor: 'Startup founders exploring new business ideas',
    inputFields: 'Industry, Focus Area, Budget, Timeline',
    outputType: 'Structured idea list with market analysis',
    useCase: 'Brainstorming AI SaaS concepts',
    difficulty: 'Beginner',
    speedScore: 9,
    depthScore: 7,
    usabilityScore: 10,
  },
  'prompt-generator': {
    category: 'Content',
    bestFor: 'Content creators and prompt engineers',
    inputFields: 'Purpose, AI Model, Style, Context',
    outputType: 'Optimized prompts with tips',
    useCase: 'Creating effective AI prompts',
    difficulty: 'Beginner',
    speedScore: 10,
    depthScore: 6,
    usabilityScore: 9,
  },
  'idea-validator': {
    category: 'Validation',
    bestFor: 'Founders validating business assumptions',
    inputFields: 'Idea Name, Description, Target Market, Stage',
    outputType: 'Comprehensive validation report with scores',
    useCase: 'Testing business viability before building',
    difficulty: 'Intermediate',
    speedScore: 7,
    depthScore: 10,
    usabilityScore: 8,
  },
  'market-analyzer': {
    category: 'Research',
    bestFor: 'Product managers assessing market opportunities',
    inputFields: 'Product, Industry, Region, Audience',
    outputType: 'Market analysis with size, trends, personas',
    useCase: 'Understanding market landscape',
    difficulty: 'Intermediate',
    speedScore: 7,
    depthScore: 9,
    usabilityScore: 8,
  },
  'competitor-research': {
    category: 'Research',
    bestFor: 'Strategy teams analyzing competition',
    inputFields: 'Market Space, Product Type, Region',
    outputType: 'Competitor profiles with feature matrix',
    useCase: 'Identifying market gaps and differentiation',
    difficulty: 'Intermediate',
    speedScore: 7,
    depthScore: 9,
    usabilityScore: 7,
  },
  'tech-stack-recommender': {
    category: 'Development',
    bestFor: 'Developers and CTOs planning tech architecture',
    inputFields: 'Description, Team Size, Scale, Budget',
    outputType: 'Full tech stack with justifications',
    useCase: 'Choosing the right technology for your project',
    difficulty: 'Advanced',
    speedScore: 6,
    depthScore: 9,
    usabilityScore: 7,
  },
  'business-model-generator': {
    category: 'Strategy',
    bestFor: 'Entrepreneurs designing business models',
    inputFields: 'Product Name, Description, Target Market, Pricing',
    outputType: 'Business model canvas with pricing tiers',
    useCase: 'Planning revenue streams and cost structure',
    difficulty: 'Intermediate',
    speedScore: 7,
    depthScore: 8,
    usabilityScore: 8,
  },
  'code-scaffolder': {
    category: 'Development',
    bestFor: 'Developers starting new projects',
    inputFields: 'App Description, Tech Preferences, Features, Scale',
    outputType: 'Project structure and code templates',
    useCase: 'Jumpstarting development with boilerplate',
    difficulty: 'Advanced',
    speedScore: 5,
    depthScore: 10,
    usabilityScore: 6,
  },
  'landing-page-optimizer': {
    category: 'Marketing',
    bestFor: 'Marketers optimizing conversion rates',
    inputFields: 'Product Name, Description, Audience, Tone',
    outputType: 'Landing page copy and structure',
    useCase: 'Creating high-converting landing pages',
    difficulty: 'Beginner',
    speedScore: 8,
    depthScore: 7,
    usabilityScore: 9,
  },
  'pitch-deck-generator': {
    category: 'Strategy',
    bestFor: 'Founders preparing investor presentations',
    inputFields: 'Company Name, Description, Stage, Market Size',
    outputType: 'Pitch deck outline with slide content',
    useCase: 'Raising funding with compelling narratives',
    difficulty: 'Intermediate',
    speedScore: 7,
    depthScore: 8,
    usabilityScore: 8,
  },
}

const COMPARISON_CRITERIA: { key: keyof ComparisonData; label: string; type?: 'score' | 'text' }[] = [
  { key: 'category', label: 'Category' },
  { key: 'bestFor', label: 'Best For' },
  { key: 'inputFields', label: 'Input Fields' },
  { key: 'outputType', label: 'Output Type' },
  { key: 'useCase', label: 'Use Case' },
  { key: 'difficulty', label: 'Difficulty Level' },
  { key: 'speedScore', label: 'Speed', type: 'score' },
  { key: 'depthScore', label: 'Depth', type: 'score' },
  { key: 'usabilityScore', label: 'Usability', type: 'score' },
]

function DifficultyBadge({ level }: { level: string }) {
  const colorMap: Record<string, string> = {
    Beginner: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
    Intermediate: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
    Advanced: 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400',
  }
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
        colorMap[level] || 'bg-muted text-muted-foreground'
      }`}
    >
      {level}
    </span>
  )
}

function ScoreBar({ value, maxValue = 10 }: { value: number; maxValue?: number }) {
  const percentage = (value / maxValue) * 100
  const color =
    value >= 8
      ? 'from-emerald-500 to-teal-500'
      : value >= 6
        ? 'from-amber-500 to-amber-400'
        : 'from-rose-500 to-rose-400'

  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden min-w-[60px]">
        <motion.div
          className={`h-full rounded-full bg-gradient-to-r ${color}`}
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.6, delay: 0.2 }}
        />
      </div>
      <span className="text-xs font-semibold text-foreground w-5 text-right">{value}</span>
    </div>
  )
}

function ScoreCheckmark({ value, best }: { value: number; best: boolean }) {
  return (
    <div className="flex items-center gap-1.5">
      {best && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 400, damping: 15 }}
        >
          <Check className="size-4 text-emerald-500" />
        </motion.div>
      )}
      <ScoreBar value={value} />
    </div>
  )
}

interface ToolComparisonProps {
  onClose: () => void
  compareToolIds?: string[]
  historyItems?: HistoryItem[]
  onViewHistoryResult?: (item: HistoryItem) => void
}

export function ToolComparison({
  onClose,
  compareToolIds,
  historyItems = [],
  onViewHistoryResult,
}: ToolComparisonProps) {
  const [selectedIds, setSelectedIds] = React.useState<string[]>(
    compareToolIds?.length ? compareToolIds.slice(0, 3) : ['', '', '']
  )
  const [showHistorySelect, setShowHistorySelect] = React.useState(false)
  const [compareHistoryIds, setCompareHistoryIds] = React.useState<string[]>([])
  const [activeView, setActiveView] = React.useState<'tools' | 'results'>('tools')

  const handleSelect = (index: number, value: string) => {
    setSelectedIds((prev) => {
      const next = [...prev]
      next[index] = value === '_none' ? '' : value
      return next
    })
  }

  const selectedTools = selectedIds
    .filter(Boolean)
    .map((id) => tools.find((t) => t.id === id))
    .filter(Boolean) as ToolConfig[]

  const availableForSlot = (slotIndex: number) => {
    const otherSelected = selectedIds.filter((_, i) => i !== slotIndex && _)
    return tools.filter((t) => !otherSelected.includes(t.id))
  }

  // Get best score for a given criterion among selected tools
  const getBestScore = (key: keyof ComparisonData): number => {
    const scores = selectedTools
      .map((t) => toolComparisonData[t.id]?.[key])
      .filter((v): v is number => typeof v === 'number')
    return scores.length > 0 ? Math.max(...scores) : 0
  }

  // History items for comparison
  const selectedHistoryItems = compareHistoryIds
    .map((id) => historyItems.find((h) => h.id === id))
    .filter(Boolean) as HistoryItem[]

  const getToolConfig = (toolType: string) => {
    return tools.find((t) => t.id === toolType)
  }

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.3 }}
      className="overflow-hidden"
    >
      <div className="rounded-xl border border-emerald-500/20 bg-card/80 backdrop-blur-sm p-6 mb-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <div className="size-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
              <GitCompareArrows className="size-4 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">
              Compare Tools
            </h3>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="size-8 text-muted-foreground hover:text-foreground"
            aria-label="Close comparison"
          >
            <X className="size-4" />
          </Button>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-2 mb-5">
          <Button
            variant={activeView === 'tools' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setActiveView('tools')}
            className={`text-xs rounded-full ${
              activeView === 'tools'
                ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
                : 'hover:border-emerald-300 dark:hover:border-emerald-700'
            }`}
          >
            <ArrowUpDown className="size-3.5 mr-1.5" />
            Compare Specs
          </Button>
          {historyItems.length > 0 && (
            <Button
              variant={activeView === 'results' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setActiveView('results')}
              className={`text-xs rounded-full ${
                activeView === 'results'
                  ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
                  : 'hover:border-emerald-300 dark:hover:border-emerald-700'
              }`}
            >
              <History className="size-3.5 mr-1.5" />
              Compare Results
            </Button>
          )}
        </div>

        {activeView === 'tools' ? (
          <>
            {/* Tool Selectors */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
              {selectedIds.map((id, index) => (
                <Select
                  key={index}
                  value={id || '_none'}
                  onValueChange={(value) => handleSelect(index, value)}
                >
                  <SelectTrigger className="w-full border-emerald-500/20 focus:ring-emerald-500/30">
                    <SelectValue placeholder={`Select tool ${index + 1}`} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="_none">None</SelectItem>
                    {availableForSlot(index).map((tool) => (
                      <SelectItem key={tool.id} value={tool.id}>
                        <div className="flex items-center gap-2">
                          <div
                            className={`size-5 rounded ${tool.iconBg} flex items-center justify-center`}
                          >
                            <tool.icon className="size-2.5 text-white" />
                          </div>
                          {tool.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ))}
            </div>

            {/* Comparison Table */}
            {selectedTools.length > 0 ? (
              <div className="overflow-x-auto -mx-2">
                <table className="w-full min-w-[500px]">
                  <thead>
                    <tr className="border-b border-emerald-500/10">
                      <th className="text-left text-xs font-medium text-muted-foreground py-3 px-3 w-32">
                        Criteria
                      </th>
                      {selectedTools.map((tool) => (
                        <th
                          key={tool.id}
                          className="text-left text-sm font-semibold text-foreground py-3 px-3"
                        >
                          <div className="flex items-center gap-2">
                            <div
                              className={`size-7 rounded-md ${tool.iconBg} flex items-center justify-center shrink-0`}
                            >
                              <tool.icon className="size-3.5 text-white" />
                            </div>
                            <span className="truncate">{tool.name}</span>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {COMPARISON_CRITERIA.map(({ key, label, type }) => (
                      <tr
                        key={key}
                        className="border-b border-border/50 last:border-0"
                      >
                        <td className="text-xs font-medium text-muted-foreground py-3 px-3">
                          {label}
                        </td>
                        {selectedTools.map((tool) => {
                          const data = toolComparisonData[tool.id]
                          const value = data?.[key]
                          const isBest =
                            type === 'score' &&
                            typeof value === 'number' &&
                            value === getBestScore(key)

                          return (
                            <td
                              key={tool.id}
                              className={`text-sm py-3 px-3 ${
                                isBest ? 'bg-emerald-50/50 dark:bg-emerald-900/10' : ''
                              }`}
                            >
                              {key === 'difficulty' ? (
                                <DifficultyBadge level={String(value || 'N/A')} />
                              ) : type === 'score' ? (
                                <ScoreCheckmark
                                  value={Number(value || 0)}
                                  best={!!isBest}
                                />
                              ) : (
                                <span className="text-foreground">{String(value || 'N/A')}</span>
                              )}
                            </td>
                          )
                        })}
                      </tr>
                    ))}
                    {/* Overall Score Row */}
                    <tr className="border-t-2 border-emerald-500/20">
                      <td className="text-xs font-bold text-foreground py-3 px-3">
                        Overall Score
                      </td>
                      {selectedTools.map((tool) => {
                        const data = toolComparisonData[tool.id]
                        if (!data) return <td key={tool.id} className="py-3 px-3">N/A</td>
                        const overall = Math.round(
                          (data.speedScore + data.depthScore + data.usabilityScore) / 3
                        )
                        const allOveralls = selectedTools.map((t) => {
                          const d = toolComparisonData[t.id]
                          return d ? Math.round((d.speedScore + d.depthScore + d.usabilityScore) / 3) : 0
                        })
                        const isBest = overall === Math.max(...allOveralls)

                        return (
                          <td
                            key={tool.id}
                            className={`py-3 px-3 ${
                              isBest ? 'bg-emerald-50/50 dark:bg-emerald-900/10' : ''
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              {isBest && (
                                <motion.div
                                  initial={{ scale: 0 }}
                                  animate={{ scale: 1 }}
                                  transition={{ type: 'spring', stiffness: 400, damping: 15 }}
                                >
                                  <Star className="size-4 fill-amber-400 text-amber-400" />
                                </motion.div>
                              )}
                              <div>
                                <div className="text-lg font-bold text-foreground">
                                  {overall}/10
                                </div>
                                <ScoreBar value={overall} />
                              </div>
                            </div>
                          </td>
                        )
                      })}
                    </tr>
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <GitCompareArrows className="size-10 text-muted-foreground/30 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">
                  Select up to 3 tools above to compare them side by side
                </p>
              </div>
            )}
          </>
        ) : (
          /* Results Comparison View */
          <>
            {/* History item selectors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
              {compareHistoryIds.length < 2 && (
                <p className="text-xs text-muted-foreground col-span-full">
                  Select 2 results from your history to compare outputs side by side.
                </p>
              )}
              {[0, 1].map((index) => (
                <Select
                  key={index}
                  value={compareHistoryIds[index] || '_none'}
                  onValueChange={(value) => {
                    setCompareHistoryIds((prev) => {
                      const next = [...prev]
                      if (value === '_none') {
                        next.splice(index, 1)
                      } else {
                        next[index] = value
                      }
                      return next
                    })
                  }}
                >
                  <SelectTrigger className="w-full border-emerald-500/20 focus:ring-emerald-500/30">
                    <SelectValue placeholder={`Select result ${index + 1}`} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="_none">None</SelectItem>
                    {historyItems
                      .filter(
                        (h) =>
                          !compareHistoryIds.includes(h.id) ||
                          compareHistoryIds[index] === h.id
                      )
                      .map((item) => {
                        const toolConfig = getToolConfig(item.toolType)
                        return (
                          <SelectItem key={item.id} value={item.id}>
                            <div className="flex items-center gap-2">
                              {toolConfig && (
                                <div
                                  className={`size-5 rounded ${toolConfig.iconBg} flex items-center justify-center`}
                                >
                                  <toolConfig.icon className="size-2.5 text-white" />
                                </div>
                              )}
                              <span className="truncate">
                                {toolConfig?.name || item.toolType} -{' '}
                                {new Date(item.createdAt).toLocaleDateString()}
                              </span>
                              {item.rating && (
                                <Badge
                                  variant="outline"
                                  className="text-[10px] px-1.5 py-0"
                                >
                                  <Star className="size-2.5 fill-amber-400 text-amber-400 mr-0.5" />
                                  {item.rating}
                                </Badge>
                              )}
                            </div>
                          </SelectItem>
                        )
                      })}
                  </SelectContent>
                </Select>
              ))}
            </div>

            {/* Side-by-side result comparison */}
            {selectedHistoryItems.length === 2 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {selectedHistoryItems.map((item, index) => {
                  const toolConfig = getToolConfig(item.toolType)
                  const Icon = toolConfig?.icon || History
                  const iconBg =
                    toolConfig?.iconBg ||
                    'bg-gradient-to-br from-emerald-500 to-teal-500'
                  const name = toolConfig?.name || item.toolType

                  return (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="rounded-xl border border-border/50 bg-background/60 p-4"
                    >
                      {/* Result header */}
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div
                            className={`size-7 rounded-md ${iconBg} flex items-center justify-center`}
                          >
                            <Icon className="size-3.5 text-white" />
                          </div>
                          <div>
                            <span className="text-sm font-semibold text-foreground">
                              {name}
                            </span>
                            <p className="text-[10px] text-muted-foreground">
                              {new Date(item.createdAt).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        {item.rating && (
                          <div className="flex items-center gap-0.5">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`size-3 ${
                                  star <= (item.rating || 0)
                                    ? 'fill-amber-400 text-amber-400'
                                    : 'text-muted-foreground/30'
                                }`}
                              />
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Input summary */}
                      <div className="mb-3 p-2 rounded-lg bg-muted/50 text-xs text-muted-foreground">
                        <span className="font-medium text-foreground">Input: </span>
                        {typeof item.input === 'string'
                          ? item.input.substring(0, 100)
                          : JSON.stringify(item.input).substring(0, 100)}
                        ...
                      </div>

                      {/* Output preview */}
                      <div className="text-xs text-foreground leading-relaxed max-h-48 overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-muted">
                        {item.output.substring(0, 500)}
                        {item.output.length > 500 && (
                          <span className="text-muted-foreground">...</span>
                        )}
                      </div>

                      {/* View full result button */}
                      {onViewHistoryResult && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onViewHistoryResult(item)}
                          className="w-full mt-3 text-xs text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
                        >
                          View Full Result
                        </Button>
                      )}
                    </motion.div>
                  )
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <History className="size-10 text-muted-foreground/30 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">
                  Select 2 results from your history to compare them
                </p>
              </div>
            )}
          </>
        )}
      </div>
    </motion.div>
  )
}
