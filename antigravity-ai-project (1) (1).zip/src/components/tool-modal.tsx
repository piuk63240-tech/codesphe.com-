'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import type { LucideIcon } from 'lucide-react'
import { Sparkles, Loader2, AlertCircle, RefreshCw, PlusCircle, Maximize2, RotateCw, Palette, Shuffle, Clock, Lightbulb, GitCompareArrows } from 'lucide-react'
import { toast } from 'sonner'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { ResultPanel } from '@/components/result-panel'
import { FullscreenResultDialog } from '@/components/fullscreen-result-dialog'
import { ResultComparison } from '@/components/result-comparison'
import { useRecentInputsStore } from '@/store/app-store'
import type { ToolConfig } from '@/components/tool-card'

interface ToolModalProps {
  tool: ToolConfig | null
  open: boolean
  onClose: () => void
}

interface FieldConfig {
  key: string
  label: string
  type: 'text' | 'textarea' | 'select'
  placeholder?: string
  options?: { value: string; label: string }[]
}

const toolFieldConfigs: Record<string, FieldConfig[]> = {
  'idea-generator': [
    {
      key: 'industry',
      label: 'Industry',
      type: 'select',
      options: [
        { value: 'technology', label: 'Technology' },
        { value: 'healthcare', label: 'Healthcare' },
        { value: 'finance', label: 'Finance' },
        { value: 'education', label: 'Education' },
        { value: 'ecommerce', label: 'E-Commerce' },
        { value: 'real-estate', label: 'Real Estate' },
        { value: 'media', label: 'Media & Entertainment' },
        { value: 'other', label: 'Other' },
      ],
    },
    {
      key: 'focusArea',
      label: 'Focus Area',
      type: 'text',
      placeholder: 'e.g., AI-powered customer support',
    },
    {
      key: 'budget',
      label: 'Budget Range',
      type: 'select',
      options: [
        { value: 'bootstrap', label: 'Bootstrap ($0 - $5K)' },
        { value: 'seed', label: 'Seed ($5K - $50K)' },
        { value: 'series-a', label: 'Series A ($50K - $500K)' },
        { value: 'enterprise', label: 'Enterprise ($500K+)' },
      ],
    },
    {
      key: 'timeline',
      label: 'Timeline',
      type: 'select',
      options: [
        { value: '1-month', label: '1 Month' },
        { value: '3-months', label: '3 Months' },
        { value: '6-months', label: '6 Months' },
        { value: '1-year', label: '1 Year' },
      ],
    },
  ],
  'prompt-generator': [
    {
      key: 'purpose',
      label: 'Purpose',
      type: 'text',
      placeholder: 'e.g., Write marketing copy for a SaaS product',
    },
    {
      key: 'aiModel',
      label: 'AI Model',
      type: 'select',
      options: [
        { value: 'gpt-4', label: 'GPT-4' },
        { value: 'gpt-4o', label: 'GPT-4o' },
        { value: 'claude-3', label: 'Claude 3' },
        { value: 'gemini', label: 'Gemini' },
        { value: 'llama', label: 'Llama' },
        { value: 'general', label: 'General / Any' },
      ],
    },
    {
      key: 'style',
      label: 'Style',
      type: 'select',
      options: [
        { value: 'professional', label: 'Professional' },
        { value: 'creative', label: 'Creative' },
        { value: 'technical', label: 'Technical' },
        { value: 'casual', label: 'Casual' },
        { value: 'academic', label: 'Academic' },
      ],
    },
    {
      key: 'context',
      label: 'Additional Context',
      type: 'textarea',
      placeholder: 'Provide any additional context or requirements...',
    },
  ],
  'idea-validator': [
    {
      key: 'ideaName',
      label: 'Idea Name',
      type: 'text',
      placeholder: 'e.g., AIResumeBuilder Pro',
    },
    {
      key: 'ideaDescription',
      label: 'Idea Description',
      type: 'textarea',
      placeholder: 'Describe your business idea in detail...',
    },
    {
      key: 'targetMarket',
      label: 'Target Market',
      type: 'text',
      placeholder: 'e.g., Job seekers, career changers',
    },
    {
      key: 'currentStage',
      label: 'Current Stage',
      type: 'select',
      options: [
        { value: 'idea', label: 'Just an Idea' },
        { value: 'research', label: 'Research Phase' },
        { value: 'mvp', label: 'MVP Development' },
        { value: 'launched', label: 'Already Launched' },
        { value: 'scaling', label: 'Scaling' },
      ],
    },
  ],
  'market-analyzer': [
    {
      key: 'product',
      label: 'Product/Service',
      type: 'text',
      placeholder: 'e.g., AI-powered accounting software',
    },
    {
      key: 'industry',
      label: 'Industry',
      type: 'select',
      options: [
        { value: 'saas', label: 'SaaS' },
        { value: 'fintech', label: 'FinTech' },
        { value: 'healthtech', label: 'HealthTech' },
        { value: 'edtech', label: 'EdTech' },
        { value: 'martech', label: 'MarTech' },
        { value: 'other', label: 'Other' },
      ],
    },
    {
      key: 'region',
      label: 'Region',
      type: 'select',
      options: [
        { value: 'global', label: 'Global' },
        { value: 'north-america', label: 'North America' },
        { value: 'europe', label: 'Europe' },
        { value: 'asia-pacific', label: 'Asia Pacific' },
        { value: 'latin-america', label: 'Latin America' },
      ],
    },
    {
      key: 'targetAudience',
      label: 'Target Audience',
      type: 'text',
      placeholder: 'e.g., Small business owners, freelancers',
    },
  ],
  'competitor-research': [
    {
      key: 'marketSpace',
      label: 'Market Space',
      type: 'text',
      placeholder: 'e.g., Project management tools',
    },
    {
      key: 'productType',
      label: 'Product Type',
      type: 'text',
      placeholder: 'e.g., Cloud-based collaboration platform',
    },
    {
      key: 'region',
      label: 'Region',
      type: 'select',
      options: [
        { value: 'global', label: 'Global' },
        { value: 'north-america', label: 'North America' },
        { value: 'europe', label: 'Europe' },
        { value: 'asia-pacific', label: 'Asia Pacific' },
      ],
    },
  ],
  'tech-stack-recommender': [
    {
      key: 'productDescription',
      label: 'Product Description',
      type: 'textarea',
      placeholder: 'Describe your product and its main features...',
    },
    {
      key: 'teamSize',
      label: 'Team Size',
      type: 'select',
      options: [
        { value: 'solo', label: 'Solo Founder' },
        { value: 'small', label: 'Small Team (2-5)' },
        { value: 'medium', label: 'Medium Team (6-15)' },
        { value: 'large', label: 'Large Team (15+)' },
      ],
    },
    {
      key: 'scaleRequirements',
      label: 'Scale Requirements',
      type: 'select',
      options: [
        { value: 'mvp', label: 'MVP / Prototype' },
        { value: 'growth', label: 'Growth Stage' },
        { value: 'enterprise', label: 'Enterprise Scale' },
      ],
    },
    {
      key: 'budget',
      label: 'Budget',
      type: 'select',
      options: [
        { value: 'low', label: 'Low (Open Source Focus)' },
        { value: 'medium', label: 'Medium ($100-500/mo)' },
        { value: 'high', label: 'High ($500+/mo)' },
      ],
    },
  ],
  'business-model-generator': [
    {
      key: 'productName',
      label: 'Product Name',
      type: 'text',
      placeholder: 'e.g., DataSync Pro',
    },
    {
      key: 'productDescription',
      label: 'Product Description',
      type: 'textarea',
      placeholder: 'Describe your product and value proposition...',
    },
    {
      key: 'targetMarket',
      label: 'Target Market',
      type: 'text',
      placeholder: 'e.g., Mid-size B2B companies',
    },
    {
      key: 'pricingPreference',
      label: 'Pricing Preference',
      type: 'select',
      options: [
        { value: 'freemium', label: 'Freemium' },
        { value: 'subscription', label: 'Subscription' },
        { value: 'usage-based', label: 'Usage-Based' },
        { value: 'one-time', label: 'One-Time Purchase' },
        { value: 'hybrid', label: 'Hybrid' },
      ],
    },
  ],
  'code-scaffolder': [
    {
      key: 'appDescription',
      label: 'App Description',
      type: 'textarea',
      placeholder: 'Describe the application you want to build...',
    },
    {
      key: 'techPreferences',
      label: 'Tech Preferences',
      type: 'text',
      placeholder: 'e.g., React, Node.js, PostgreSQL',
    },
    {
      key: 'features',
      label: 'Key Features',
      type: 'textarea',
      placeholder: 'List the main features you need...',
    },
    {
      key: 'scale',
      label: 'Scale',
      type: 'select',
      options: [
        { value: 'small', label: 'Small (Single Page)' },
        { value: 'medium', label: 'Medium (Multi-Page)' },
        { value: 'large', label: 'Large (Microservices)' },
      ],
    },
  ],
  'landing-page-optimizer': [
    {
      key: 'productName',
      label: 'Product Name',
      type: 'text',
      placeholder: 'e.g., CloudVault AI',
    },
    {
      key: 'productDescription',
      label: 'Product Description',
      type: 'textarea',
      placeholder: 'Describe your product and its key benefits...',
    },
    {
      key: 'targetAudience',
      label: 'Target Audience',
      type: 'text',
      placeholder: 'e.g., Startup founders, product managers',
    },
    {
      key: 'tone',
      label: 'Tone',
      type: 'select',
      options: [
        { value: 'professional', label: 'Professional' },
        { value: 'friendly', label: 'Friendly & Approachable' },
        { value: 'bold', label: 'Bold & Assertive' },
        { value: 'minimalist', label: 'Minimalist' },
        { value: 'playful', label: 'Playful & Fun' },
      ],
    },
  ],
  'pitch-deck-generator': [
    {
      key: 'companyName',
      label: 'Company Name',
      type: 'text',
      placeholder: 'e.g., Antigravity Labs',
    },
    {
      key: 'productDescription',
      label: 'Product Description',
      type: 'textarea',
      placeholder: 'Describe your product and market opportunity...',
    },
    {
      key: 'fundingStage',
      label: 'Funding Stage',
      type: 'select',
      options: [
        { value: 'pre-seed', label: 'Pre-Seed' },
        { value: 'seed', label: 'Seed' },
        { value: 'series-a', label: 'Series A' },
        { value: 'series-b', label: 'Series B' },
        { value: 'series-c', label: 'Series C+' },
      ],
    },
    {
      key: 'marketSize',
      label: 'Market Size (TAM)',
      type: 'text',
      placeholder: 'e.g., $50B global market',
    },
  ],
}

// Contextual tips data structure: 3 tips per tool
interface ToolTip {
  title: string
  description: string
  example: string
  fieldKey: string
}

const toolTipsData: Record<string, ToolTip[]> = {
  'idea-generator': [
    {
      title: 'Pick the right industry',
      description: 'Choosing a specific industry helps the AI narrow down relevant problems and tailor ideas to market gaps.',
      example: 'technology',
      fieldKey: 'industry',
    },
    {
      title: 'Define your focus area',
      description: 'A clear focus area like "AI-powered customer support" gives more actionable and specific ideas.',
      example: 'AI-powered customer support',
      fieldKey: 'focusArea',
    },
    {
      title: 'Match budget to timeline',
      description: 'Bootstrap budgets work best with shorter timelines. Series A budgets pair well with 1-year plans.',
      example: 'bootstrap',
      fieldKey: 'budget',
    },
  ],
  'prompt-generator': [
    {
      title: 'Be specific about purpose',
      description: 'Instead of vague descriptions, specify exactly what you want the AI to produce for better results.',
      example: 'Write marketing copy for a B2B SaaS analytics platform',
      fieldKey: 'purpose',
    },
    {
      title: 'Choose the right AI model',
      description: 'Different models excel at different tasks. GPT-4 for reasoning, Claude for nuanced writing, Gemini for multimodal.',
      example: 'gpt-4',
      fieldKey: 'aiModel',
    },
    {
      title: 'Add context for precision',
      description: 'Extra context about your audience, tone, or constraints dramatically improves prompt quality.',
      example: 'Target audience: startup founders, must include data points and statistics',
      fieldKey: 'context',
    },
  ],
  'idea-validator': [
    {
      title: 'Name your idea clearly',
      description: 'A descriptive name helps the AI understand the core concept and provide more relevant validation.',
      example: 'EcoTrack AI',
      fieldKey: 'ideaName',
    },
    {
      title: 'Detail the problem you solve',
      description: 'The more specific your idea description, the more accurate the market validation scores will be.',
      example: 'An AI-powered carbon footprint tracker for small businesses that automates ESG reporting',
      fieldKey: 'ideaDescription',
    },
    {
      title: 'Define your target market',
      description: 'Narrow markets (e.g., "freelance designers") yield better validation than broad ones ("everyone").',
      example: 'Small business owners with 10-50 employees',
      fieldKey: 'targetMarket',
    },
  ],
  'market-analyzer': [
    {
      title: 'Describe your product precisely',
      description: 'Use concrete terms like "AI-powered accounting software" rather than generic descriptions.',
      example: 'AI-powered accounting software for freelancers',
      fieldKey: 'product',
    },
    {
      title: 'Specify your region',
      description: 'Regional analysis reveals local competitors, regulations, and market size differences.',
      example: 'north-america',
      fieldKey: 'region',
    },
    {
      title: 'Know your target audience',
      description: 'Defining who will buy helps estimate TAM, SAM, and SOM more accurately.',
      example: 'Freelance accountants and small bookkeeping firms',
      fieldKey: 'targetAudience',
    },
  ],
  'competitor-research': [
    {
      title: 'Define the market space',
      description: 'Be specific about the market category to get more relevant competitor data.',
      example: 'Project management tools for remote teams',
      fieldKey: 'marketSpace',
    },
    {
      title: 'Describe your product type',
      description: 'Clarifying your product type helps identify direct vs. indirect competitors.',
      example: 'Cloud-based collaboration platform with AI task assignment',
      fieldKey: 'productType',
    },
    {
      title: 'Choose the right region',
      description: 'Different regions have different competitive landscapes. Local analysis is more actionable.',
      example: 'global',
      fieldKey: 'region',
    },
  ],
  'tech-stack-recommender': [
    {
      title: 'Describe features thoroughly',
      description: 'Listing key features helps the AI recommend the most suitable technologies for each component.',
      example: 'Real-time chat, user authentication, payment processing, and admin dashboard',
      fieldKey: 'productDescription',
    },
    {
      title: 'Match stack to team size',
      description: 'Solo founders benefit from batteries-included frameworks. Large teams can leverage microservices.',
      example: 'small',
      fieldKey: 'teamSize',
    },
    {
      title: 'State your tech preferences',
      description: 'If your team has existing expertise, mention it to get recommendations that leverage your skills.',
      example: 'React, Node.js, PostgreSQL',
      fieldKey: 'techPreferences',
    },
  ],
  'business-model-generator': [
    {
      title: 'Name your product clearly',
      description: 'A clear product name helps generate business model suggestions aligned with your brand.',
      example: 'DataSync Pro',
      fieldKey: 'productName',
    },
    {
      title: 'Highlight your value prop',
      description: 'Focus on what makes your product unique — the AI will build the revenue model around it.',
      example: 'Automated data pipeline that connects 50+ SaaS tools with zero-code setup',
      fieldKey: 'productDescription',
    },
    {
      title: 'Choose pricing wisely',
      description: 'Freemium works for user acquisition. Subscription suits B2B. Usage-based fits variable demand.',
      example: 'subscription',
      fieldKey: 'pricingPreference',
    },
  ],
  'code-scaffolder': [
    {
      title: 'Describe the app clearly',
      description: 'Include the main purpose and key user flows for a more complete project structure.',
      example: 'A task management app with team collaboration, real-time updates, and file sharing',
      fieldKey: 'appDescription',
    },
    {
      title: 'List key features',
      description: 'Prioritize features as must-haves vs. nice-to-haves to get a phased development plan.',
      example: 'User auth, CRUD operations, real-time notifications, API endpoints, role-based access',
      fieldKey: 'features',
    },
    {
      title: 'Pick the right scale',
      description: 'Start with "Small" for MVPs. Only choose "Large" if you need distributed systems from day one.',
      example: 'medium',
      fieldKey: 'scale',
    },
  ],
  'landing-page-optimizer': [
    {
      title: 'Name your product',
      description: 'A clear product name ensures the AI generates copy that matches your brand identity.',
      example: 'CloudVault AI',
      fieldKey: 'productName',
    },
    {
      title: 'Highlight key benefits',
      description: 'Focus on outcomes, not features. "Save 10 hours/week" beats "Automated scheduling".',
      example: 'Save 10+ hours per week on data entry, reduce errors by 95%, onboard in 5 minutes',
      fieldKey: 'productDescription',
    },
    {
      title: 'Match tone to audience',
      description: 'Professional for enterprise, friendly for consumers, bold for startups, playful for creative tools.',
      example: 'professional',
      fieldKey: 'tone',
    },
  ],
  'pitch-deck-generator': [
    {
      title: 'Use a strong company name',
      description: 'Your company name sets the tone for the entire pitch. Make it memorable and clear.',
      example: 'Antigravity Labs',
      fieldKey: 'companyName',
    },
    {
      title: 'Articulate the opportunity',
      description: 'Focus on the problem-solution fit and why now is the right time for your product.',
      example: 'AI-powered supply chain optimization reducing waste by 40% for mid-market manufacturers',
      fieldKey: 'productDescription',
    },
    {
      title: 'Include TAM for impact',
      description: 'Investors want to see market size. Use credible sources and show TAM, SAM, and SOM.',
      example: '$50B global market, $12B serviceable market',
      fieldKey: 'marketSize',
    },
  ],
}

export function ToolModal({ tool, open, onClose }: ToolModalProps) {
  const [formData, setFormData] = React.useState<Record<string, string>>({})
  const [isGenerating, setIsGenerating] = React.useState(false)
  const [result, setResult] = React.useState<string | null>(null)
  const [activeTab, setActiveTab] = React.useState('input')
  const [validationErrors, setValidationErrors] = React.useState<Record<string, boolean>>({})
  const [fullscreenOpen, setFullscreenOpen] = React.useState(false)
  const [regeneratePopoverOpen, setRegeneratePopoverOpen] = React.useState(false)
  const [comparisonOpen, setComparisonOpen] = React.useState(false)
  const fieldRefs = React.useRef<Record<string, HTMLElement | null>>({})
  const { addRecentInput, getRecentInputs, hydrate: hydrateRecentInputs } = useRecentInputsStore()

  // Hydrate recent inputs store from localStorage on mount
  React.useEffect(() => {
    hydrateRecentInputs()
  }, [hydrateRecentInputs])

  const fields = tool ? toolFieldConfigs[tool.id] || [] : []
  const Icon: LucideIcon = tool?.icon || Sparkles
  const recentInputs = tool ? getRecentInputs(tool.id) : []

  // Reset form when tool changes
  React.useEffect(() => {
    setFormData({})
    setResult(null)
    setIsGenerating(false)
    setActiveTab('input')
    setValidationErrors({})
    setFullscreenOpen(false)
  }, [tool?.id])

  const handleGenerate = async (regenerationContext?: 'same' | 'different-style' | 'alternative') => {
    if (!tool) return

    // Validate: check if at least one field has a value
    const errors: Record<string, boolean> = {}
    let hasValue = false
    let firstEmptyKey: string | null = null

    for (const field of fields) {
      const value = (formData[field.key] || '').trim()
      if (value) {
        hasValue = true
      } else {
        errors[field.key] = true
        if (!firstEmptyKey) firstEmptyKey = field.key
      }
    }

    setValidationErrors(errors)

    if (!hasValue) {
      toast.warning('Please fill in at least one field')
      // Scroll to first empty field
      if (firstEmptyKey && fieldRefs.current[firstEmptyKey]) {
        fieldRefs.current[firstEmptyKey]?.scrollIntoView({
          behavior: 'smooth',
          block: 'center',
        })
        fieldRefs.current[firstEmptyKey]?.focus()
      }
      return
    }

    // Clear validation errors when generating
    setValidationErrors({})
    setIsGenerating(true)
    setActiveTab('result')
    setResult(null)

    // Save input to recent inputs store
    addRecentInput(tool.id, formData)

    const loadingToast = toast.loading('Generating...')

    // Build the input with optional regeneration context
    const inputWithCtx: Record<string, string> = { ...formData }
    if (regenerationContext === 'different-style') {
      inputWithCtx._regenerationStyle = 'different-style'
    } else if (regenerationContext === 'alternative') {
      inputWithCtx._regenerationStyle = 'alternative'
    }

    try {
      const response = await fetch('/api/tools/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolType: tool.id,
          input: inputWithCtx,
          regenerationContext: regenerationContext || undefined,
        }),
      })

      const data = await response.json()

      toast.dismiss(loadingToast)

      if (data.result) {
        setResult(data.result)
        toast.success('Results generated!')
      } else if (data.error) {
        setResult(`## Error\n\n${data.error}\n\nPlease try again.`)
        toast.error('Failed to generate. Please try again.')
      }
    } catch {
      toast.dismiss(loadingToast)
      setResult(
        '## Connection Error\n\nUnable to connect to the AI service. Please try again later.'
      )
      toast.error('Failed to generate. Please try again.')
    } finally {
      setIsGenerating(false)
    }
  }

  const handleSaveIdea = async (metadata?: { title?: string; category?: string; notes?: string }) => {
    if (!tool || !result) return
    try {
      await fetch('/api/tools/save-idea', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolType: tool.id,
          input: formData,
          result,
          title: metadata?.title,
          category: metadata?.category,
          notes: metadata?.notes,
        }),
      })
    } catch {
      // Silently fail
    }
  }

  const handleRate = async (rating: number) => {
    if (!tool || !result) return
    try {
      await fetch('/api/tools/rate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolType: tool.id,
          rating,
        }),
      })
    } catch {
      // Silently fail
    }
  }

  const handleNewInput = () => {
    setFormData({})
    setResult(null)
    setActiveTab('input')
    setValidationErrors({})
  }

  const handleRecentInputClick = (inputFormData: Record<string, string>) => {
    setFormData(inputFormData)
    setValidationErrors({})
  }

  const getRecentInputLabel = (inputFormData: Record<string, string>): string => {
    // Find the first non-empty field value and truncate to 25 chars
    for (const value of Object.values(inputFormData)) {
      const trimmed = value?.trim()
      if (trimmed) {
        return trimmed.length > 25 ? trimmed.substring(0, 25) + '...' : trimmed
      }
    }
    return 'Empty input'
  }

  const handleFieldChange = (key: string, value: string) => {
    setFormData((prev) => ({ ...prev, [key]: value }))
    // Clear validation error for this field when user starts typing
    if (validationErrors[key]) {
      setValidationErrors((prev) => {
        const next = { ...prev }
        delete next[key]
        return next
      })
    }
  }

  const renderField = (field: FieldConfig) => {
    const value = formData[field.key] || ''
    const hasError = validationErrors[field.key]
    const placeholderHint = field.placeholder || `Enter your ${field.label.toLowerCase()} or leave blank for general ideas`

    if (field.type === 'select') {
      return (
        <div key={field.key} className="space-y-2" ref={(el) => { fieldRefs.current[field.key] = el }}>
          <Label htmlFor={field.key}>{field.label}</Label>
          <Select
            value={value}
            onValueChange={(val) => handleFieldChange(field.key, val)}
          >
            <SelectTrigger
              className={`w-full ${hasError ? 'border-red-500 focus:ring-red-500/20' : ''}`}
              id={field.key}
            >
              <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {hasError && (
            <p className="text-xs text-red-500 flex items-center gap-1">
              <AlertCircle className="size-3" />
              Please select an option or fill another field
            </p>
          )}
        </div>
      )
    }

    if (field.type === 'textarea') {
      return (
        <div key={field.key} className="space-y-2" ref={(el) => { fieldRefs.current[field.key] = el }}>
          <Label htmlFor={field.key}>{field.label}</Label>
          <Textarea
            id={field.key}
            value={value}
            onChange={(e) => handleFieldChange(field.key, e.target.value)}
            placeholder={placeholderHint}
            rows={3}
            className={`resize-none ${hasError ? 'border-red-500 focus-visible:ring-red-500/20' : ''}`}
          />
          {hasError && (
            <p className="text-xs text-red-500 flex items-center gap-1">
              <AlertCircle className="size-3" />
              Please enter a value or fill another field
            </p>
          )}
        </div>
      )
    }

    return (
      <div key={field.key} className="space-y-2" ref={(el) => { fieldRefs.current[field.key] = el }}>
        <Label htmlFor={field.key}>{field.label}</Label>
        <Input
          id={field.key}
          value={value}
          onChange={(e) => handleFieldChange(field.key, e.target.value)}
          placeholder={placeholderHint}
          className={hasError ? 'border-red-500 focus-visible:ring-red-500/20' : ''}
        />
        {hasError && (
          <p className="text-xs text-red-500 flex items-center gap-1">
            <AlertCircle className="size-3" />
            Please enter a value or fill another field
          </p>
        )}
      </div>
    )
  }

  return (
    <>
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent
        className="sm:max-w-3xl max-h-[90vh] p-0 gap-0 overflow-hidden backdrop-blur-xl bg-background/80 shadow-2xl shadow-emerald-500/5 border-white/10 dark:border-white/5"
        onInteractOutside={(e) => {
          // Prevent closing when clicking on portaled elements (Select dropdowns, Toasts, etc.)
          const target = e.target as HTMLElement
          if (
            target.closest('[data-radix-popper-content-wrapper]') ||
            target.closest('[data-sonner-toaster]') ||
            target.closest('[data-radix-dialog-content]')
          ) {
            e.preventDefault()
          }
        }}
        onPointerDownOutside={(e) => {
          // Prevent closing on pointer down outside for portaled elements
          const target = e.target as HTMLElement
          if (
            target.closest('[data-radix-popper-content-wrapper]') ||
            target.closest('[data-sonner-toaster]') ||
            target.closest('[data-radix-dialog-content]')
          ) {
            e.preventDefault()
          }
        }}
      >
        {/* Gradient border wrapper */}
        <div className="absolute inset-0 rounded-lg pointer-events-none p-[1px]">
          <div className="w-full h-full rounded-lg bg-gradient-to-br from-emerald-400/20 via-transparent to-teal-400/20 dark:from-emerald-400/10 dark:via-transparent dark:to-teal-400/10" />
        </div>

        {/* Header with frosted glass */}
        <div className="relative border-b px-6 py-4 bg-background/60 backdrop-blur-md border-white/10 dark:border-white/5">
          <DialogHeader>
            <div className="flex items-center gap-3">
              <div
                className={`flex size-10 items-center justify-center rounded-lg ${tool?.iconBg} shadow-sm`}
              >
                <Icon className="size-5 text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <DialogTitle className="text-lg">{tool?.name}</DialogTitle>
                  {tool?.difficulty && (
                    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
                      tool.difficulty === 'Beginner'
                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
                        : tool.difficulty === 'Intermediate'
                        ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
                        : 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400'
                    }`}>
                      {tool.difficulty}
                    </span>
                  )}
                </div>
                <DialogDescription>{tool?.description}</DialogDescription>
              </div>
            </div>
          </DialogHeader>
        </div>

        {/* Tabs */}
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="flex-1 flex flex-col min-h-0"
        >
          <div className="px-6 pt-2 border-b border-white/10 dark:border-white/5">
            <TabsList className="w-full justify-start bg-transparent">
              <TabsTrigger value="input">Input</TabsTrigger>
              <TabsTrigger value="result">
                Results
                {result && (
                  <span className="ml-1.5 size-2 rounded-full bg-emerald-500 inline-block" />
                )}
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Input Tab */}
          <TabsContent value="input" className="flex-1 overflow-y-auto p-6">
            <div className="grid gap-4 sm:grid-cols-2">
              {fields.map(renderField)}
            </div>

            {/* Recent Inputs Section */}
            {recentInputs.length > 0 && (
              <div className="mt-5">
                <div className="flex items-center gap-1.5 mb-2">
                  <Clock className="size-3.5 text-muted-foreground" />
                  <span className="text-xs font-medium text-muted-foreground">Recent Inputs</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {recentInputs.map((input) => (
                    <button
                      key={input.id}
                      onClick={(e) => {
                        e.stopPropagation()
                        handleRecentInputClick(input.formData)
                      }}
                      className="inline-flex items-center gap-1 rounded-full border border-emerald-500/20 bg-emerald-500/5 dark:bg-emerald-500/10 px-2.5 py-1 text-xs text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/15 dark:hover:bg-emerald-500/20 hover:border-emerald-500/40 transition-all duration-200 cursor-pointer max-w-[200px]"
                      aria-label={`Fill form with recent input: ${getRecentInputLabel(input.formData)}`}
                    >
                      <span className="truncate">{getRecentInputLabel(input.formData)}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-6 flex items-center justify-end gap-3">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              {/* Tips Popover */}
              {tool && toolTipsData[tool.id] && (
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs border-emerald-500/30 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:border-emerald-500/50 gap-1.5"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Lightbulb className="size-3.5" />
                      Tips
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent
                    side="top"
                    align="end"
                    className="w-80 p-0 overflow-hidden"
                    onOpenAutoFocus={(e) => e.preventDefault()}
                  >
                    <div className="bg-gradient-to-r from-emerald-500 to-teal-500 px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <Lightbulb className="size-4 text-white" />
                        <span className="text-sm font-semibold text-white">Usage Tips</span>
                      </div>
                      <p className="text-xs text-emerald-100 mt-0.5">Click an example to fill the form field</p>
                    </div>
                    <div className="p-2 space-y-1">
                      {toolTipsData[tool.id].map((tip, idx) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, y: 4 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.2, delay: idx * 0.05 }}
                          className="rounded-lg border border-emerald-100 dark:border-emerald-900/30 p-3 hover:bg-emerald-50/50 dark:hover:bg-emerald-900/10 transition-colors"
                        >
                          <div className="flex items-start gap-2">
                            <div className="flex items-center justify-center size-5 rounded-full bg-emerald-100 dark:bg-emerald-900/30 shrink-0 mt-0.5">
                              <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">{idx + 1}</span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-semibold text-foreground">{tip.title}</p>
                              <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">{tip.description}</p>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  handleFieldChange(tip.fieldKey, tip.example)
                                  toast.success(`Filled "${tip.example}" into ${fields.find(f => f.key === tip.fieldKey)?.label || tip.fieldKey}`)
                                }}
                                className="mt-1.5 inline-flex items-center gap-1 rounded-md bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800/50 px-2 py-0.5 text-[11px] font-medium text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 hover:border-emerald-300 dark:hover:border-emerald-700/50 transition-colors cursor-pointer"
                              >
                                <Sparkles className="size-2.5" />
                                {tip.example.length > 35 ? tip.example.substring(0, 35) + '...' : tip.example}
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </PopoverContent>
                </Popover>
              )}
              <Button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/25 min-w-[140px]"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="size-4" />
                    Generate
                  </>
                )}
              </Button>
            </div>
          </TabsContent>

          {/* Result Tab */}
          <TabsContent value="result" className="flex-1 min-h-0 flex flex-col">
            <div className="flex-1 min-h-0">
              <ResultPanel
                result={result}
                isGenerating={isGenerating}
                onSaveIdea={handleSaveIdea}
                onRate={handleRate}
              />
            </div>
            {/* Quick Actions Bar */}
            {result && !isGenerating && (
              <div className="flex items-center gap-2 px-4 py-2 border-t border-white/10 dark:border-white/5">
                <Popover open={regeneratePopoverOpen} onOpenChange={setRegeneratePopoverOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => e.stopPropagation()}
                      className="text-xs text-muted-foreground hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
                    >
                      <RefreshCw className="size-3.5" />
                      Regenerate
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent
                    align="start"
                    className="w-64 p-2"
                    onOpenAutoFocus={(e) => e.preventDefault()}
                  >
                    <div className="space-y-1">
                      <p className="text-xs font-medium text-muted-foreground px-2 pb-1">Regeneration Options</p>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          setRegeneratePopoverOpen(false)
                          handleGenerate('same')
                        }}
                        className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-sm hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors text-left"
                      >
                        <RotateCw className="size-4 text-emerald-500" />
                        <div>
                          <div className="font-medium">Same input</div>
                          <div className="text-xs text-muted-foreground">Regenerate with current settings</div>
                        </div>
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          setRegeneratePopoverOpen(false)
                          handleGenerate('different-style')
                        }}
                        className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-sm hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors text-left"
                      >
                        <Palette className="size-4 text-teal-500" />
                        <div>
                          <div className="font-medium">Different style</div>
                          <div className="text-xs text-muted-foreground">Generate with a different approach</div>
                        </div>
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          setRegeneratePopoverOpen(false)
                          handleGenerate('alternative')
                        }}
                        className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-sm hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors text-left"
                      >
                        <Shuffle className="size-4 text-amber-500" />
                        <div>
                          <div className="font-medium">Generate alternative</div>
                          <div className="text-xs text-muted-foreground">Get a completely different take</div>
                        </div>
                      </button>
                    </div>
                  </PopoverContent>
                </Popover>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleNewInput}
                  className="text-xs text-muted-foreground hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
                >
                  <PlusCircle className="size-3.5" />
                  New Input
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setFullscreenOpen(true)}
                  className="text-xs text-muted-foreground hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
                >
                  <Maximize2 className="size-3.5" />
                  Full Screen
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setComparisonOpen(true)}
                  className="text-xs text-muted-foreground hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
                >
                  <GitCompareArrows className="size-3.5" />
                  Compare
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
    <FullscreenResultDialog
      open={fullscreenOpen}
      onOpenChange={setFullscreenOpen}
      result={result}
    />
    <ResultComparison
      open={comparisonOpen}
      onOpenChange={setComparisonOpen}
      currentToolType={tool?.id}
    />
  </>
  )
}
