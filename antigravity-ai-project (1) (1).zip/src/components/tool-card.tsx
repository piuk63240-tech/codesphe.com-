'use client'

import * as React from 'react'
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'
import type { LucideIcon } from 'lucide-react'
import { Sparkles, Pin, Info } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { useFavoritesStore } from '@/store/app-store'

export interface ToolConfig {
  id: string
  name: string
  description: string
  icon: LucideIcon
  category: string
  gradient: string
  iconBg: string
  difficulty?: 'Beginner' | 'Intermediate' | 'Advanced'
}

// Tool usage tips map
const toolTips: Record<string, string> = {
  'idea-generator': 'Try specifying an industry and budget for more targeted ideas',
  'prompt-generator': 'Include your target AI model for model-specific optimization',
  'idea-validator': 'Provide detailed descriptions for more accurate validation scores',
  'market-analyzer': 'Specify a region for localized market insights',
  'competitor-research': 'Be specific about your product type for better competitor analysis',
  'tech-stack-recommender': 'Include your team size for realistic tech recommendations',
  'business-model-generator': 'Choose a pricing preference to get aligned revenue models',
  'code-scaffolder': 'List key features for a more complete project structure',
  'landing-page-optimizer': 'Match the tone to your target audience for better conversion',
  'pitch-deck-generator': 'Include TAM for more impressive market opportunity slides',
}

// Difficulty color map
const difficultyConfig = {
  Beginner: {
    bg: 'bg-emerald-100 dark:bg-emerald-900/30',
    text: 'text-emerald-700 dark:text-emerald-300',
    border: 'border-emerald-200 dark:border-emerald-800/50',
    dot: 'bg-emerald-500',
  },
  Intermediate: {
    bg: 'bg-amber-100 dark:bg-amber-900/30',
    text: 'text-amber-700 dark:text-amber-300',
    border: 'border-amber-200 dark:border-amber-800/50',
    dot: 'bg-amber-500',
  },
  Advanced: {
    bg: 'bg-rose-100 dark:bg-rose-900/30',
    text: 'text-rose-700 dark:text-rose-300',
    border: 'border-rose-200 dark:border-rose-800/50',
    dot: 'bg-rose-500',
  },
}

interface ToolCardProps {
  tool: ToolConfig
  index: number
  onClick: (tool: ToolConfig) => void
  compact?: boolean
}

export function ToolCard({ tool, index, onClick, compact = false }: ToolCardProps) {
  const Icon = tool.icon
  const cardRef = React.useRef<HTMLDivElement>(null)
  const difficulty = tool.difficulty ?? 'Beginner'
  const diffConfig = difficultyConfig[difficulty]
  const { isFavorite, toggleFavorite, hydrate: hydrateFavorites, favorites } = useFavoritesStore()
  const favorited = isFavorite(tool.id)

  // Hydrate favorites store on mount
  React.useEffect(() => {
    hydrateFavorites()
  }, [hydrateFavorites])

  // Motion values for mouse position (0..1 range across the card)
  const mouseX = useMotionValue(0.5)
  const mouseY = useMotionValue(0.5)

  // Spring physics for tilt — bouncy spring feel
  const tiltSpringConfig = { stiffness: 200, damping: 18, mass: 0.6 }
  const tiltX = useSpring(useTransform(mouseY, [0, 1], [6, -6]), tiltSpringConfig)
  const tiltY = useSpring(useTransform(mouseX, [0, 1], [-6, 6]), tiltSpringConfig)

  // Glare position tracking (percentage 0–100)
  const glareX = useTransform(mouseX, [0, 1], [0, 100])
  const glareY = useTransform(mouseY, [0, 1], [0, 100])

  // Glowing border spotlight that follows mouse
  const borderSpotlight = useTransform(
    [glareX, glareY],
    ([latestX, latestY]: number[]) =>
      `radial-gradient(circle at ${latestX}% ${latestY}%, rgba(16,185,129,0.4) 0%, rgba(16,185,129,0.1) 30%, transparent 60%)`
  )

  // Combine glare position into a CSS background string
  const glareBackground = useTransform(
    [glareX, glareY],
    ([latestX, latestY]: number[]) =>
      `radial-gradient(circle at ${latestX}% ${latestY}%, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0.06) 30%, transparent 60%)`
  )

  const [isHovering, setIsHovering] = React.useState(false)

  const handleMouseMove = React.useCallback(
    (e: React.MouseEvent<HTMLButtonElement>) => {
      if (!cardRef.current) return
      const rect = cardRef.current.getBoundingClientRect()
      const normalizedX = (e.clientX - rect.left) / rect.width
      const normalizedY = (e.clientY - rect.top) / rect.height

      mouseX.set(normalizedX)
      mouseY.set(normalizedY)
    },
    [mouseX, mouseY]
  )

  const handleMouseEnter = React.useCallback(() => {
    setIsHovering(true)
  }, [])

  const handleMouseLeave = React.useCallback(() => {
    setIsHovering(false)
    // Reset to center — springs will animate smoothly back
    mouseX.set(0.5)
    mouseY.set(0.5)
  }, [mouseX, mouseY])

  return (
    <TooltipProvider delayDuration={300}>
      <Tooltip>
        <TooltipTrigger asChild>
          <motion.button
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.4, delay: index * 0.08 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => onClick(tool)}
            onMouseMove={handleMouseMove}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            className="group cursor-pointer text-left w-full"
            aria-label={`Open ${tool.name} tool`}
            style={{ perspective: '1000px' }}
          >
            <motion.div
              ref={cardRef}
              className="relative h-full rounded-xl border bg-card p-6 shadow-sm overflow-hidden"
              style={{
                rotateX: tiltX,
                rotateY: tiltY,
                transformStyle: 'preserve-3d',
                transition: isHovering ? 'box-shadow 0.3s ease-out' : 'box-shadow 0.5s ease-out',
                boxShadow: isHovering
                  ? '0 8px 24px rgba(16, 185, 129, 0.15), 0 4px 12px rgba(0,0,0,0.08)'
                  : '0 1px 3px rgba(0,0,0,0.06)',
                willChange: 'transform, box-shadow',
              }}
            >
              {/* Pulsing gradient border on hover */}
              <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 p-[1.5px] overflow-hidden">
                <motion.div
                  className="absolute inset-0 rounded-xl"
                  style={{
                    background: 'linear-gradient(90deg, #10b981, #14b8a6, #06b6d4, #10b981)',
                    backgroundSize: '300% 100%',
                  }}
                  animate={isHovering ? {
                    backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                  } : {}}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }}
                />
                <div className="relative h-full w-full rounded-xl bg-card" />
              </div>

              {/* Spotlight border glow that follows mouse */}
              <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 p-[1.5px]">
                <motion.div
                  className="absolute inset-0 rounded-xl"
                  style={{ background: borderSpotlight }}
                />
                <div className="relative h-full w-full rounded-xl bg-card" />
              </div>

              {/* Glow effect behind card on hover */}
              <div className="absolute -inset-2 rounded-2xl bg-emerald-500/0 blur-xl transition-all duration-500 group-hover:bg-emerald-500/10" />

              {/* Hover gradient overlay */}
              <div
                className={`absolute inset-0 ${tool.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
              />

              {/* Glare / shine effect that follows the mouse */}
              <motion.div
                className="absolute inset-0 pointer-events-none z-20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{ background: glareBackground }}
              />

              {/* Content - floating depth effect with translateZ */}
              <div
                className="relative z-10"
                style={{
                  transform: 'translateZ(20px)',
                  transformStyle: 'preserve-3d',
                }}
              >
                {/* AI Powered badge with glow */}
                <div className="absolute -top-1 -right-1 opacity-0 group-hover:opacity-100 transition-all duration-500 translate-y-1 group-hover:translate-y-0">
                  <motion.div
                    animate={{ rotate: [0, 15, -15, 0], scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                    className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-emerald-500/10 dark:bg-emerald-500/20 border border-emerald-500/20 dark:border-emerald-400/30"
                    style={{
                      boxShadow: '0 0 8px rgba(16, 185, 129, 0.3), 0 0 16px rgba(16, 185, 129, 0.15)',
                    }}
                  >
                    <Sparkles className="size-3 text-emerald-500 dark:text-emerald-400" />
                    <span className="text-[9px] font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">AI</span>
                  </motion.div>
                </div>

                {/* Favorite/Pin button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    toggleFavorite(tool.id)
                  }}
                  className={`absolute top-0 left-0 z-20 flex items-center justify-center size-7 rounded-md transition-all duration-200 ${
                    favorited
                      ? 'opacity-100 text-emerald-500 dark:text-emerald-400 hover:text-emerald-600 dark:hover:text-emerald-300'
                      : 'opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-emerald-500 dark:hover:text-emerald-400'
                  }`}
                  aria-label={favorited ? `Unpin ${tool.name}` : `Pin ${tool.name}`}
                  aria-pressed={favorited}
                >
                  <Pin className={`size-3.5 ${favorited ? 'fill-emerald-500 dark:fill-emerald-400' : ''}`} />
                </button>

                {/* Icon and Badge row */}
                <div className="flex items-start justify-between mb-4">
                  <div
                    className={`flex size-12 items-center justify-center rounded-lg ${tool.iconBg} shadow-sm transition-transform duration-300 group-hover:scale-105`}
                  >
                    <Icon className="size-6 text-white" />
                  </div>
                  <div className="flex flex-col items-end gap-1.5">
                    <Badge
                      variant="secondary"
                      className="text-xs bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/50"
                    >
                      {tool.category}
                    </Badge>
                    {/* Difficulty badge */}
                    <span
                      className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-medium ${diffConfig.bg} ${diffConfig.text} ${diffConfig.border}`}
                    >
                      <span className={`size-1.5 rounded-full ${diffConfig.dot}`} />
                      {difficulty}
                    </span>
                  </div>
                </div>

                {/* Name with Tip and Description */}
                <div className="flex items-start gap-1.5 mb-2">
                  <h3 className="text-lg font-semibold text-card-foreground group-hover:text-emerald-700 dark:group-hover:text-emerald-300 transition-colors duration-300">
                    {tool.name}
                  </h3>
                  {toolTips[tool.id] && (
                    <Popover>
                      <PopoverTrigger asChild>
                        <button
                          onClick={(e) => e.stopPropagation()}
                          className="mt-1 flex items-center justify-center size-5 rounded-full text-muted-foreground/50 hover:text-emerald-500 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors shrink-0"
                          aria-label={`Tip for ${tool.name}`}
                        >
                          <Info className="size-3.5" />
                        </button>
                      </PopoverTrigger>
                      <PopoverContent
                        side="top"
                        align="start"
                        className="w-64 p-3 text-sm"
                        onOpenAutoFocus={(e) => e.preventDefault()}
                      >
                        <div className="flex items-start gap-2">
                          <div className="flex items-center justify-center size-6 rounded-full bg-emerald-100 dark:bg-emerald-900/30 shrink-0 mt-0.5">
                            <Sparkles className="size-3 text-emerald-600 dark:text-emerald-400" />
                          </div>
                          <div>
                            <p className="font-medium text-xs text-emerald-700 dark:text-emerald-300 mb-1">Pro Tip</p>
                            <p className="text-xs text-muted-foreground leading-relaxed">{toolTips[tool.id]}</p>
                          </div>
                        </div>
                      </PopoverContent>
                    </Popover>
                  )}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {tool.description}
                </p>

                {/* Try now indicator */}
                <div className="mt-4 flex items-center gap-1 text-sm font-medium text-emerald-600 dark:text-emerald-400 opacity-0 group-hover:opacity-100 transition-all duration-500 ease-out translate-y-2 group-hover:translate-y-0 group-hover:drop-shadow-[0_0_6px_rgba(16,185,129,0.5)]">
                  Try now
                  <svg
                    className="size-4 transition-transform duration-500 ease-out group-hover:translate-x-1"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M13 7l5 5m0 0l-5 5m5-5H6"
                    />
                  </svg>
                </div>
              </div>
            </motion.div>
          </motion.button>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="max-w-[240px]">
          <p className="text-xs">{tool.description}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
