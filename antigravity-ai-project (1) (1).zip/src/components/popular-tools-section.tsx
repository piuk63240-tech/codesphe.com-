'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import {
  Lightbulb,
  ShieldCheck,
  Layers,
  MessageSquareCode,
  TrendingUp,
  Flame,
  Star,
  ThumbsUp,
  ArrowRight,
} from 'lucide-react'
import { tools, type ToolConfig } from '@/components/tools-grid'

// ── Popular tool data ────────────────────────────────────────────────────────
interface PopularTool {
  id: string
  name: string
  description: string
  icon: React.ElementType
  badge: string
  badgeIcon: React.ElementType
  badgeColor: string
  gradientFrom: string
  gradientTo: string
  usage: string
  toolConfigId: string
}

const popularTools: PopularTool[] = [
  {
    id: 'idea-generator',
    name: 'Idea Generator',
    description:
      'Spark creative SaaS ideas with AI-powered brainstorming and market-fit analysis.',
    icon: Lightbulb,
    badge: 'Most Popular',
    badgeIcon: Flame,
    badgeColor:
      'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-300 dark:border-amber-800/50',
    gradientFrom: 'from-amber-500/10',
    gradientTo: 'to-orange-500/10',
    usage: 'Used 1.2K times today',
    toolConfigId: 'idea-generator',
  },
  {
    id: 'idea-validator',
    name: 'Idea Validator',
    description:
      'Get comprehensive validation with market data, competition analysis, and viability scoring.',
    icon: ShieldCheck,
    badge: 'Trending',
    badgeIcon: TrendingUp,
    badgeColor:
      'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-300 dark:border-emerald-800/50',
    gradientFrom: 'from-emerald-500/10',
    gradientTo: 'to-teal-500/10',
    usage: 'Used 890 times today',
    toolConfigId: 'idea-validator',
  },
  {
    id: 'tech-stack',
    name: 'Tech Stack Recommender',
    description:
      'Get the perfect tech stack recommendation tailored to your project requirements.',
    icon: Layers,
    badge: 'Recommended',
    badgeIcon: Star,
    badgeColor:
      'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-900/20 dark:text-rose-300 dark:border-rose-800/50',
    gradientFrom: 'from-rose-500/10',
    gradientTo: 'to-pink-500/10',
    usage: 'Used 650 times today',
    toolConfigId: 'tech-stack-recommender',
  },
  {
    id: 'prompt-generator',
    name: 'Prompt Generator',
    description:
      'Craft optimized prompts that deliver better results from any AI model or use case.',
    icon: MessageSquareCode,
    badge: 'Popular',
    badgeIcon: ThumbsUp,
    badgeColor:
      'bg-teal-50 text-teal-700 border-teal-200 dark:bg-teal-900/20 dark:text-teal-300 dark:border-teal-800/50',
    gradientFrom: 'from-teal-500/10',
    gradientTo: 'to-cyan-500/10',
    usage: 'Used 1.1K times today',
    toolConfigId: 'prompt-generator',
  },
]

// ── Rotating Gradient Border Card ────────────────────────────────────────────
function RotatingBorderCard({
  children,
  isHovering,
}: {
  children: React.ReactNode
  isHovering: boolean
}) {
  return (
    <div className="relative h-full rounded-2xl overflow-hidden">
      {/* Animated rotating conic-gradient border */}
      <div
        className={`absolute inset-0 rounded-2xl ${isHovering ? 'animate-rotate-border-fast' : 'animate-rotate-border'}`}
        style={{
          background: isHovering
            ? 'conic-gradient(from var(--angle), #10b981, #14b8a6, #06b6d4, #34d399, #10b981)'
            : 'conic-gradient(from var(--angle), #10b981, #14b8a6, #06b6d4, #10b981)',
          padding: '2px',
          willChange: 'transform, background',
          opacity: isHovering ? 1 : 0.7,
          transition: 'opacity 0.3s ease',
        }}
      >
        <div className="h-full w-full rounded-2xl bg-card" />
      </div>
      {/* Inner content area */}
      <div className="absolute inset-[2px] rounded-2xl bg-card overflow-hidden">
        {children}
      </div>
    </div>
  )
}

// ── Component ────────────────────────────────────────────────────────────────
interface PopularToolsSectionProps {
  onToolClick: (tool: ToolConfig) => void
}

export function PopularToolsSection({ onToolClick }: PopularToolsSectionProps) {
  // Build a lookup map from the canonical tools list
  const toolMap = React.useMemo(
    () => new Map(tools.map((t) => [t.id, t])),
    []
  )

  const [hoveredId, setHoveredId] = React.useState<string | null>(null)

  return (
    <section className="py-20 sm:py-28 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-14"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Most <span className="animated-gradient-text">Popular</span> Tools
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            The tools our community loves most — trusted by thousands of
            founders every day.
          </p>
        </motion.div>

        {/* Featured Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {popularTools.map((tool, index) => {
            const Icon = tool.icon
            const BadgeIcon = tool.badgeIcon

            return (
              <motion.button
                key={tool.id}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.45, delay: index * 0.1 }}
                whileHover={{ y: -6, scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  const fullTool = toolMap.get(tool.toolConfigId)
                  if (fullTool) onToolClick(fullTool)
                }}
                onMouseEnter={() => setHoveredId(tool.id)}
                onMouseLeave={() => setHoveredId(null)}
                className="group cursor-pointer text-left w-full"
                aria-label={`Open ${tool.name} tool`}
              >
                <RotatingBorderCard isHovering={hoveredId === tool.id}>
                  {/* Gradient background overlay */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${tool.gradientFrom} ${tool.gradientTo} dark:from-emerald-500/5 dark:to-teal-500/5 opacity-60 group-hover:opacity-100 transition-opacity duration-500`}
                  />

                  {/* Subtle gradient overlay on hover */}
                  <div className="absolute inset-0 bg-gradient-to-t from-emerald-500/[0.04] to-transparent dark:from-emerald-500/[0.08] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                  <div className="relative z-10 p-6">
                    {/* Badge */}
                    <div className="flex items-center justify-between mb-5">
                      <span
                        className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium ${tool.badgeColor}`}
                      >
                        <BadgeIcon className="size-3" />
                        {tool.badge}
                      </span>
                    </div>

                    {/* Icon */}
                    <div
                      className={`flex size-14 items-center justify-center rounded-xl bg-gradient-to-br ${tool.gradientFrom.replace('/10', '/80')} ${tool.gradientTo.replace('/10', '/80')} mb-4 shadow-lg group-hover:shadow-xl group-hover:scale-105 transition-all duration-300`}
                    >
                      <Icon className="size-7 text-white" />
                    </div>

                    {/* Text */}
                    <h3 className="text-lg font-semibold text-card-foreground group-hover:text-emerald-700 dark:group-hover:text-emerald-300 transition-colors duration-300 mb-2">
                      {tool.name}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                      {tool.description}
                    </p>

                    {/* Usage stat */}
                    <div className="flex items-center justify-between mt-auto">
                      <span className="text-xs text-muted-foreground/70 flex items-center gap-1.5">
                        <span className="inline-block size-2 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-400/50" />
                        {tool.usage}
                      </span>
                      <span className="flex items-center gap-1 text-sm font-medium text-emerald-600 dark:text-emerald-400 opacity-0 group-hover:opacity-100 transition-all duration-500 ease-out translate-x-[-4px] group-hover:translate-x-0">
                        Try now
                        <ArrowRight className="size-3.5" />
                      </span>
                    </div>
                  </div>
                </RotatingBorderCard>
              </motion.button>
            )
          })}
        </div>
      </div>
    </section>
  )
}
