'use client'

import * as React from 'react'
import { Rocket, Github, Twitter, Linkedin, Youtube, Heart, ArrowUp, Mail, Send } from 'lucide-react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'

export function Footer() {
  const [email, setEmail] = React.useState('')
  const [subscribed, setSubscribed] = React.useState(false)

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) {
      toast.error('Please enter your email address')
      return
    }
    // Simple email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      toast.error('Please enter a valid email address')
      return
    }
    setSubscribed(true)
    toast.success('Thanks for subscribing! 🎉')
    setEmail('')
  }

  const handleBackToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <footer className="border-t bg-muted/30 mt-auto relative overflow-hidden">
      {/* Animated wave/gradient divider at top of footer */}
      <div className="absolute top-0 left-0 right-0 h-1.5 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 via-teal-400 to-emerald-400 animate-gradient-shift" style={{ backgroundSize: '200% 100%' }} />
      </div>

      {/* Floating particles above footer */}
      <div className="absolute top-0 left-0 right-0 h-16 overflow-hidden pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-emerald-400/20 dark:bg-emerald-400/10"
            style={{
              width: `${4 + i * 2}px`,
              height: `${4 + i * 2}px`,
              left: `${15 + i * 15}%`,
              top: `${20 + (i % 3) * 20}%`,
            }}
            animate={{
              y: [0, -8, 0],
              opacity: [0.2, 0.6, 0.2],
            }}
            transition={{
              duration: 3 + i * 0.5,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: i * 0.4,
            }}
          />
        ))}
      </div>

      {/* Newsletter section at top of footer */}
      <div className="relative border-b border-border/50 bg-gradient-to-r from-emerald-500/[0.03] via-transparent to-teal-500/[0.03] dark:from-emerald-500/[0.06] dark:via-transparent dark:to-teal-500/[0.06]">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-left">
              <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
                <Mail className="size-5 text-emerald-500" />
                Stay in the loop
              </h3>
              <p className="text-sm text-muted-foreground mt-1">
                Join 5,000+ founders getting weekly AI insights
              </p>
            </div>
            <form onSubmit={handleSubscribe} className="flex gap-2 w-full max-w-md">
              <div className="relative flex-1">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full h-10 pl-9 pr-3 rounded-lg border bg-background text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all"
                  aria-label="Email address for newsletter"
                />
              </div>
              <Button
                type="submit"
                size="sm"
                className="bg-emerald-500 hover:bg-emerald-600 text-white shrink-0 gap-1.5 h-10 px-5 shadow-lg shadow-emerald-500/20 hover:shadow-emerald-500/30 transition-all duration-300"
                disabled={subscribed}
              >
                <Send className="size-4" />
                {subscribed ? 'Subscribed!' : 'Subscribe'}
              </Button>
            </form>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Brand - spans 2 columns */}
          <div className="lg:col-span-2">
            <a href="#" className="flex items-center gap-2 group mb-4">
              <motion.div
                className="flex size-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 text-white shadow-lg shadow-emerald-500/25 group-hover:shadow-emerald-500/40 transition-shadow duration-300"
                whileHover={{ rotate: 20, scale: 1.1 }}
                transition={{ type: 'spring', stiffness: 400, damping: 15 }}
              >
                <Rocket className="size-4" />
              </motion.div>
              <span className="text-lg font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                Antigravity AI
              </span>
            </a>
            <p className="text-sm text-muted-foreground leading-relaxed mb-6 max-w-xs">
              AI-powered SaaS tools platform for founders, builders, and dreamers. Launch faster, build smarter.
            </p>

            {/* Social links with enhanced hover animations */}
            <div className="flex items-center gap-3">
              {[
                { icon: Github, label: 'GitHub', href: '#' },
                { icon: Twitter, label: 'Twitter', href: '#' },
                { icon: Linkedin, label: 'LinkedIn', href: '#' },
                { icon: Youtube, label: 'YouTube', href: '#' },
              ].map(({ icon: SocialIcon, label, href }) => (
                <motion.a
                  key={label}
                  href={href}
                  className="flex size-9 items-center justify-center rounded-lg border bg-background hover:border-emerald-300 dark:hover:border-emerald-700 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors duration-300"
                  aria-label={label}
                  whileHover={{ scale: 1.15, rotate: -5 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 15 }}
                >
                  <SocialIcon className="size-4" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Product */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4">
              Product
            </h4>
            <ul className="space-y-2.5">
              {['Idea Generator', 'Prompt Generator', 'Market Analyzer', 'Code Scaffolder'].map(
                (item) => (
                  <li key={item}>
                    <a
                      href="#tools"
                      className="footer-link text-sm text-muted-foreground"
                    >
                      {item}
                    </a>
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4">
              Resources
            </h4>
            <ul className="space-y-2.5">
              {['Documentation', 'API Reference', 'Blog', 'Changelog'].map(
                (item) => (
                  <li key={item}>
                    <a
                      href="#"
                      className="footer-link text-sm text-muted-foreground"
                    >
                      {item}
                    </a>
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4">
              Company
            </h4>
            <ul className="space-y-2.5">
              {['About', 'Careers', 'Privacy Policy', 'Terms of Service'].map(
                (item) => (
                  <li key={item}>
                    <a
                      href="#"
                      className="footer-link text-sm text-muted-foreground"
                    >
                      {item}
                    </a>
                  </li>
                )
              )}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} Antigravity AI. All rights
            reserved.
          </p>
          <div className="flex items-center gap-4">
            <p className="text-xs text-muted-foreground flex items-center gap-1 animate-pulse-text">
              Built with <Heart className="size-3 text-emerald-500 fill-emerald-500 inline" /> and AI
            </p>
            {/* Back to top link */}
            <button
              type="button"
              onClick={handleBackToTop}
              className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors duration-300 group"
              aria-label="Back to top"
            >
              <ArrowUp className="size-3 transition-transform group-hover:-translate-y-0.5" />
              Back to top
            </button>
          </div>
        </div>
      </div>
    </footer>
  )
}
