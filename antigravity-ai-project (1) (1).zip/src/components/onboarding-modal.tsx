'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Sparkles,
  Lightbulb,
  ShieldCheck,
  Search,
  Layers,
  DollarSign,
  Layout,
  Keyboard,
  ArrowRight,
  ArrowLeft,
  Zap,
  Target,
  TrendingUp,
  Code2,
  Presentation,
} from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'

const STORAGE_KEY = 'antigravity-onboarding-complete'

interface OnboardingModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onTryTool?: () => void
}

const TOOL_CATEGORIES = [
  {
    name: 'Ideation',
    icon: Lightbulb,
    color: 'from-amber-500 to-orange-500',
    description: 'Brainstorm and discover innovative SaaS ideas',
  },
  {
    name: 'Content',
    icon: Target,
    color: 'from-emerald-500 to-teal-500',
    description: 'Generate optimized prompts and creative content',
  },
  {
    name: 'Validation',
    icon: ShieldCheck,
    color: 'from-green-500 to-emerald-600',
    description: 'Validate business ideas with comprehensive analysis',
  },
  {
    name: 'Research',
    icon: Search,
    color: 'from-cyan-500 to-teal-500',
    description: 'Analyze markets and research competitors',
  },
  {
    name: 'Development',
    icon: Layers,
    color: 'from-rose-500 to-pink-500',
    description: 'Get tech stack recommendations and code scaffolding',
  },
  {
    name: 'Strategy',
    icon: DollarSign,
    color: 'from-emerald-500 to-green-600',
    description: 'Build business models and pitch decks',
  },
  {
    name: 'Marketing',
    icon: Layout,
    color: 'from-sky-500 to-blue-500',
    description: 'Optimize landing pages for conversions',
  },
]

const KEYBOARD_SHORTCUTS = [
  { keys: ['⌘', 'K'], description: 'Open search & command palette' },
  { keys: ['⌘', '/'], description: 'Show keyboard shortcuts' },
  { keys: ['1-9'], description: 'Quick open tool 1-9' },
  { keys: ['Esc'], description: 'Close any dialog or modal' },
]

const slideVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 300 : -300,
    opacity: 0,
  }),
  center: {
    x: 0,
    opacity: 1,
  },
  exit: (direction: number) => ({
    x: direction > 0 ? -300 : 300,
    opacity: 0,
  }),
}

export function OnboardingModal({ open, onOpenChange, onTryTool }: OnboardingModalProps) {
  const [step, setStep] = React.useState(0)
  const [direction, setDirection] = React.useState(1)
  const [dontShowAgain, setDontShowAgain] = React.useState(false)

  const totalSteps = 3

  const handleNext = () => {
    if (step < totalSteps - 1) {
      setDirection(1)
      setStep(step + 1)
    } else {
      completeOnboarding()
    }
  }

  const handleBack = () => {
    if (step > 0) {
      setDirection(-1)
      setStep(step - 1)
    }
  }

  const handleSkip = () => {
    completeOnboarding()
  }

  const completeOnboarding = () => {
    if (dontShowAgain) {
      try {
        localStorage.setItem(STORAGE_KEY, 'true')
      } catch {
        // Silently fail
      }
    }
    onOpenChange(false)
    // Reset step for next time
    setTimeout(() => {
      setStep(0)
      setDontShowAgain(false)
    }, 300)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="sm:max-w-lg p-0 gap-0 overflow-hidden backdrop-blur-xl bg-background/90 shadow-2xl shadow-emerald-500/10 border-white/10 dark:border-white/5"
        showCloseButton={false}
      >
        {/* Accessible title/description (visually hidden) */}
        <DialogTitle className="sr-only">Welcome to Antigravity AI</DialogTitle>
        <DialogDescription className="sr-only">Onboarding guide for new users</DialogDescription>

        {/* Gradient border wrapper */}
        <div className="absolute inset-0 rounded-lg pointer-events-none p-[1px]">
          <div className="w-full h-full rounded-lg bg-gradient-to-br from-emerald-400/30 via-transparent to-teal-400/30 dark:from-emerald-400/15 dark:via-transparent dark:to-teal-400/15" />
        </div>

        {/* Progress bar */}
        <div className="h-1 bg-emerald-100 dark:bg-emerald-900/30">
          <motion.div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-500"
            animate={{ width: `${((step + 1) / totalSteps) * 100}%` }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
          />
        </div>

        {/* Content area with animated steps */}
        <div className="relative overflow-hidden min-h-[380px]">
          <AnimatePresence mode="wait" custom={direction}>
            {step === 0 && (
              <StepWelcome key="welcome" direction={direction} />
            )}
            {step === 1 && (
              <StepCategories key="categories" direction={direction} />
            )}
            {step === 2 && (
              <StepQuickTips
                key="tips"
                direction={direction}
                onTryTool={onTryTool}
                onComplete={completeOnboarding}
              />
            )}
          </AnimatePresence>
        </div>

        {/* Footer with navigation */}
        <div className="border-t border-white/10 dark:border-white/5 px-6 py-4 flex items-center justify-between bg-background/60 backdrop-blur-md">
          {/* Don't show again checkbox */}
          <div className="flex items-center gap-2">
            <Checkbox
              id="dont-show"
              checked={dontShowAgain}
              onCheckedChange={(checked) => setDontShowAgain(checked === true)}
              className="data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
            />
            <Label htmlFor="dont-show" className="text-xs text-muted-foreground cursor-pointer">
              Don&apos;t show again
            </Label>
          </div>

          {/* Navigation buttons */}
          <div className="flex items-center gap-2">
            {step > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBack}
                className="text-xs text-muted-foreground"
              >
                <ArrowLeft className="size-3.5" />
                Back
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSkip}
              className="text-xs text-muted-foreground"
            >
              Skip
            </Button>
            <Button
              size="sm"
              onClick={handleNext}
              className="bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/25 gap-1.5"
            >
              {step === totalSteps - 1 ? (
                <>
                  Get Started
                  <Sparkles className="size-3.5" />
                </>
              ) : (
                <>
                  Next
                  <ArrowRight className="size-3.5" />
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function StepWelcome({ direction }: { direction: number }) {
  return (
    <motion.div
      custom={direction}
      variants={slideVariants}
      initial="enter"
      animate="center"
      exit="exit"
      transition={{ duration: 0.35, ease: 'easeInOut' }}
      className="p-8 flex flex-col items-center text-center"
    >
      {/* Animated Sparkles icon */}
      <motion.div
        className="relative mb-6"
        animate={{
          scale: [1, 1.1, 1],
          rotate: [0, 5, -5, 0],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      >
        <div className="size-20 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center shadow-xl shadow-emerald-500/30">
          <Sparkles className="size-10 text-white" />
        </div>
        {/* Floating particles */}
        <motion.div
          className="absolute -top-2 -right-2 size-4 rounded-full bg-emerald-400"
          animate={{ y: [-4, 4, -4], opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
        <motion.div
          className="absolute -bottom-1 -left-3 size-3 rounded-full bg-teal-400"
          animate={{ y: [4, -4, 4], opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2.5, repeat: Infinity, delay: 0.5 }}
        />
      </motion.div>

      <h2 className="text-2xl font-bold text-foreground mb-3">
        Welcome to Antigravity AI
      </h2>
      <p className="text-muted-foreground text-sm leading-relaxed max-w-sm mb-6">
        Your AI-powered SaaS toolkit for ideation, validation, and growth.
        Generate ideas, analyze markets, and build faster with 10 specialized tools.
      </p>

      {/* Feature highlights */}
      <div className="grid grid-cols-3 gap-3 w-full max-w-sm">
        {[
          { icon: Zap, label: '10 AI Tools', desc: 'Specialized' },
          { icon: TrendingUp, label: 'Smart Analysis', desc: 'AI-Powered' },
          { icon: Code2, label: 'Code Ready', desc: 'Exportable' },
        ].map((item, i) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + i * 0.1 }}
            className="flex flex-col items-center gap-1 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-800/30"
          >
            <item.icon className="size-5 text-emerald-600 dark:text-emerald-400" />
            <span className="text-xs font-semibold text-foreground">{item.label}</span>
            <span className="text-[10px] text-muted-foreground">{item.desc}</span>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}

function StepCategories({ direction }: { direction: number }) {
  return (
    <motion.div
      custom={direction}
      variants={slideVariants}
      initial="enter"
      animate="center"
      exit="exit"
      transition={{ duration: 0.35, ease: 'easeInOut' }}
      className="p-6"
    >
      <div className="text-center mb-5">
        <h2 className="text-xl font-bold text-foreground mb-2">
          Explore 10 AI Tools
        </h2>
        <p className="text-sm text-muted-foreground">
          Organized into 7 categories to cover your entire startup journey
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[260px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-emerald-200 dark:scrollbar-thumb-emerald-800">
        {TOOL_CATEGORIES.map((cat, i) => (
          <motion.div
            key={cat.name}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 + i * 0.05 }}
            className="flex items-center gap-3 p-3 rounded-xl border border-border/50 bg-background/60 hover:bg-emerald-50 dark:hover:bg-emerald-900/10 transition-colors"
          >
            <div className={`size-9 rounded-lg bg-gradient-to-br ${cat.color} flex items-center justify-center shrink-0 shadow-sm`}>
              <cat.icon className="size-4 text-white" />
            </div>
            <div className="min-w-0">
              <span className="text-sm font-semibold text-foreground block">{cat.name}</span>
              <span className="text-xs text-muted-foreground truncate block">{cat.description}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}

function StepQuickTips({
  direction,
  onTryTool,
  onComplete,
}: {
  direction: number
  onTryTool?: () => void
  onComplete: () => void
}) {
  return (
    <motion.div
      custom={direction}
      variants={slideVariants}
      initial="enter"
      animate="center"
      exit="exit"
      transition={{ duration: 0.35, ease: 'easeInOut' }}
      className="p-6"
    >
      <div className="text-center mb-5">
        <h2 className="text-xl font-bold text-foreground mb-2">
          Quick Tips
        </h2>
        <p className="text-sm text-muted-foreground">
          Master these shortcuts to work faster
        </p>
      </div>

      {/* Keyboard shortcuts */}
      <div className="space-y-3 mb-6">
        {KEYBOARD_SHORTCUTS.map((shortcut, i) => (
          <motion.div
            key={shortcut.description}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + i * 0.08 }}
            className="flex items-center justify-between p-3 rounded-xl border border-border/50 bg-background/60"
          >
            <span className="text-sm text-foreground">{shortcut.description}</span>
            <div className="flex items-center gap-1">
              {shortcut.keys.map((key, ki) => (
                <React.Fragment key={ki}>
                  {ki > 0 && (
                    <span className="text-xs text-muted-foreground">+</span>
                  )}
                  <kbd className="inline-flex items-center justify-center px-2 py-1 text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/30 border border-emerald-200 dark:border-emerald-800/50 rounded-md shadow-sm">
                    {key}
                  </kbd>
                </React.Fragment>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      {/* CTA */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="text-center"
      >
        <p className="text-sm text-muted-foreground mb-3">
          Ready to dive in? Try a tool now!
        </p>
        <Button
          onClick={() => {
            onComplete()
            onTryTool?.()
          }}
          className="bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/25 gap-2"
        >
          <Presentation className="size-4" />
          Try Idea Generator
        </Button>
      </motion.div>
    </motion.div>
  )
}

// Helper to check if onboarding should show
export function shouldShowOnboarding(): boolean {
  if (typeof window === 'undefined') return false
  try {
    return !localStorage.getItem(STORAGE_KEY)
  } catch {
    return true
  }
}
