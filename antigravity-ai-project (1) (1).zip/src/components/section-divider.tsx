'use client'

import * as React from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'

export type DividerVariant = 'wave' | 'gradient' | 'dots'

interface SectionDividerProps {
  variant?: DividerVariant
}

// ── Wave Divider ─────────────────────────────────────────────────────────────
function WaveDivider() {
  const ref = React.useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  })
  const fillWidth = useTransform(scrollYProgress, [0, 0.5], ['0%', '100%'])

  return (
    <div ref={ref} className="flex justify-center py-4 sm:py-6">
      <div className="relative w-full max-w-7xl h-8 sm:h-10 overflow-hidden">
        {/* Animated wave SVG background */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 1200 40"
          preserveAspectRatio="none"
          fill="none"
          aria-hidden="true"
        >
          {/* Primary wave with animation */}
          <motion.path
            d="M0 20 Q150 0 300 20 T600 20 T900 20 T1200 20"
            stroke="rgba(16,185,129,0.2)"
            strokeWidth="1.5"
            fill="none"
            className="hidden sm:block"
            animate={{
              d: [
                "M0 20 Q150 0 300 20 T600 20 T900 20 T1200 20",
                "M0 20 Q150 5 300 18 T600 22 T900 18 T1200 20",
                "M0 20 Q150 0 300 20 T600 20 T900 20 T1200 20",
              ],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
          {/* Secondary wave */}
          <motion.path
            d="M0 20 Q300 5 600 20 T1200 20"
            stroke="rgba(16,185,129,0.12)"
            strokeWidth="0.8"
            fill="none"
            className="hidden sm:block"
            animate={{
              d: [
                "M0 20 Q300 5 600 20 T1200 20",
                "M0 20 Q300 10 600 18 T1200 22",
                "M0 20 Q300 5 600 20 T1200 20",
              ],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: 0.5,
            }}
          />
          {/* Third decorative wave */}
          <motion.path
            d="M0 22 Q200 12 400 22 T800 22 T1200 22"
            stroke="rgba(20,184,166,0.1)"
            strokeWidth="0.5"
            fill="none"
            className="hidden sm:block"
            animate={{
              d: [
                "M0 22 Q200 12 400 22 T800 22 T1200 22",
                "M0 22 Q200 16 400 20 T800 24 T1200 22",
                "M0 22 Q200 12 400 22 T800 22 T1200 22",
              ],
            }}
            transition={{
              duration: 6,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: 1,
            }}
          />
          {/* Mobile: simpler animated wave */}
          <motion.path
            d="M0 20 Q600 5 1200 20"
            stroke="rgba(16,185,129,0.2)"
            strokeWidth="1"
            fill="none"
            className="sm:hidden"
            animate={{
              d: [
                "M0 20 Q600 5 1200 20",
                "M0 20 Q600 10 1200 18",
                "M0 20 Q600 5 1200 20",
              ],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        </svg>
        {/* Animated fill */}
        <motion.div
          className="absolute top-1/2 -translate-y-1/2 h-px"
          style={{
            width: fillWidth,
            background:
              'linear-gradient(90deg, transparent, rgba(16,185,129,0.5), rgba(20,184,166,0.5), rgba(16,185,129,0.5), transparent)',
            willChange: 'width',
          }}
        />
      </div>
    </div>
  )
}

// ── Gradient Divider ─────────────────────────────────────────────────────────
function GradientDivider() {
  const ref = React.useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  })
  const pulseOpacity = useTransform(scrollYProgress, [0.3, 0.5, 0.7], [0.4, 1, 0.4])

  return (
    <div ref={ref} className="flex justify-center py-4 sm:py-6">
      <div className="relative h-px w-full max-w-7xl">
        {/* Background track */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'linear-gradient(90deg, rgba(52,211,153,0.08), rgba(52,211,153,0.15), rgba(52,211,153,0.08))',
          }}
        />
        {/* Animated gradient fill with shimmer */}
        <motion.div
          className="absolute inset-0 animate-gradient-shift"
          style={{
            opacity: pulseOpacity,
            background:
              'linear-gradient(90deg, transparent, rgba(16,185,129,0.4), rgba(20,184,166,0.6), rgba(16,185,129,0.4), transparent)',
            willChange: 'opacity, background-position',
            backgroundSize: '200% 100%',
          }}
        />
        {/* Shimmer sweep overlay */}
        <div className="absolute inset-0 overflow-hidden">
          <div
            className="absolute inset-0 animate-shimmer"
            style={{
              background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.15) 50%, transparent 100%)',
              backgroundSize: '200% 100%',
            }}
          />
        </div>
        {/* Desktop: extra glow */}
        <div
          className="absolute inset-0 h-[3px] -top-[1px] hidden sm:block"
          style={{
            background:
              'linear-gradient(90deg, transparent, rgba(16,185,129,0.08), transparent)',
          }}
        />
      </div>
    </div>
  )
}

// ── Dots Divider ─────────────────────────────────────────────────────────────
function DotsDivider() {
  const ref = React.useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  })
  const opacity = useTransform(scrollYProgress, [0, 0.5, 1], [0.2, 0.8, 0.2])

  // Number of dots varies by screen size (we render max and hide some on mobile)
  const desktopDots = 15
  const dotPositions = Array.from({ length: desktopDots }, (_, i) => i)

  return (
    <div ref={ref} className="flex justify-center py-4 sm:py-6">
      <motion.div
        className="flex items-center justify-center gap-2 sm:gap-3 w-full max-w-7xl px-8"
        style={{ opacity, willChange: 'opacity' }}
      >
        {dotPositions.map((i) => {
          // Stagger animation delay based on position
          const delay = i * 0.15
          const isProminent = i === Math.floor(desktopDots / 2)
          // Gradient from emerald to teal across dots
          const gradientPosition = i / (desktopDots - 1)
          const color = isProminent
            ? 'bg-emerald-400 dark:bg-emerald-400'
            : gradientPosition < 0.5
              ? 'bg-emerald-400/70 dark:bg-emerald-500/70'
              : 'bg-teal-400/70 dark:bg-teal-500/70'
          return (
            <motion.div
              key={i}
              animate={{
                scale: [1, isProminent ? 1.6 : 1.2, 1],
                opacity: [0.3, isProminent ? 1 : 0.7, 0.3],
              }}
              transition={{
                duration: 2.5,
                repeat: Infinity,
                ease: 'easeInOut',
                delay: delay % 2.5,
              }}
              className={`rounded-full ${color} ${
                isProminent ? 'size-2 sm:size-2.5' : 'size-1 sm:size-1.5'
              } ${i > 7 && i < 12 ? '' : 'hidden sm:block'}`}
            />
          )
        })}
      </motion.div>
    </div>
  )
}

// ── Main SectionDivider ──────────────────────────────────────────────────────
export function SectionDivider({ variant = 'gradient' }: SectionDividerProps) {
  switch (variant) {
    case 'wave':
      return <WaveDivider />
    case 'gradient':
      return <GradientDivider />
    case 'dots':
      return <DotsDivider />
    default:
      return <GradientDivider />
  }
}
