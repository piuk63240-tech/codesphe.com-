'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { Rocket, Menu, X, History, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ThemeToggle } from '@/components/toolbar'

const navLinks = [
  { label: 'Tools', href: '#tools' },
  { label: 'Analytics', href: '#analytics' },
  { label: 'Features', href: '#features' },
  { label: 'How It Works', href: '#how-it-works' },
]

interface NavbarProps {
  onHistoryClick?: () => void
  onCommandPaletteOpen?: () => void
}

export function Navbar({ onHistoryClick, onCommandPaletteOpen }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false)
  const [scrolled, setScrolled] = React.useState(false)

  React.useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false)
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: 'spring', stiffness: 100, damping: 20 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-background/70 backdrop-blur-2xl border-b border-white/10 dark:border-white/5 shadow-lg shadow-emerald-500/5'
          : 'bg-transparent'
      }`}
    >
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2 group">
            <div className="flex size-9 items-center justify-center rounded-lg bg-emerald-500 text-white shadow-lg shadow-emerald-500/25 group-hover:shadow-emerald-500/40 transition-shadow">
              <Rocket className="size-5" />
            </div>
            <span className="text-lg sm:text-xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              Antigravity AI
            </span>
          </a>

          {/* Desktop Nav Links */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Button
                key={link.href}
                variant="ghost"
                size="sm"
                onClick={() => handleNavClick(link.href)}
                className="text-muted-foreground hover:text-foreground"
              >
                {link.label}
              </Button>
            ))}
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button
              variant="ghost"
              size="icon"
              className="text-muted-foreground hover:text-foreground"
              onClick={onHistoryClick}
              aria-label="Open history panel"
            >
              <History className="size-5" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="hidden sm:flex items-center gap-1.5 h-8 text-muted-foreground hover:text-foreground border-border/60"
              onClick={onCommandPaletteOpen}
              aria-label="Open command palette"
            >
              <Search className="size-3.5" />
              <kbd className="pointer-events-none inline-flex h-5 items-center gap-0.5 rounded border border-border/60 bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground">
                <span className="text-xs">⌘</span>K
              </kbd>
            </Button>
            <Button
              size="sm"
              className="hidden sm:flex bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/25 ripple-effect"
              onClick={() => handleNavClick('#tools')}
            >
              Get Started
            </Button>
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {mobileMenuOpen ? (
                <X className="size-5" />
              ) : (
                <Menu className="size-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-border/50 mt-2 pt-3 pb-3 space-y-1 overflow-hidden"
          >
            {navLinks.map((link) => (
              <Button
                key={link.href}
                variant="ghost"
                className="w-full justify-start"
                onClick={() => handleNavClick(link.href)}
              >
                {link.label}
              </Button>
            ))}
            <Button
              variant="ghost"
              className="w-full justify-start"
              onClick={() => {
                setMobileMenuOpen(false)
                onHistoryClick?.()
              }}
            >
              <History className="size-4 mr-2" />
              History & Saved
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start"
              onClick={() => {
                setMobileMenuOpen(false)
                onCommandPaletteOpen?.()
              }}
            >
              <Search className="size-4 mr-2" />
              Search Tools
              <kbd className="ml-auto inline-flex h-5 items-center gap-0.5 rounded border border-border/60 bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground">
                <span className="text-xs">⌘</span>K
              </kbd>
            </Button>
            <Button
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/25 ripple-effect"
              onClick={() => handleNavClick('#tools')}
            >
              Get Started
            </Button>
          </motion.div>
        )}
      </nav>
    </motion.header>
  )
}
