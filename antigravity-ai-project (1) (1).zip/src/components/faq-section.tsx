'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { HelpCircle } from 'lucide-react'
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from '@/components/ui/accordion'

const faqs = [
  {
    question: 'What is Antigravity AI?',
    answer:
      'Antigravity AI is an AI-powered SaaS tools platform designed for founders, builders, and entrepreneurs. It provides 10 specialized AI tools that help you ideate, validate, plan, and launch your SaaS business faster than ever before — from idea generation and validation to pitch deck creation and market analysis.',
  },
  {
    question: 'How many AI tools are available?',
    answer:
      'We offer 10 specialized AI tools covering the full SaaS building journey: Idea Generator, Idea Validator, Market Analyzer, Competitor Researcher, Business Model Generator, Pitch Deck Creator, Tech Stack Recommender, Landing Page Optimizer, Pricing Strategy Advisor, and Prompt Generator. Each tool is fine-tuned for startup-specific outcomes.',
  },
  {
    question: 'Is there a free plan?',
    answer:
      'Yes! Our Starter plan gives you 5 free AI generations per day with access to 3 core tools. It\'s a great way to explore the platform and see the quality of our AI results before committing to a paid plan. No credit card required.',
  },
  {
    question: 'How accurate are the AI results?',
    answer:
      'Our AI models achieve 99% accuracy on structured outputs and are continuously refined based on user feedback. Each tool uses specialized prompts and models trained on startup-specific data, ensuring results are relevant, actionable, and tailored to the SaaS ecosystem.',
  },
  {
    question: 'Can I export my results?',
    answer:
      'Yes! Pro and Enterprise plans allow you to export results as Markdown and PDF files. You can also share results via direct links with your team or stakeholders. The free Starter plan includes copy-to-clipboard functionality for quick sharing.',
  },
  {
    question: 'What AI models do you use?',
    answer:
      'We use a combination of advanced large language models (LLMs) that are optimized for different tasks. Our system automatically selects the best model for each tool type to ensure the highest quality output. Enterprise customers can also request custom AI model configurations.',
  },
  {
    question: 'Is my data secure?',
    answer:
      'Absolutely. We use enterprise-grade encryption (AES-256) for all data at rest and in transit. Your inputs and results are never used to train our models. We are SOC 2 compliant and follow industry best practices for data privacy and security.',
  },
  {
    question: 'Can I cancel my subscription?',
    answer:
      'Yes, you can cancel your subscription at any time with no penalties or hidden fees. When you cancel, you\'ll retain access to your plan features until the end of your current billing period. Your saved ideas and history are always accessible, even on the free plan.',
  },
]

export function FaqSection() {
  return (
    <section className="py-20 sm:py-28" id="faq" aria-labelledby="faq-heading">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 rounded-full bg-emerald-100 dark:bg-emerald-900/30 px-4 py-1.5 text-sm font-medium text-emerald-700 dark:text-emerald-400 mb-4">
            <HelpCircle className="size-4" />
            FAQ
          </div>
          <h2
            id="faq-heading"
            className="text-3xl sm:text-4xl font-bold text-foreground mb-4"
            aria-label="Frequently Asked Questions"
          >
            Frequently Asked{' '}
            <span className="bg-gradient-to-r from-emerald-500 to-teal-500 bg-clip-text text-transparent">
              Questions
            </span>
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            Everything you need to know about Antigravity AI. Can&apos;t find
            the answer you&apos;re looking for? Reach out to our support team.
          </p>
        </motion.div>

        {/* FAQ Grid - 2 columns on desktop, 1 on mobile */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-12">
          {/* Left column: questions 0-3 */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5 }}
          >
            <Accordion type="single" collapsible className="space-y-3">
              {faqs.slice(0, 4).map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`left-${index}`}
                  className="rounded-xl border bg-card px-6 data-[state=open]:border-emerald-300 dark:data-[state=open]:border-emerald-700 data-[state=open]:shadow-md data-[state=open]:shadow-emerald-500/5 transition-all duration-200"
                >
                  <AccordionTrigger className="hover:text-emerald-600 dark:hover:text-emerald-400 hover:no-underline py-5 text-left text-[15px] font-semibold">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>

          {/* Right column: questions 4-7 */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.5 }}
          >
            <Accordion type="single" collapsible className="space-y-3">
              {faqs.slice(4, 8).map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`right-${index}`}
                  className="rounded-xl border bg-card px-6 data-[state=open]:border-emerald-300 dark:data-[state=open]:border-emerald-700 data-[state=open]:shadow-md data-[state=open]:shadow-emerald-500/5 transition-all duration-200"
                >
                  <AccordionTrigger className="hover:text-emerald-600 dark:hover:text-emerald-400 hover:no-underline py-5 text-left text-[15px] font-semibold">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
