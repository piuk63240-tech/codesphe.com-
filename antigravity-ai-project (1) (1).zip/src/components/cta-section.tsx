'use client'

import * as React from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function CtaSection() {
  const handleScrollTo = (id: string) => {
    const element = document.querySelector(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section className="py-20 sm:py-28 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600" />
      <div className="absolute inset-0 opacity-10">
        <img src="/hero-bg.png" alt="" className="w-full h-full object-cover" aria-hidden="true" />
      </div>

      {/* Animated particles/shapes */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div
          animate={{ y: [0, -15, 0], opacity: [0.1, 0.2, 0.1] }}
          transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute top-10 left-[10%] w-64 h-64 rounded-full bg-white/10 blur-3xl"
        />
        <motion.div
          animate={{ y: [0, 15, 0], opacity: [0.1, 0.2, 0.1] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
          className="absolute bottom-10 right-[10%] w-80 h-80 rounded-full bg-white/10 blur-3xl"
        />
        {/* Small floating shapes */}
        <div className="absolute top-[20%] left-[15%] w-3 h-3 rounded-full bg-white/20 animate-float-shape" />
        <div className="absolute top-[60%] right-[20%] w-2 h-2 rounded-full bg-white/25 animate-float-shape" style={{ animationDelay: '2s' }} />
        <div className="absolute top-[40%] left-[70%] w-4 h-4 rounded-sm bg-white/15 animate-float-shape" style={{ animationDelay: '4s' }} />
        <div className="absolute top-[30%] right-[40%] w-2 h-2 rounded-full bg-white/20 animate-float-shape" style={{ animationDelay: '1s' }} />
        <div className="absolute bottom-[25%] left-[30%] w-3 h-3 rounded-sm bg-white/15 animate-float-shape" style={{ animationDelay: '3s' }} />
        <div className="absolute top-[15%] left-[50%] w-2 h-2 rounded-full bg-white/20 animate-float-shape" style={{ animationDelay: '5s' }} />
        <div className="absolute bottom-[40%] right-[15%] w-3 h-3 rotate-45 bg-white/15 animate-float-shape" style={{ animationDelay: '2.5s' }} />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          {/* Glassmorphism card wrapper */}
          <div className="backdrop-blur-md bg-white/10 rounded-3xl p-8 sm:p-12 border border-white/20">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-sm text-white/90 mb-8 backdrop-blur-sm">
              <Sparkles className="size-4" />
              <span>Start building today</span>
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
              Ready to Launch Your
              <br />
              Next Big Idea?
            </h2>

            <p className="mx-auto max-w-2xl text-lg text-white/80 mb-10">
              Join thousands of founders who use Antigravity AI to validate ideas,
              generate strategies, and build their SaaS businesses faster.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                size="lg"
                className="bg-white text-emerald-700 hover:bg-white/90 shadow-xl shadow-black/20 transition-all group"
                onClick={() => handleScrollTo('#tools')}
              >
                Get Started Free
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-white/30 text-white hover:bg-white/10 hover:text-white"
                onClick={() => handleScrollTo('#how-it-works')}
              >
                Learn More
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Trust indicators */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-12 flex flex-wrap items-center justify-center gap-6 text-white/60 text-sm"
        >
          <div className="flex items-center gap-2">
            <svg className="size-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
            <span>No credit card required</span>
          </div>
          <div className="flex items-center gap-2">
            <svg className="size-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
            <span>10 AI tools included</span>
          </div>
          <div className="flex items-center gap-2">
            <svg className="size-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
            <span>Results in seconds</span>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
