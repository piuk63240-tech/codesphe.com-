'use client'

import * as React from 'react'
import { useTheme } from 'next-themes'
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from '@/components/ui/command'
import {
  Lightbulb,
  MessageSquareCode,
  ShieldCheck,
  TrendingUp,
  Search,
  Layers,
  DollarSign,
  Code2,
  Layout,
  Presentation,
  Sun,
  Moon,
  Compass,
  Sparkles,
  HelpCircle,
} from 'lucide-react'

const tools = [
  { id: 'idea-generator', name: 'Idea Generator', icon: Lightbulb, description: 'Generate innovative AI SaaS business ideas', category: 'Tools' },
  { id: 'prompt-generator', name: 'Prompt Generator', icon: MessageSquareCode, description: 'Create optimized prompts for AI models', category: 'Tools' },
  { id: 'idea-validator', name: 'Idea Validator', icon: ShieldCheck, description: 'Validate your business idea with comprehensive AI analysis', category: 'Tools' },
  { id: 'market-analyzer', name: 'Market Analyzer', icon: TrendingUp, description: 'Analyze market size, trends, and opportunities', category: 'Tools' },
  { id: 'competitor-research', name: 'Competitor Research', icon: Search, description: 'Research competitors and find market gaps', category: 'Tools' },
  { id: 'tech-stack-recommender', name: 'Tech Stack Recommender', icon: Layers, description: 'Get AI-recommended tech stacks for your project', category: 'Tools' },
  { id: 'business-model-generator', name: 'Business Model Generator', icon: DollarSign, description: 'Generate complete business models and pricing strategies', category: 'Tools' },
  { id: 'code-scaffolder', name: 'Code Scaffolder', icon: Code2, description: 'Generate production-ready code scaffolding and project structure', category: 'Tools' },
  { id: 'landing-page-optimizer', name: 'Landing Page Optimizer', icon: Layout, description: 'Generate high-converting landing page copy', category: 'Tools' },
  { id: 'pitch-deck-generator', name: 'Pitch Deck Generator', icon: Presentation, description: 'Create compelling pitch deck content for investors', category: 'Tools' },
]

interface CommandPaletteProps {
  onToolSelect: (toolId: string) => void
  open?: boolean
  onOpenChange?: (open: boolean) => void
}

export function CommandPalette({ onToolSelect, open: externalOpen, onOpenChange }: CommandPaletteProps) {
  const [internalOpen, setInternalOpen] = React.useState(false)

  const open = externalOpen !== undefined ? externalOpen : internalOpen
  const setOpen = onOpenChange !== undefined ? onOpenChange : setInternalOpen
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
  }, [])

  React.useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault()
        if (onOpenChange) {
          onOpenChange(!externalOpen)
        } else {
          setInternalOpen((prev) => !prev)
        }
      }
    }
    document.addEventListener('keydown', down)
    return () => document.removeEventListener('keydown', down)
  }, [externalOpen, onOpenChange])

  const handleSelect = (callback: () => void) => {
    setOpen(false)
    callback()
  }

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="Search tools, actions..." />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="AI Tools">
          {tools.map((tool) => (
            <CommandItem
              key={tool.id}
              value={tool.name}
              onSelect={() => handleSelect(() => onToolSelect(tool.id))}
            >
              <tool.icon className="mr-2 size-4" />
              <span>{tool.name}</span>
              <span className="ml-auto text-xs text-muted-foreground">
                {tool.description}
              </span>
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Actions">
          <CommandItem
            value="Toggle Theme"
            onSelect={() =>
              handleSelect(() =>
                setTheme(theme === 'dark' ? 'light' : 'dark')
              )
            }
          >
            {mounted && theme === 'dark' ? (
              <Sun className="mr-2 size-4" />
            ) : (
              <Moon className="mr-2 size-4" />
            )}
            <span>Toggle Theme</span>
          </CommandItem>
          <CommandItem
            value="Go to Tools"
            onSelect={() =>
              handleSelect(() =>
                document
                  .querySelector('#tools')
                  ?.scrollIntoView({ behavior: 'smooth' })
              )
            }
          >
            <Compass className="mr-2 size-4" />
            <span>Go to Tools</span>
          </CommandItem>
          <CommandItem
            value="Go to Features"
            onSelect={() =>
              handleSelect(() =>
                document
                  .querySelector('#features')
                  ?.scrollIntoView({ behavior: 'smooth' })
              )
            }
          >
            <Sparkles className="mr-2 size-4" />
            <span>Go to Features</span>
          </CommandItem>
          <CommandItem
            value="Go to How It Works"
            onSelect={() =>
              handleSelect(() =>
                document
                  .querySelector('#how-it-works')
                  ?.scrollIntoView({ behavior: 'smooth' })
              )
            }
          >
            <HelpCircle className="mr-2 size-4" />
            <span>Go to How It Works</span>
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  )
}
