'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'

interface ConfettiParticle {
  id: number
  x: number
  y: number
  rotation: number
  size: number
  color: string
  delay: number
  duration: number
}

const CONFETTI_COLORS = [
  'bg-emerald-400',
  'bg-emerald-500',
  'bg-teal-400',
  'bg-teal-500',
  'bg-cyan-400',
  'bg-emerald-300',
  'bg-teal-300',
]

function generateParticles(count: number): ConfettiParticle[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    x: (Math.random() - 0.5) * 300, // spread horizontally
    y: -(Math.random() * 200 + 50), // burst upward then fall
    rotation: Math.random() * 720 - 360,
    size: Math.random() * 4 + 6, // 6-10px
    color: CONFETTI_COLORS[Math.floor(Math.random() * CONFETTI_COLORS.length)],
    delay: Math.random() * 0.2,
    duration: Math.random() * 0.5 + 1.0, // 1.0-1.5s
  }))
}

interface ConfettiEffectProps {
  trigger: boolean
}

export function ConfettiEffect({ trigger }: ConfettiEffectProps) {
  const [particles, setParticles] = React.useState<ConfettiParticle[]>([])
  const prevTrigger = React.useRef(false)

  React.useEffect(() => {
    // Fire confetti when trigger goes from false to true
    if (trigger && !prevTrigger.current) {
      setParticles(generateParticles(30))

      // Clean up particles after animation
      const timer = setTimeout(() => {
        setParticles([])
      }, 2000)

      return () => clearTimeout(timer)
    }
    prevTrigger.current = trigger
  }, [trigger])

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
      <AnimatePresence>
        {particles.map((particle) => (
          <motion.div
            key={particle.id}
            initial={{
              x: '50%',
              y: '10%',
              scale: 0,
              opacity: 1,
              rotate: 0,
            }}
            animate={{
              x: `calc(50% + ${particle.x}px)`,
              y: `calc(10% + ${particle.y}px)`,
              scale: 1,
              opacity: [1, 1, 0],
              rotate: particle.rotation,
            }}
            exit={{ opacity: 0 }}
            transition={{
              duration: particle.duration,
              delay: particle.delay,
              ease: 'easeOut',
              opacity: {
                duration: particle.duration,
                delay: particle.delay,
                times: [0, 0.6, 1],
              },
            }}
            className={`absolute rounded-md ${particle.color}`}
            style={{
              width: particle.size,
              height: particle.size,
            }}
          />
        ))}
      </AnimatePresence>
    </div>
  )
}
