'use client'

import * as React from 'react'
import { motion, type Variants } from 'framer-motion'

// ── Animation Variants ──────────────────────────────────────────────────────────
type AnimationVariant =
  | 'fade-up'
  | 'fade-down'
  | 'slide-left'
  | 'slide-right'
  | 'scale-up'
  | 'rotate-in'

const variantMap: Record<AnimationVariant, Variants> = {
  'fade-up': {
    hidden: { opacity: 0, y: 40 },
    visible: { opacity: 1, y: 0 },
  },
  'fade-down': {
    hidden: { opacity: 0, y: -40 },
    visible: { opacity: 1, y: 0 },
  },
  'slide-left': {
    hidden: { opacity: 0, x: 60 },
    visible: { opacity: 1, x: 0 },
  },
  'slide-right': {
    hidden: { opacity: 0, x: -60 },
    visible: { opacity: 1, x: 0 },
  },
  'scale-up': {
    hidden: { opacity: 0, scale: 0.85 },
    visible: { opacity: 1, scale: 1 },
  },
  'rotate-in': {
    hidden: { opacity: 0, rotate: -8, scale: 0.9 },
    visible: { opacity: 1, rotate: 0, scale: 1 },
  },
}

// ── ScrollReveal Props ──────────────────────────────────────────────────────────
interface ScrollRevealProps {
  children: React.ReactNode
  variant?: AnimationVariant
  duration?: number
  delay?: number
  className?: string
  /** Pass to enable staggered children – wraps children in a motion container */
  staggerChildren?: number
  /** Margin to trigger animation, e.g. "-80px" */
  margin?: string
  /** Only animate once */
  once?: boolean
}

// ── ScrollReveal Component ─────────────────────────────────────────────────────
export function ScrollReveal({
  children,
  variant = 'fade-up',
  duration = 0.6,
  delay = 0,
  className,
  staggerChildren = 0,
  margin = '-60px',
  once = true,
}: ScrollRevealProps) {
  const selectedVariant = variantMap[variant]

  if (staggerChildren > 0) {
    return (
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once, margin }}
        variants={{
          hidden: {},
          visible: {
            transition: { staggerChildren },
          },
        }}
        className={className}
      >
        {React.Children.map(children, (child) => (
          <motion.div
            variants={{
              hidden: selectedVariant.hidden,
              visible: {
                ...selectedVariant.visible,
                transition: { duration, ease: 'easeOut' },
              },
            }}
          >
            {child}
          </motion.div>
        ))}
      </motion.div>
    )
  }

  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once, margin }}
      variants={selectedVariant}
      transition={{ duration, delay, ease: 'easeOut' }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

// ── ScrollRevealItem (for use inside a staggered parent) ───────────────────────
interface ScrollRevealItemProps {
  children: React.ReactNode
  variant?: AnimationVariant
  duration?: number
  className?: string
}

export function ScrollRevealItem({
  children,
  variant = 'fade-up',
  duration = 0.5,
  className,
}: ScrollRevealItemProps) {
  const selectedVariant = variantMap[variant]

  return (
    <motion.div
      variants={{
        hidden: selectedVariant.hidden,
        visible: {
          ...selectedVariant.visible,
          transition: { duration, ease: 'easeOut' },
        },
      }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

// ── StaggerContainer (parent for staggered children) ───────────────────────────
interface StaggerContainerProps {
  children: React.ReactNode
  staggerChildren?: number
  delayChildren?: number
  className?: string
  margin?: string
  once?: boolean
}

export function StaggerContainer({
  children,
  staggerChildren = 0.1,
  delayChildren = 0,
  className,
  margin = '-60px',
  once = true,
}: StaggerContainerProps) {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once, margin }}
      variants={{
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: { staggerChildren, delayChildren },
        },
      }}
      className={className}
    >
      {children}
    </motion.div>
  )
}
