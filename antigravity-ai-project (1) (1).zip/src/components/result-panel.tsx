'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import ReactMarkdown from 'react-markdown'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism'
import { Check, Copy, Share2, Star, Bookmark, SkipForward, Download, FileText, FileCode, FileType, FileDown, Mail, Linkedin } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { ConfettiEffect } from '@/components/confetti-effect'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu'

interface SaveMetadata {
  title?: string
  category?: string
  notes?: string
}

interface ResultPanelProps {
  result: string | null
  isGenerating: boolean
  onSaveIdea?: (metadata?: SaveMetadata) => void
  onRate?: (rating: number) => void
}

// Code block component with syntax highlighting and copy button
function CodeBlock({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLElement> & { children?: React.ReactNode }) {
  const match = /language-(\w+)/.exec(className || '')
  const codeString = String(children).replace(/\n$/, '')

  const [copied, setCopied] = React.useState(false)

  const handleCopyCode = () => {
    navigator.clipboard.writeText(codeString)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  if (match) {
    return (
      <div className="relative group my-3">
        <SyntaxHighlighter
          style={oneDark}
          language={match[1]}
          PreTag="div"
          customStyle={{
            margin: 0,
            borderRadius: '0.5rem',
            fontSize: '0.8125rem',
          }}
        >
          {codeString}
        </SyntaxHighlighter>
        <button
          onClick={handleCopyCode}
          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-white/10 hover:bg-white/20 rounded px-2 py-1 text-xs text-white flex items-center gap-1"
          aria-label="Copy code"
        >
          {copied ? (
            <>
              <Check className="size-3" />
              Copied!
            </>
          ) : (
            <>
              <Copy className="size-3" />
              Copy
            </>
          )}
        </button>
      </div>
    )
  }

  return (
    <code
      className="bg-muted px-1.5 py-0.5 rounded text-sm font-mono text-emerald-600 dark:text-emerald-400"
      {...props}
    >
      {children}
    </code>
  )
}

// Custom markdown components with syntax highlighting and styled elements
const markdownComponents = {
  code: CodeBlock,
  h1: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <h1 className="text-xl font-bold text-foreground mt-6 mb-3 first:mt-0">
      {children}
    </h1>
  ),
  h2: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <h2 className="text-lg font-bold text-foreground mt-5 mb-2">{children}</h2>
  ),
  h3: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <h3 className="text-base font-semibold text-foreground mt-4 mb-2">
      {children}
    </h3>
  ),
  p: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <p className="text-sm text-muted-foreground leading-relaxed mb-3">
      {children}
    </p>
  ),
  ul: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <ul className="text-sm text-muted-foreground list-disc pl-5 mb-3 space-y-1">
      {children}
    </ul>
  ),
  ol: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <ol className="text-sm text-muted-foreground list-decimal pl-5 mb-3 space-y-1">
      {children}
    </ol>
  ),
  li: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <li className="text-sm text-muted-foreground">{children}</li>
  ),
  strong: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <strong className="text-foreground font-semibold">{children}</strong>
  ),
  blockquote: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <blockquote className="border-l-4 border-emerald-500 pl-4 italic text-muted-foreground my-3">
      {children}
    </blockquote>
  ),
  table: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <div className="overflow-x-auto my-3">
      <table className="w-full text-sm border-collapse">{children}</table>
    </div>
  ),
  th: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <th className="border border-border px-3 py-2 bg-muted text-foreground font-semibold text-left">
      {children}
    </th>
  ),
  td: ({ children }: React.HTMLAttributes<HTMLElement>) => (
    <td className="border border-border px-3 py-2 text-muted-foreground">
      {children}
    </td>
  ),
  hr: () => <hr className="border-border my-4" />,
  a: ({
    children,
    href,
  }: React.AnchorHTMLAttributes<HTMLAnchorElement>) => (
    <a
      href={href}
      className="text-emerald-600 dark:text-emerald-400 underline underline-offset-2 hover:text-emerald-700 dark:hover:text-emerald-300"
      target="_blank"
      rel="noopener noreferrer"
    >
      {children}
    </a>
  ),
}

// Enhanced generating progress bar with animated gradient
function GeneratingProgress() {
  const [progress, setProgress] = React.useState(0)

  React.useEffect(() => {
    const startTime = Date.now()
    const totalDuration = 25000 // 25 seconds to reach 90%
    const targetProgress = 90

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime
      const rawProgress = Math.min((elapsed / totalDuration) * targetProgress, targetProgress)
      setProgress(rawProgress)
    }, 100)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="w-full max-w-xs space-y-2">
      <div className="h-2 w-full rounded-full bg-emerald-100 dark:bg-emerald-900/30 overflow-hidden">
        <motion.div
          className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500"
          initial={{ width: '0%' }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          style={{
            backgroundSize: '200% 100%',
          }}
        />
      </div>
      <p className="text-xs text-muted-foreground text-center">
        Usually takes 15-30 seconds
      </p>
    </div>
  )
}

// Rotating tip messages during generation
const tipMessages = [
  'AI is analyzing your input...',
  'Generating comprehensive insights...',
  'Structuring results for clarity...',
  'Adding actionable recommendations...',
]

function GeneratingTips() {
  const [tipIndex, setTipIndex] = React.useState(0)

  React.useEffect(() => {
    const interval = setInterval(() => {
      setTipIndex((prev) => (prev + 1) % tipMessages.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="h-5 flex items-center justify-center">
      <AnimatePresence mode="wait">
        <motion.p
          key={tipIndex}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.3 }}
          className="text-xs text-emerald-600 dark:text-emerald-400 font-medium"
        >
          {tipMessages[tipIndex]}
        </motion.p>
      </AnimatePresence>
    </div>
  )
}

export function ResultPanel({
  result,
  isGenerating,
  onSaveIdea,
  onRate,
}: ResultPanelProps) {
  const [copied, setCopied] = React.useState(false)
  const [currentRating, setCurrentRating] = React.useState(0)
  const [saved, setSaved] = React.useState(false)
  const [savePopoverOpen, setSavePopoverOpen] = React.useState(false)
  const [saveTitle, setSaveTitle] = React.useState('')
  const [saveCategory, setSaveCategory] = React.useState('')
  const [saveNotes, setSaveNotes] = React.useState('')

  // Category options for save popover
  const categoryOptions = [
    { value: '💡 Idea', label: '💡 Idea' },
    { value: '📊 Analysis', label: '📊 Analysis' },
    { value: '📝 Content', label: '📝 Content' },
    { value: '🔧 Technical', label: '🔧 Technical' },
    { value: '⭐ Favorite', label: '⭐ Favorite' },
  ]

  // Typing animation state
  const [displayedResult, setDisplayedResult] = React.useState('')
  const [isTyping, setIsTyping] = React.useState(false)
  const skipRef = React.useRef(false)
  const intervalRef = React.useRef<ReturnType<typeof setInterval> | null>(null)

  // Confetti trigger state
  const [confettiTrigger, setConfettiTrigger] = React.useState(false)
  const prevResultRef = React.useRef<string | null>(null)

  // Confetti: fire when result first appears (goes from null to non-null)
  React.useEffect(() => {
    if (result && !prevResultRef.current && !isGenerating) {
      setConfettiTrigger(true)
      setTimeout(() => setConfettiTrigger(false), 2000)
    }
    prevResultRef.current = result
  }, [result, isGenerating])

  // Typing effect: when result changes, gradually reveal text
  React.useEffect(() => {
    if (!result) {
      setDisplayedResult('')
      setIsTyping(false)
      skipRef.current = false
      return
    }

    // Reset skip flag
    skipRef.current = false
    setIsTyping(true)
    let index = 0

    intervalRef.current = setInterval(() => {
      // If skip was triggered, show full result immediately
      if (skipRef.current) {
        setDisplayedResult(result)
        setIsTyping(false)
        if (intervalRef.current) clearInterval(intervalRef.current)
        return
      }

      if (index < result.length) {
        // Reveal in chunks for performance (5 chars at a time, 15ms interval)
        const chunkSize = Math.min(5, result.length - index)
        setDisplayedResult(result.substring(0, index + chunkSize))
        index += chunkSize
      } else {
        setDisplayedResult(result)
        setIsTyping(false)
        if (intervalRef.current) clearInterval(intervalRef.current)
      }
    }, 15)

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [result])

  const handleSkip = (e: React.MouseEvent) => {
    e.stopPropagation()
    e.preventDefault()
    skipRef.current = true
    setDisplayedResult(result || '')
    setIsTyping(false)
  }

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!result) return
    try {
      await navigator.clipboard.writeText(result)
      setCopied(true)
      toast.success('Copied to clipboard!')
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // Fallback for older browsers
      const textarea = document.createElement('textarea')
      textarea.value = result
      document.body.appendChild(textarea)
      textarea.select()
      document.execCommand('copy')
      document.body.removeChild(textarea)
      setCopied(true)
      toast.success('Copied to clipboard!')
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleRate = (rating: number, e: React.MouseEvent) => {
    e.stopPropagation()
    setCurrentRating(rating)
    onRate?.(rating)
    toast.success(`Rated ${rating} star${rating > 1 ? 's' : ''}!`)
  }

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (saved) {
      // If already saved, unsaving is simple
      setSaved(false)
      toast('Idea unsaved')
    } else {
      // Open save popover for first save
      setSavePopoverOpen(true)
    }
  }

  const handleConfirmSave = (e: React.MouseEvent) => {
    e.stopPropagation()
    setSaved(true)
    setSavePopoverOpen(false)
    onSaveIdea?.({
      title: saveTitle || undefined,
      category: saveCategory || undefined,
      notes: saveNotes || undefined,
    })
    toast.success('Idea saved!')
  }

  const handleShareMarkdown = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!result) return
    try {
      await navigator.clipboard.writeText(result)
      toast.success('Copied as Markdown!')
    } catch {
      const textarea = document.createElement('textarea')
      textarea.value = result
      document.body.appendChild(textarea)
      textarea.select()
      document.execCommand('copy')
      document.body.removeChild(textarea)
      toast.success('Copied as Markdown!')
    }
  }

  const handleShareFormattedText = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!result) return
    const plainText = result
      .replace(/```[\s\S]*?```/g, (match) => match.replace(/```\w*\n?/g, '').trim())
      .replace(/`([^`]+)`/g, '$1')
      .replace(/\*\*(.+?)\*\*/g, '$1')
      .replace(/\*(.+?)\*/g, '$1')
      .replace(/^#{1,6}\s+/gm, '')
      .replace(/^>\s+/gm, '')
      .replace(/^---+$/gm, '---')
      .replace(/^[\-\*]\s+/gm, '• ')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/!\[([^\]]*)\]\([^)]+\)/g, '$1')
    try {
      await navigator.clipboard.writeText(plainText)
      toast.success('Copied as Formatted Text!')
    } catch {
      const textarea = document.createElement('textarea')
      textarea.value = plainText
      document.body.appendChild(textarea)
      textarea.select()
      document.execCommand('copy')
      document.body.removeChild(textarea)
      toast.success('Copied as Formatted Text!')
    }
  }

  const handleShareEmail = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!result) return
    const subject = encodeURIComponent('Antigravity AI - Generated Result')
    const body = encodeURIComponent(result.substring(0, 2000))
    window.open(`mailto:?subject=${subject}&body=${body}`, '_blank')
    toast.success('Opening email client...')
  }

  const handleShareTwitter = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!result) return
    const summary = result.split('\n').find(l => l.trim() && !l.startsWith('#') && !l.startsWith('```'))?.trim() || 'Check out my AI-generated result!'
    const truncatedSummary = summary.length > 200 ? summary.substring(0, 197) + '...' : summary
    const text = encodeURIComponent(`${truncatedSummary}\n\n🚀 Generated with Antigravity AI`)
    window.open(`https://twitter.com/intent/tweet?text=${text}`, '_blank')
    toast.success('Opening Twitter/X...')
  }

  const handleShareLinkedIn = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!result) return
    const summary = result.split('\n').find(l => l.trim() && !l.startsWith('#') && !l.startsWith('```'))?.trim() || 'Check out my AI-generated result!'
    const truncatedSummary = summary.length > 200 ? summary.substring(0, 197) + '...' : summary
    const text = encodeURIComponent(`${truncatedSummary}\n\n🚀 Generated with Antigravity AI`)
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent('https://antigravity.ai')}&summary=${text}`, '_blank')
    toast.success('Opening LinkedIn...')
  }

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!result) return
    const blob = new Blob([result], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `antigravity-ai-result-${new Date().toISOString().slice(0, 10)}.md`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success('Downloaded as Markdown!')
  }

  const handleDownloadHtml = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!result) return
    // Simple markdown-to-HTML conversion for export
    let htmlContent = result
      // Headers
      .replace(/^### (.+)$/gm, '<h3>$1</h3>')
      .replace(/^## (.+)$/gm, '<h2>$1</h2>')
      .replace(/^# (.+)$/gm, '<h1>$1</h1>')
      // Bold and italic
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      // Code blocks
      .replace(/```(\w*)\n([\s\S]*?)```/g, '<pre><code class="language-$1">$2</code></pre>')
      // Inline code
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      // Unordered lists
      .replace(/^\- (.+)$/gm, '<li>$1</li>')
      // Ordered lists
      .replace(/^\d+\. (.+)$/gm, '<li>$1</li>')
      // Blockquotes
      .replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>')
      // Horizontal rules
      .replace(/^---$/gm, '<hr>')
      // Paragraphs - wrap remaining lines
      .replace(/^(?!<[hupblo]|<li|<hr|<pre|<code|<strong|<em|<blockquote)(.+)$/gm, '<p>$1</p>')
      // Line breaks
      .replace(/\n\n/g, '\n')

    const fullHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Antigravity AI Result</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      max-width: 800px;
      margin: 40px auto;
      padding: 0 20px;
      color: #1a1a1a;
      line-height: 1.6;
      background: #fafafa;
    }
    h1 { color: #059669; border-bottom: 2px solid #10b981; padding-bottom: 8px; font-size: 1.75rem; }
    h2 { color: #047857; font-size: 1.4rem; margin-top: 1.5em; }
    h3 { color: #065f46; font-size: 1.15rem; margin-top: 1.25em; }
    code { background: #e5e7eb; padding: 2px 6px; border-radius: 4px; font-size: 0.9em; color: #059669; }
    pre { background: #1e1e1e; color: #d4d4d4; padding: 16px; border-radius: 8px; overflow-x: auto; margin: 1em 0; }
    pre code { background: none; color: inherit; padding: 0; }
    blockquote { border-left: 4px solid #10b981; padding-left: 16px; color: #6b7280; font-style: italic; margin: 1em 0; }
    li { margin: 4px 0; }
    hr { border: none; border-top: 1px solid #e5e7eb; margin: 1.5em 0; }
    strong { color: #111827; }
    .header { text-align: center; margin-bottom: 2em; padding-bottom: 1em; border-bottom: 1px solid #e5e7eb; }
    .header h1 { border: none; font-size: 1.5rem; margin-bottom: 0.25em; }
    .header p { color: #6b7280; font-size: 0.875rem; }
  </style>
</head>
<body>
  <div class="header">
    <h1>🚀 Antigravity AI</h1>
    <p>Generated on ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
  </div>
  <main>
    ${htmlContent}
  </main>
</body>
</html>`

    const blob = new Blob([fullHtml], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `antigravity-ai-result-${new Date().toISOString().slice(0, 10)}.html`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success('Downloaded as HTML!')
  }

  const handleDownloadPdf = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!result) return
    // Reuse the HTML conversion logic for PDF export
    let htmlContent = result
      .replace(/^### (.+)$/gm, '<h3>$1</h3>')
      .replace(/^## (.+)$/gm, '<h2>$1</h2>')
      .replace(/^# (.+)$/gm, '<h1>$1</h1>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      .replace(/```(\w*)\n([\s\S]*?)```/g, '<pre><code class="language-$1">$2</code></pre>')
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/^\- (.+)$/gm, '<li>$1</li>')
      .replace(/^\d+\. (.+)$/gm, '<li>$1</li>')
      .replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>')
      .replace(/^---$/gm, '<hr>')
      .replace(/^(?!<[hupblo]|<li|<hr|<pre|<code|<strong|<em|<blockquote)(.+)$/gm, '<p>$1</p>')
      .replace(/\n\n/g, '\n')

    const printHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Antigravity AI Result</title>
  <style>
    @media print {
      body { margin: 0; padding: 20px; }
      .no-print { display: none !important; }
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      max-width: 800px;
      margin: 40px auto;
      padding: 0 20px;
      color: #1a1a1a;
      line-height: 1.6;
      background: #ffffff;
    }
    h1 { color: #059669; border-bottom: 2px solid #10b981; padding-bottom: 8px; font-size: 1.75rem; }
    h2 { color: #047857; font-size: 1.4rem; margin-top: 1.5em; }
    h3 { color: #065f46; font-size: 1.15rem; margin-top: 1.25em; }
    code { background: #f3f4f6; padding: 2px 6px; border-radius: 4px; font-size: 0.9em; color: #059669; }
    pre { background: #1e1e1e; color: #d4d4d4; padding: 16px; border-radius: 8px; overflow-x: auto; margin: 1em 0; }
    pre code { background: none; color: inherit; padding: 0; }
    blockquote { border-left: 4px solid #10b981; padding-left: 16px; color: #6b7280; font-style: italic; margin: 1em 0; }
    li { margin: 4px 0; }
    hr { border: none; border-top: 1px solid #e5e7eb; margin: 1.5em 0; }
    strong { color: #111827; }
    .header { text-align: center; margin-bottom: 2em; padding-bottom: 1em; border-bottom: 1px solid #e5e7eb; }
    .header h1 { border: none; font-size: 1.5rem; margin-bottom: 0.25em; }
    .header p { color: #6b7280; font-size: 0.875rem; }
    .print-btn {
      position: fixed; bottom: 24px; right: 24px;
      background: #059669; color: white; border: none; border-radius: 8px;
      padding: 10px 20px; font-size: 14px; cursor: pointer;
      box-shadow: 0 4px 12px rgba(5,150,105,0.3);
      display: flex; align-items: center; gap: 8px;
    }
    .print-btn:hover { background: #047857; }
    .print-hint {
      position: fixed; bottom: 72px; right: 24px;
      color: #6b7280; font-size: 12px;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>🚀 Antigravity AI</h1>
    <p>Generated on ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
  </div>
  <main>
    ${htmlContent}
  </main>
  <p class="print-hint no-print">Use your browser's "Save as PDF" option in the print dialog</p>
  <button class="print-btn no-print" onclick="window.print()">
    📄 Print / Save as PDF
  </button>
</body>
</html>`

    const blob = new Blob([printHtml], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const printWindow = window.open(url, '_blank')
    if (printWindow) {
      printWindow.onload = () => {
        URL.revokeObjectURL(url)
      }
    } else {
      URL.revokeObjectURL(url)
    }
    toast.success('PDF export opened! Use Save as PDF in the print dialog.')
  }

  const handleDownloadPlainText = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!result) return
    // Strip markdown formatting to produce plain text
    let plainText = result
      // Remove code blocks
      .replace(/```[\s\S]*?```/g, (match) => match.replace(/```\w*\n?/g, '').trim())
      // Remove inline code backticks
      .replace(/`([^`]+)`/g, '$1')
      // Remove bold markers
      .replace(/\*\*(.+?)\*\*/g, '$1')
      // Remove italic markers
      .replace(/\*(.+?)\*/g, '$1')
      // Remove heading markers
      .replace(/^#{1,6}\s+/gm, '')
      // Remove blockquote markers
      .replace(/^>\s+/gm, '')
      // Remove horizontal rules
      .replace(/^---+$/gm, '---')
      // Remove list markers (unordered)
      .replace(/^[\-\*]\s+/gm, '• ')
      // Remove list markers (ordered)
      .replace(/^\d+\.\s+/gm, (match) => match)
      // Remove links, keep text
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      // Remove images, keep alt text
      .replace(/!\[([^\]]*)\]\([^)]+\)/g, '$1')

    const blob = new Blob([plainText], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `antigravity-ai-result-${new Date().toISOString().slice(0, 10)}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success('Downloaded as Plain Text!')
  }

  return (
    <div className="flex flex-col h-full relative">
      {/* Confetti Effect */}
      <ConfettiEffect trigger={confettiTrigger} />

      {/* Results Area */}
      <ScrollArea className="flex-1 min-h-0">
        <div className="p-4">
          <AnimatePresence mode="wait">
            {isGenerating ? (
              <motion.div
                key="generating"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center py-12 gap-5"
              >
                {/* Spinner */}
                <div className="relative">
                  <div className="size-14 rounded-full border-4 border-emerald-200 dark:border-emerald-800" />
                  <div className="size-14 rounded-full border-4 border-emerald-500 border-t-transparent animate-spin absolute inset-0" />
                </div>

                {/* Progress Bar */}
                <GeneratingProgress />

                {/* Tips */}
                <GeneratingTips />
              </motion.div>
            ) : result ? (
              <motion.div
                key="result"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="max-w-none"
              >
                <ReactMarkdown components={markdownComponents}>
                  {displayedResult}
                </ReactMarkdown>
                {/* Blinking cursor during typing */}
                {isTyping && (
                  <span className="inline-block w-2 h-4 bg-emerald-500 animate-pulse ml-0.5 align-text-bottom" />
                )}
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center py-16 gap-3"
              >
                <div className="size-16 rounded-full bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center">
                  <Star className="size-8 text-emerald-500" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium text-foreground">
                    No results yet
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Fill in the form and click Generate to get started
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </ScrollArea>

      {/* Skip Button - appears during typing animation */}
      <AnimatePresence>
        {isTyping && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute bottom-16 right-4 z-10"
          >
            <Button
              size="sm"
              variant="outline"
              onClick={handleSkip}
              className="text-xs bg-background/80 backdrop-blur-sm border-emerald-500/30 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 shadow-lg"
            >
              <SkipForward className="size-3.5 text-emerald-500" />
              Skip
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Action Bar */}
      {result && !isGenerating && !isTyping && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="border-t bg-muted/30 p-3 flex items-center justify-between gap-2"
        >
          <div className="flex items-center gap-1">
            {/* Star Rating */}
            <div className="flex items-center gap-0.5 mr-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={(e) => handleRate(star, e)}
                  className="p-0.5 transition-colors hover:scale-110"
                  aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
                >
                  <Star
                    className={`size-4 ${
                      star <= currentRating
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-muted-foreground/40 hover:text-amber-400'
                    }`}
                  />
                </button>
              ))}
            </div>

            {/* Save with Popover */}
            <Popover open={savePopoverOpen} onOpenChange={setSavePopoverOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleSave}
                  className="text-xs"
                >
                  <Bookmark
                    className={`size-3.5 ${
                      saved ? 'fill-emerald-500 text-emerald-500' : ''
                    }`}
                  />
                  {saved ? 'Saved' : 'Save'}
                </Button>
              </PopoverTrigger>
              <PopoverContent
                align="start"
                className="w-72 p-4 space-y-3"
                onOpenAutoFocus={(e) => e.preventDefault()}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <div className="flex items-center justify-center size-6 rounded-full bg-emerald-100 dark:bg-emerald-900/30">
                      <Bookmark className="size-3 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <span className="text-sm font-semibold text-foreground">Save Idea</span>
                  </div>
                  <p className="text-[11px] text-muted-foreground">Add details to organize your saved ideas</p>
                </div>

                <div className="space-y-2">
                  <div className="space-y-1">
                    <Label htmlFor="save-title" className="text-xs">Title</Label>
                    <Input
                      id="save-title"
                      value={saveTitle}
                      onChange={(e) => setSaveTitle(e.target.value)}
                      placeholder="Enter a custom title..."
                      className="text-xs h-8"
                      onClick={(e) => e.stopPropagation()}
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="save-category" className="text-xs">Category</Label>
                    <div className="flex flex-wrap gap-1.5">
                      {categoryOptions.map((opt) => (
                        <button
                          key={opt.value}
                          onClick={(e) => {
                            e.stopPropagation()
                            setSaveCategory(saveCategory === opt.value ? '' : opt.value)
                          }}
                          className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-medium transition-all cursor-pointer ${
                            saveCategory === opt.value
                              ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 dark:border-emerald-700'
                              : 'border-border bg-background text-muted-foreground hover:border-emerald-300 dark:hover:border-emerald-700 hover:text-emerald-600 dark:hover:text-emerald-400'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="save-notes" className="text-xs">Notes (optional)</Label>
                    <Textarea
                      id="save-notes"
                      value={saveNotes}
                      onChange={(e) => setSaveNotes(e.target.value)}
                      placeholder="Add a brief note..."
                      className="text-xs resize-none"
                      rows={2}
                      onClick={(e) => e.stopPropagation()}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs"
                    onClick={(e) => {
                      e.stopPropagation()
                      setSavePopoverOpen(false)
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    size="sm"
                    className="text-xs bg-emerald-500 hover:bg-emerald-600 text-white"
                    onClick={handleConfirmSave}
                  >
                    <Bookmark className="size-3" />
                    Save
                  </Button>
                </div>
              </PopoverContent>
            </Popover>

            {/* Share Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="text-xs" onClick={(e) => e.stopPropagation()}>
                  <Share2 className="size-3.5" />
                  Share
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-52">
                <DropdownMenuLabel className="text-xs">Share Options</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={handleShareMarkdown}
                  className="cursor-pointer"
                >
                  <FileText className="size-4 text-emerald-500" />
                  <span>Copy as Markdown</span>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={handleShareFormattedText}
                  className="cursor-pointer"
                >
                  <FileType className="size-4 text-teal-500" />
                  <span>Copy as Formatted Text</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={handleShareEmail}
                  className="cursor-pointer"
                >
                  <Mail className="size-4 text-amber-500" />
                  <span>Share via Email</span>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={handleShareTwitter}
                  className="cursor-pointer"
                >
                  <svg className="size-4 text-foreground shrink-0" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                  <span>Share on X</span>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={handleShareLinkedIn}
                  className="cursor-pointer"
                >
                  <Linkedin className="size-4 text-teal-600" />
                  <span>Share on LinkedIn</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="flex items-center gap-1">
            {/* Download with format options */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => e.stopPropagation()}
                  className="text-xs"
                >
                  <Download className="size-3.5" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuLabel className="text-xs">Export Format</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    handleDownload(e)
                  }}
                  className="cursor-pointer"
                >
                  <FileText className="size-4 text-emerald-500" />
                  <span>Markdown (.md)</span>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    handleDownloadHtml(e)
                  }}
                  className="cursor-pointer"
                >
                  <FileCode className="size-4 text-teal-500" />
                  <span>HTML (.html)</span>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    handleDownloadPlainText(e)
                  }}
                  className="cursor-pointer"
                >
                  <FileType className="size-4 text-amber-500" />
                  <span>Plain Text (.txt)</span>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    handleDownloadPdf(e)
                  }}
                  className="cursor-pointer"
                >
                  <FileDown className="size-4 text-rose-500" />
                  <span>PDF (.pdf)</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Copy */}
            <Button
              variant="outline"
              size="sm"
              onClick={handleCopy}
              className="text-xs"
            >
              {copied ? (
                <>
                  <Check className="size-3.5 text-emerald-500" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="size-3.5" />
                  Copy
                </>
              )}
            </Button>
          </div>
        </motion.div>
      )}
    </div>
  )
}
