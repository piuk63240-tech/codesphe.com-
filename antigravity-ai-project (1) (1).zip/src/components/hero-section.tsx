'use client'

import * as React from 'react'
import { motion, useInView, useScroll, useTransform } from 'framer-motion'
import { ArrowRight, Sparkles, Zap, ChevronDown } from 'lucide-react'
import { Button } from '@/components/ui/button'

// ── Animated Counter ────────────────────────────────────────────────────────
function AnimatedCounter({
  target,
  suffix = '',
  prefix = '',
}: {
  target: number
  suffix?: string
  prefix?: string
}) {
  const [count, setCount] = React.useState(0)
  const ref = React.useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true })

  React.useEffect(() => {
    if (!inView) return
    let start = 0
    const end = target
    if (end === 0) return
    const duration = 2000
    const stepTime = duration / end
    const timer = setInterval(() => {
      start += 1
      setCount(start)
      if (start >= end) clearInterval(timer)
    }, stepTime)
    return () => clearInterval(timer)
  }, [inView, target])

  return (
    <div ref={ref}>
      {prefix}
      {count}
      {suffix}
    </div>
  )
}

// ── Typing Subtitle ─────────────────────────────────────────────────────────
const phrases = [
  'Validate SaaS ideas in seconds',
  'Generate AI prompts that convert',
  'Analyze markets with AI precision',
  'Build your startup faster',
]

function TypingSubtitle() {
  const [phraseIndex, setPhraseIndex] = React.useState(0)
  const [text, setText] = React.useState('')
  const [isDeleting, setIsDeleting] = React.useState(false)

  React.useEffect(() => {
    const currentPhrase = phrases[phraseIndex]

    const timeout = setTimeout(
      () => {
        if (!isDeleting) {
          setText(currentPhrase.slice(0, text.length + 1))
          if (text.length + 1 === currentPhrase.length) {
            setTimeout(() => setIsDeleting(true), 2000)
          }
        } else {
          setText(currentPhrase.slice(0, text.length - 1))
          if (text.length - 1 === 0) {
            setIsDeleting(false)
            setPhraseIndex((prev) => (prev + 1) % phrases.length)
          }
        }
      },
      isDeleting ? 35 : 70
    )

    return () => clearTimeout(timeout)
  }, [text, isDeleting, phraseIndex])

  return (
    <span className="inline-flex items-center">
      <span>{text}</span>
      <motion.span
        animate={{ opacity: [1, 0] }}
        transition={{ duration: 0.5, repeat: Infinity, repeatType: 'reverse' }}
        className="ml-0.5 inline-block w-[2px] h-[1.1em] bg-emerald-500 dark:bg-emerald-400 align-middle"
      />
    </span>
  )
}

// ── Particle with trail effect ──────────────────────────────────────────────
interface FloatingParticleProps {
  className?: string
  size: number
  color: string
  duration: number
  delay?: number
  xDrift?: number
  shape?: 'circle' | 'diamond'
}

function FloatingParticle({
  className,
  size,
  color,
  duration,
  delay = 0,
  xDrift = 0,
  shape = 'circle',
}: FloatingParticleProps) {
  // Generate trail positions
  const trailCount = 3
  const trailDelays = Array.from({ length: trailCount }, (_, i) => (i + 1) * 0.15)

  return (
    <div className={`absolute ${className ?? ''}`} style={{ width: size, height: size }}>
      {/* Trail particles (fading copies with slight offset) */}
      {trailDelays.map((trailDelay, i) => (
        <motion.div
          key={`trail-${i}`}
          animate={{
            y: [0, -50, 0],
            x: [0, xDrift, 0],
            opacity: [0, 0.15 - i * 0.04, 0],
          }}
          transition={{
            duration,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: delay + trailDelay,
          }}
          className={`absolute inset-0 ${color} ${shape === 'diamond' ? 'rotate-45' : 'rounded-full'}`}
          style={{
            width: size - i * 2,
            height: size - i * 2,
            top: i * 1,
            left: i * 1,
            filter: `blur(${1 + i}px)`,
            willChange: 'transform',
          }}
        />
      ))}
      {/* Main particle */}
      <motion.div
        animate={{
          y: [0, -50, 0],
          x: [0, xDrift, 0],
          opacity: [0.2, 0.8, 0.2],
        }}
        transition={{
          duration,
          repeat: Infinity,
          ease: 'easeInOut',
          delay,
        }}
        className={`absolute inset-0 ${color} ${shape === 'diamond' ? 'rotate-45' : 'rounded-full'}`}
        style={{ willChange: 'transform' }}
      />
    </div>
  )
}

// ── Mouse Spotlight ─────────────────────────────────────────────────────────
function MouseSpotlight() {
  const [mousePos, setMousePos] = React.useState({ x: 50, y: 50 })

  React.useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY })
    }
    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  return (
    <div
      className="absolute inset-0 pointer-events-none z-[1] transition-opacity duration-300"
      style={{
        background: `radial-gradient(600px circle at ${mousePos.x}px ${mousePos.y}px, rgba(16, 185, 129, 0.06), transparent 40%)`,
      }}
    />
  )
}

// ── Hero Section ─────────────────────────────────────────────────────────────
export function HeroSection() {
  const sectionRef = React.useRef<HTMLElement>(null)

  // Parallax scroll transforms
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start start', 'end start'],
  })

  // Particles move slower (parallax effect)
  const particlesY = useTransform(scrollYProgress, [0, 1], [0, 150])
  // Background gradient shifts slightly
  const bgGradientY = useTransform(scrollYProgress, [0, 1], [0, 80])
  // Hero text: subtle zoom out + fade
  const heroScale = useTransform(scrollYProgress, [0, 0.5], [1, 0.95])
  const heroOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0.8])

  const handleScrollTo = (id: string) => {
    const element = document.querySelector(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section
      ref={sectionRef}
      className="relative min-h-[85vh] sm:min-h-[90vh] flex items-center justify-center overflow-hidden pt-16 pb-12 sm:pb-0"
    >
      {/* Background gradient - with slight parallax */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 dark:from-gray-950 dark:via-gray-900 dark:to-emerald-950/20"
        style={{ y: bgGradientY, willChange: 'transform' }}
      />

      {/* Hero background image with overlay */}
      <div className="absolute inset-0 opacity-[0.07] dark:opacity-[0.12]">
        <img
          src="/hero-bg.png"
          alt=""
          className="w-full h-full object-cover"
          aria-hidden="true"
        />
      </div>

      {/* Enhanced grid pattern overlay using repeating-linear-gradient */}
      <div
        className="absolute inset-0 z-[1]"
        style={{
          backgroundImage:
            'repeating-linear-gradient(0deg, rgba(16,185,129,0.04) 0px, rgba(16,185,129,0.04) 1px, transparent 1px, transparent 60px), repeating-linear-gradient(90deg, rgba(16,185,129,0.04) 0px, rgba(16,185,129,0.04) 1px, transparent 1px, transparent 60px)',
        }}
      />

      {/* Radial gradient mouse spotlight */}
      <MouseSpotlight />

      {/* Floating decorative elements - with parallax (slower movement) */}
      <motion.div
        className="absolute inset-0 overflow-hidden pointer-events-none z-[2]"
        style={{ y: particlesY, willChange: 'transform' }}
      >
        {/* Top right circle */}
        <motion.div
          animate={{ y: [0, -20, 0], x: [0, 10, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-emerald-200/30 dark:bg-emerald-800/10 blur-3xl"
        />
        {/* Bottom left circle */}
        <motion.div
          animate={{ y: [0, 20, 0], x: [0, -15, 0] }}
          transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-teal-200/30 dark:bg-teal-800/10 blur-3xl"
        />
        {/* Center floating shape */}
        <motion.div
          animate={{ y: [0, -30, 0], rotate: [0, 5, -5, 0] }}
          transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute top-1/4 right-1/4 w-32 h-32 rounded-2xl bg-emerald-300/20 dark:bg-emerald-700/10 blur-2xl border border-emerald-300/20 dark:border-emerald-700/20"
        />

        {/* ── Original floating dots (mix of circles and diamonds) ── */}
        <FloatingParticle
          className="top-[20%] left-[15%]"
          size={8}
          color="bg-emerald-400"
          duration={6}
        />
        <FloatingParticle
          className="top-[60%] right-[20%]"
          size={12}
          color="bg-teal-400"
          duration={7}
          delay={1}
          shape="diamond"
        />
        <FloatingParticle
          className="top-[40%] left-[70%]"
          size={8}
          color="bg-cyan-400"
          duration={9}
          delay={2}
          xDrift={15}
        />

        {/* ── Additional floating particles (mix shapes) ── */}
        <FloatingParticle
          className="top-[15%] right-[35%]"
          size={6}
          color="bg-emerald-300"
          duration={8}
          delay={0.5}
          xDrift={-10}
          shape="diamond"
        />
        <FloatingParticle
          className="top-[70%] left-[25%]"
          size={10}
          color="bg-teal-300"
          duration={10}
          delay={1.5}
          xDrift={12}
        />
        <FloatingParticle
          className="top-[35%] left-[10%]"
          size={5}
          color="bg-cyan-300"
          duration={7}
          delay={3}
          xDrift={-8}
          shape="diamond"
        />
        <FloatingParticle
          className="top-[80%] right-[15%]"
          size={7}
          color="bg-emerald-400/60"
          duration={9}
          delay={2.5}
          xDrift={10}
        />
        <FloatingParticle
          className="top-[50%] left-[50%]"
          size={4}
          color="bg-teal-200"
          duration={11}
          delay={4}
          xDrift={-12}
          shape="diamond"
        />
        <FloatingParticle
          className="top-[25%] right-[50%]"
          size={6}
          color="bg-emerald-200"
          duration={6.5}
          delay={0.8}
          xDrift={8}
        />
        <FloatingParticle
          className="top-[75%] left-[45%]"
          size={5}
          color="bg-cyan-200"
          duration={8.5}
          delay={3.5}
          xDrift={-6}
          shape="diamond"
        />
        <FloatingParticle
          className="top-[10%] left-[40%]"
          size={4}
          color="bg-emerald-300/70"
          duration={7.5}
          delay={1.2}
          xDrift={14}
        />
        <FloatingParticle
          className="top-[55%] right-[30%]"
          size={8}
          color="bg-teal-200/80"
          duration={9.5}
          delay={2.2}
          xDrift={-9}
          shape="diamond"
        />
      </motion.div>

      {/* Content - with subtle zoom-out parallax */}
      <motion.div
        className="relative z-10 mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 text-center"
        style={{ scale: heroScale, opacity: heroOpacity, willChange: 'transform, opacity' }}
      >
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="inline-flex items-center gap-1.5 sm:gap-2 rounded-full border border-emerald-200 dark:border-emerald-800/50 bg-emerald-50 dark:bg-emerald-900/20 px-3 sm:px-4 py-1.5 text-xs sm:text-sm text-emerald-700 dark:text-emerald-300 mb-6 sm:mb-8">
            <Sparkles className="size-4 animate-pulse-glow" />
            <span>AI-Powered SaaS Tools Platform</span>
            <Zap className="size-3.5" />
          </div>
        </motion.div>

        {/* Main headline */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6"
        >
          <span className="relative inline-block bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 bg-clip-text text-transparent">
            Antigravity AI
            {/* Shimmer / shine sweep */}
            <span className="absolute inset-0 overflow-hidden rounded">
              <span className="absolute inset-0 animate-shimmer bg-gradient-to-r from-transparent via-white/20 to-transparent" />
            </span>
          </span>
          <br />
          <span className="text-foreground mt-2 block">
            Launch Your SaaS Ideas
          </span>
        </motion.h1>

        {/* Typing subtitle */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.25 }}
          className="mx-auto max-w-2xl text-base sm:text-lg md:text-xl text-emerald-600 dark:text-emerald-400 mb-4 h-7 sm:h-8"
        >
          <TypingSubtitle />
        </motion.div>

        {/* Static subtitle with typing cursor at end */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mx-auto max-w-2xl text-sm sm:text-base md:text-lg text-muted-foreground mb-8 sm:mb-10 inline-flex items-center"
        >
          Validate ideas, generate prompts, analyze markets, and build your
          AI-powered SaaS business with 10 specialized tools — all in one
          platform.
          {/* Blinking typing cursor after subtitle */}
          <motion.span
            animate={{ opacity: [1, 0] }}
            transition={{ duration: 0.6, repeat: Infinity, repeatType: 'reverse', delay: 1 }}
            className="ml-1 inline-block w-[2px] h-[1em] bg-emerald-500 dark:bg-emerald-400 align-middle"
          />
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          {/* Glowing CTA button wrapper */}
          <div className="relative group">
            {/* Animated glow ring behind the button */}
            <div className="absolute -inset-0.5 rounded-lg bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 opacity-60 blur-sm group-hover:opacity-90 transition-opacity duration-500 animate-pulse" />
            <Button
              size="lg"
              className="relative bg-emerald-500 hover:bg-emerald-600 text-white shadow-xl shadow-emerald-500/25 hover:shadow-emerald-500/40 transition-all group/btn ripple-effect"
              onClick={() => handleScrollTo('#tools')}
            >
              Get Started Free
              <ArrowRight className="size-4 transition-transform group-hover/btn:translate-x-1" />
            </Button>
          </div>
          <Button
            variant="outline"
            size="lg"
            className="shadow-sm"
            onClick={() => handleScrollTo('#tools')}
          >
            View Tools
          </Button>
        </motion.div>

        {/* Stats with animated counters */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-12 sm:mt-16 grid grid-cols-3 gap-4 sm:gap-8 max-w-xs sm:max-w-lg mx-auto"
        >
          {[
            {
              target: 10,
              suffix: '',
              label: 'AI Tools',
            },
            {
              target: 5,
              suffix: 'K+',
              label: 'Ideas Generated',
            },
            {
              target: 99,
              suffix: '%',
              label: 'Accuracy',
            },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-xl sm:text-2xl md:text-3xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                <AnimatedCounter
                  target={stat.target}
                  suffix={stat.suffix}
                />
              </div>
              <div className="text-xs sm:text-sm text-muted-foreground mt-1">
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* Scroll to explore indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-muted-foreground/60 z-10"
      >
        <span className="text-xs font-medium tracking-wider uppercase">Scroll to explore</span>
        <ChevronDown className="size-5 animate-gentle-bounce" />
      </motion.div>
    </section>
  )
}
