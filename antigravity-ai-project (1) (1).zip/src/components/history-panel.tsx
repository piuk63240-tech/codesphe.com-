'use client'

import * as React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Clock,
  Bookmark,
  Trash2,
  Lightbulb,
  MessageSquareCode,
  ShieldCheck,
  TrendingUp,
  Search,
  Layers,
  DollarSign,
  Code2,
  Layout,
  Presentation,
  Loader2,
  Inbox,
  BookmarkCheck,
  Filter,
} from 'lucide-react'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'

// Map tool type IDs to their icons
const toolIconMap: Record<string, React.ElementType> = {
  'idea-generator': Lightbulb,
  'prompt-generator': MessageSquareCode,
  'idea-validator': ShieldCheck,
  'market-analyzer': TrendingUp,
  'competitor-research': Search,
  'tech-stack-recommender': Layers,
  'business-model-generator': DollarSign,
  'code-scaffolder': Code2,
  'landing-page-optimizer': Layout,
  'pitch-deck-generator': Presentation,
}

// Map tool type IDs to display names
const toolNameMap: Record<string, string> = {
  'idea-generator': 'Idea Generator',
  'prompt-generator': 'Prompt Generator',
  'idea-validator': 'Idea Validator',
  'market-analyzer': 'Market Analyzer',
  'competitor-research': 'Competitor Research',
  'tech-stack-recommender': 'Tech Stack Recommender',
  'business-model-generator': 'Business Model Generator',
  'code-scaffolder': 'Code Scaffolder',
  'landing-page-optimizer': 'Landing Page Optimizer',
  'pitch-deck-generator': 'Pitch Deck Generator',
}

interface HistoryItem {
  id: string
  toolType: string
  input: string
  output: string
  rating: number | null
  createdAt: string
}

interface SavedIdeaItem {
  id: string
  title: string
  description: string
  category: string
  toolType: string
  notes: string | null
  createdAt: string
  updatedAt: string
}

interface HistoryPanelProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

function formatTimeAgo(dateStr: string): string {
  const date = new Date(dateStr)
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffMins = Math.floor(diffMs / 60000)
  const diffHours = Math.floor(diffMins / 60)
  const diffDays = Math.floor(diffHours / 24)

  if (diffMins < 1) return 'Just now'
  if (diffMins < 60) return `${diffMins}m ago`
  if (diffHours < 24) return `${diffHours}h ago`
  if (diffDays < 7) return `${diffDays}d ago`
  return date.toLocaleDateString()
}

function truncateText(text: string, maxLength: number = 80): string {
  if (text.length <= maxLength) return text
  return text.substring(0, maxLength).trim() + '...'
}

function HistoryItemSkeleton() {
  return (
    <div className="rounded-lg border bg-card p-3">
      <div className="flex items-start gap-3">
        <Skeleton className="size-9 shrink-0 rounded-md" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-3 w-12" />
          </div>
          <Skeleton className="h-3 w-full mt-2" />
          <Skeleton className="h-3 w-3/4 mt-1" />
        </div>
      </div>
    </div>
  )
}

function SavedIdeaSkeleton() {
  return (
    <div className="rounded-lg border bg-card p-3">
      <div className="flex items-start gap-3">
        <Skeleton className="size-9 shrink-0 rounded-md" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <Skeleton className="h-4 w-28" />
            <Skeleton className="h-3 w-12" />
          </div>
          <Skeleton className="h-3 w-full mt-2" />
          <Skeleton className="h-3 w-2/3 mt-1" />
          <div className="flex items-center gap-2 mt-2">
            <Skeleton className="h-4 w-14 rounded-full" />
            <Skeleton className="h-3 w-20" />
          </div>
        </div>
      </div>
    </div>
  )
}

export function HistoryPanel({ open, onOpenChange }: HistoryPanelProps) {
  const [historyItems, setHistoryItems] = React.useState<HistoryItem[]>([])
  const [savedIdeas, setSavedIdeas] = React.useState<SavedIdeaItem[]>([])
  const [isLoadingHistory, setIsLoadingHistory] = React.useState(false)
  const [isLoadingIdeas, setIsLoadingIdeas] = React.useState(false)
  const [activeTab, setActiveTab] = React.useState('history')
  const [categoryFilter, setCategoryFilter] = React.useState<string>('all')

  // Category filter options for Saved Ideas tab
  const categoryFilterOptions = [
    { value: 'all', label: 'All' },
    { value: '💡 Idea', label: '💡 Idea' },
    { value: '📊 Analysis', label: '📊 Analysis' },
    { value: '📝 Content', label: '📝 Content' },
    { value: '🔧 Technical', label: '🔧 Technical' },
    { value: '⭐ Favorite', label: '⭐ Favorite' },
  ]

  // Filter saved ideas by category
  const filteredSavedIdeas = React.useMemo(() => {
    if (categoryFilter === 'all') return savedIdeas
    return savedIdeas.filter((item) => item.category === categoryFilter)
  }, [savedIdeas, categoryFilter])

  // Fetch data when the panel opens
  React.useEffect(() => {
    if (open) {
      fetchHistory()
      fetchSavedIdeas()
    }
  }, [open])

  const fetchHistory = async () => {
    setIsLoadingHistory(true)
    try {
      const response = await fetch('/api/tools/history?limit=50')
      if (response.ok) {
        const data = await response.json()
        setHistoryItems(data.results || [])
      }
    } catch {
      // Silently fail
    } finally {
      setIsLoadingHistory(false)
    }
  }

  const fetchSavedIdeas = async () => {
    setIsLoadingIdeas(true)
    try {
      const response = await fetch('/api/tools/saved-ideas?limit=50')
      if (response.ok) {
        const data = await response.json()
        setSavedIdeas(data.ideas || [])
      }
    } catch {
      // Silently fail
    } finally {
      setIsLoadingIdeas(false)
    }
  }

  const handleDeleteHistory = (id: string) => {
    setHistoryItems((prev) => prev.filter((item) => item.id !== id))
  }

  const handleDeleteIdea = (id: string) => {
    setSavedIdeas((prev) => prev.filter((item) => item.id !== id))
  }

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      Ideation: 'bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300 border-amber-200 dark:border-amber-800/50',
      Content: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/50',
      Validation: 'bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-300 border-green-200 dark:border-green-800/50',
      Research: 'bg-cyan-50 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300 border-cyan-200 dark:border-cyan-800/50',
      Development: 'bg-rose-50 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300 border-rose-200 dark:border-rose-800/50',
      Strategy: 'bg-orange-50 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300 border-orange-200 dark:border-orange-800/50',
      Marketing: 'bg-sky-50 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300 border-sky-200 dark:border-sky-800/50',
      '💡 Idea': 'bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300 border-amber-200 dark:border-amber-800/50',
      '📊 Analysis': 'bg-cyan-50 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300 border-cyan-200 dark:border-cyan-800/50',
      '📝 Content': 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/50',
      '🔧 Technical': 'bg-rose-50 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300 border-rose-200 dark:border-rose-800/50',
      '⭐ Favorite': 'bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300 border-amber-200 dark:border-amber-800/50',
    }
    return colors[category] || 'bg-muted text-muted-foreground border-border'
  }

  const getToolIconBg = (toolType: string) => {
    const bgs: Record<string, string> = {
      'idea-generator': 'bg-gradient-to-br from-amber-500 to-orange-500',
      'prompt-generator': 'bg-gradient-to-br from-emerald-500 to-teal-500',
      'idea-validator': 'bg-gradient-to-br from-green-500 to-emerald-600',
      'market-analyzer': 'bg-gradient-to-br from-cyan-500 to-teal-500',
      'competitor-research': 'bg-gradient-to-br from-violet-500 to-purple-500',
      'tech-stack-recommender': 'bg-gradient-to-br from-rose-500 to-pink-500',
      'business-model-generator': 'bg-gradient-to-br from-emerald-500 to-green-600',
      'code-scaffolder': 'bg-gradient-to-br from-teal-500 to-cyan-500',
      'landing-page-optimizer': 'bg-gradient-to-br from-sky-500 to-blue-500',
      'pitch-deck-generator': 'bg-gradient-to-br from-orange-500 to-red-500',
    }
    return bgs[toolType] || 'bg-gradient-to-br from-emerald-500 to-teal-500'
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-md p-0 gap-0">
        <SheetHeader className="p-4 pb-0">
          <SheetTitle className="flex items-center gap-2">
            <Clock className="size-5 text-emerald-500" />
            History & Saved
          </SheetTitle>
          <SheetDescription>
            View your recent tool results and saved ideas
          </SheetDescription>
        </SheetHeader>

        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="flex-1 flex flex-col min-h-0"
        >
          <div className="px-4 pt-2 border-b">
            <TabsList className="w-full">
              <TabsTrigger value="history" className="flex-1 gap-1.5">
                <Clock className="size-3.5" />
                History
                {historyItems.length > 0 && (
                  <span className="ml-1 text-xs text-muted-foreground">
                    ({historyItems.length})
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="saved" className="flex-1 gap-1.5">
                <Bookmark className="size-3.5" />
                Saved Ideas
                {savedIdeas.length > 0 && (
                  <span className="ml-1 text-xs text-muted-foreground">
                    ({savedIdeas.length})
                  </span>
                )}
              </TabsTrigger>
            </TabsList>
          </div>

          {/* History Tab */}
          <TabsContent value="history" className="flex-1 min-h-0">
            <ScrollArea className="h-[calc(100vh-180px)]">
              <div className="p-4 space-y-3">
                {isLoadingHistory ? (
                  <div className="space-y-3">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <HistoryItemSkeleton key={`history-skeleton-${i}`} />
                    ))}
                  </div>
                ) : historyItems.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 gap-3">
                    <div className="size-16 rounded-full bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center">
                      <Inbox className="size-8 text-emerald-500" />
                    </div>
                    <div className="text-center">
                      <p className="text-sm font-medium text-foreground">
                        No history yet
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Your tool results will appear here
                      </p>
                    </div>
                  </div>
                ) : (
                  <AnimatePresence initial={false}>
                    {historyItems.map((item, index) => {
                      const Icon = toolIconMap[item.toolType] || Lightbulb
                      const toolName =
                        toolNameMap[item.toolType] || item.toolType
                      const iconBg = getToolIconBg(item.toolType)

                      return (
                        <motion.div
                          key={item.id}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -20, height: 0 }}
                          transition={{ duration: 0.2, delay: index * 0.03 }}
                          className="group relative rounded-lg border bg-card p-3 hover:border-emerald-200 dark:hover:border-emerald-800/50 transition-colors"
                        >
                          <div className="flex items-start gap-3">
                            {/* Tool Icon */}
                            <div
                              className={`flex size-9 shrink-0 items-center justify-center rounded-md ${iconBg} shadow-sm`}
                            >
                              <Icon className="size-4 text-white" />
                            </div>

                            {/* Content */}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-2">
                                <h4 className="text-sm font-medium text-foreground truncate">
                                  {toolName}
                                </h4>
                                <span className="text-xs text-muted-foreground whitespace-nowrap">
                                  {formatTimeAgo(item.createdAt)}
                                </span>
                              </div>
                              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                                {truncateText(item.output, 120)}
                              </p>
                              {item.rating && (
                                <div className="flex items-center gap-0.5 mt-1.5">
                                  {Array.from({ length: 5 }).map((_, i) => (
                                    <span
                                      key={i}
                                      className={`text-xs ${
                                        i < item.rating!
                                          ? 'text-amber-400'
                                          : 'text-muted-foreground/30'
                                      }`}
                                    >
                                      ★
                                    </span>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Delete button */}
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-7 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                              onClick={() => handleDeleteHistory(item.id)}
                            >
                              <Trash2 className="size-3.5" />
                            </Button>
                          </div>
                        </motion.div>
                      )
                    })}
                  </AnimatePresence>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* Saved Ideas Tab */}
          <TabsContent value="saved" className="flex-1 min-h-0">
            <ScrollArea className="h-[calc(100vh-220px)]">
              <div className="p-4 space-y-3">
                {/* Category Filter */}
                {savedIdeas.length > 0 && (
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <Filter className="size-3.5 text-muted-foreground shrink-0" />
                    {categoryFilterOptions.map((opt) => (
                      <button
                        key={opt.value}
                        onClick={() => setCategoryFilter(opt.value)}
                        className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-medium transition-all cursor-pointer ${
                          categoryFilter === opt.value
                            ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 dark:border-emerald-700'
                            : 'border-border bg-background text-muted-foreground hover:border-emerald-300 dark:hover:border-emerald-700 hover:text-emerald-600 dark:hover:text-emerald-400'
                        }`}
                        aria-label={`Filter by ${opt.label}`}
                        aria-pressed={categoryFilter === opt.value}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                )}
                {isLoadingIdeas ? (
                  <div className="space-y-3">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <SavedIdeaSkeleton key={`idea-skeleton-${i}`} />
                    ))}
                  </div>
                ) : filteredSavedIdeas.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 gap-3">
                    <div className="size-16 rounded-full bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center">
                      <BookmarkCheck className="size-8 text-emerald-500" />
                    </div>
                    <div className="text-center">
                      <p className="text-sm font-medium text-foreground">
                        {categoryFilter !== 'all' ? 'No ideas in this category' : 'No saved ideas yet'}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {categoryFilter !== 'all' ? 'Try a different category filter' : 'Save ideas from tool results to find them here'}
                      </p>
                    </div>
                  </div>
                ) : (
                  <AnimatePresence initial={false}>
                    {filteredSavedIdeas.map((item, index) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20, height: 0 }}
                        transition={{ duration: 0.2, delay: index * 0.03 }}
                        className="group relative rounded-lg border bg-card p-3 hover:border-emerald-200 dark:hover:border-emerald-800/50 transition-colors"
                      >
                        <div className="flex items-start gap-3">
                          {/* Icon */}
                          <div className="flex size-9 shrink-0 items-center justify-center rounded-md bg-emerald-100 dark:bg-emerald-900/30">
                            <BookmarkCheck className="size-4 text-emerald-600 dark:text-emerald-400" />
                          </div>

                          {/* Content */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2">
                              <h4 className="text-sm font-medium text-foreground truncate">
                                {item.title}
                              </h4>
                              <span className="text-xs text-muted-foreground whitespace-nowrap">
                                {formatTimeAgo(item.createdAt)}
                              </span>
                            </div>
                            {item.description && (
                              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                                {truncateText(item.description, 120)}
                              </p>
                            )}
                            {item.notes && (
                              <p className="text-[11px] text-emerald-600/70 dark:text-emerald-400/70 mt-1 line-clamp-1 italic">
                                📎 {truncateText(item.notes, 60)}
                              </p>
                            )}
                            <div className="flex items-center gap-2 mt-2">
                              {item.category && (
                                <Badge
                                  variant="secondary"
                                  className={`text-[10px] px-1.5 py-0 ${getCategoryColor(item.category)}`}
                                >
                                  {item.category}
                                </Badge>
                              )}
                              {item.toolType && (
                                <span className="text-[10px] text-muted-foreground">
                                  via {toolNameMap[item.toolType] || item.toolType}
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Delete button */}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-7 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                            onClick={() => handleDeleteIdea(item.id)}
                          >
                            <Trash2 className="size-3.5" />
                          </Button>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  )
}
