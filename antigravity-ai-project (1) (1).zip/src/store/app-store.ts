'use client'

import { create } from 'zustand'

// ─── Favorites Store ────────────────────────────────────────────────────────

interface FavoritesState {
  favorites: string[]
  toggleFavorite: (toolId: string) => void
  isFavorite: (toolId: string) => boolean
  hydrate: () => void
}

const FAVORITES_KEY = 'antigravity-favorites'

function loadFavorites(): string[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = localStorage.getItem(FAVORITES_KEY)
    return raw ? JSON.parse(raw) : []
  } catch {
    return []
  }
}

function saveFavorites(favorites: string[]) {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites))
  } catch {
    // localStorage may be full or unavailable
  }
}

export const useFavoritesStore = create<FavoritesState>((set, get) => ({
  favorites: [],
  toggleFavorite: (toolId: string) => {
    const current = get().favorites
    const next = current.includes(toolId)
      ? current.filter((id) => id !== toolId)
      : [...current, toolId]
    saveFavorites(next)
    set({ favorites: next })
  },
  isFavorite: (toolId: string) => {
    return get().favorites.includes(toolId)
  },
  hydrate: () => {
    set({ favorites: loadFavorites() })
  },
}))

// ─── Recent Inputs Store ────────────────────────────────────────────────────

export interface RecentInput {
  id: string
  toolId: string
  formData: Record<string, string>
  timestamp: number
}

interface RecentInputsState {
  recentInputs: Record<string, RecentInput[]> // keyed by toolId
  addRecentInput: (toolId: string, formData: Record<string, string>) => void
  getRecentInputs: (toolId: string) => RecentInput[]
  hydrate: () => void
}

const RECENT_INPUTS_KEY = 'antigravity-recent-inputs'
const MAX_RECENT_INPUTS = 5

function loadRecentInputs(): Record<string, RecentInput[]> {
  if (typeof window === 'undefined') return {}
  try {
    const raw = localStorage.getItem(RECENT_INPUTS_KEY)
    return raw ? JSON.parse(raw) : {}
  } catch {
    return {}
  }
}

function saveRecentInputs(inputs: Record<string, RecentInput[]>) {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(RECENT_INPUTS_KEY, JSON.stringify(inputs))
  } catch {
    // localStorage may be full or unavailable
  }
}

export const useRecentInputsStore = create<RecentInputsState>((set, get) => ({
  recentInputs: {},
  addRecentInput: (toolId: string, formData: Record<string, string>) => {
    const current = { ...get().recentInputs }
    const toolInputs = current[toolId] || []

    // Check if this exact combination already exists (compare form data values)
    const isDuplicate = toolInputs.some(
      (input) =>
        Object.keys(input.formData).length === Object.keys(formData).length &&
        Object.entries(input.formData).every(
          ([key, value]) => formData[key] === value
        )
    )

    if (isDuplicate) return

    const newInput: RecentInput = {
      id: `${toolId}-${Date.now()}`,
      toolId,
      formData,
      timestamp: Date.now(),
    }

    // Prepend new input, keep only MAX_RECENT_INPUTS
    const updated = [newInput, ...toolInputs].slice(0, MAX_RECENT_INPUTS)
    current[toolId] = updated
    saveRecentInputs(current)
    set({ recentInputs: current })
  },
  getRecentInputs: (toolId: string) => {
    return get().recentInputs[toolId] || []
  },
  hydrate: () => {
    set({ recentInputs: loadRecentInputs() })
  },
}))
